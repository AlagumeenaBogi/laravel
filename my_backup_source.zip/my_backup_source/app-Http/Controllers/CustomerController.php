<?php 
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input; //use Illuminate\Support\Facades\Input as input; //https://stackoverflow.com/questions/31696679/laravel-5-class-input-not-found
use Session;
use DB;
//use Illuminate/Database;
use App\Http\Requests;
use App\Http\Controllers\Controller;


class CustomerController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('guest');
	}

        /*public function formValidationPost(Request $request)
        {
        $this->validate($request,[
        'contact_person_name' => 'required|min:5|max:35'
        ],[
        'contact_person_name.required' => ' The first name field is required.',
        ]);
        dd('You are successfully added all fields.');
        }*/

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function customer(Request $req)
	{          
          
            $contact_person_name = Input::get('contact_person_name');// $arr_count=count($req->input('contact_person_name'));//echo "--customer_modules_testing--->".$req."<BR><BR>"; //            echo "-outstide-->".$arr_count."<BR><BR><BR>";
            $email = Input::get('email');
            $mobile_number = Input::get('mobile_number');//            print_r($quantities);
            $customer_info_arrs = array('contact_person_name' => $contact_person_name, 'mobile_number' => $mobile_number,'email'=>$email);
            //echo "step1--------><pre>"; print_r($customer_info_arrs);            //$brand_count = array_count_values($brand_ids);  foreach ($brand_count as $key=>$value) {
            $i=0;
            foreach($customer_info_arrs['contact_person_name'] as $key=>$customer_info_arr)
            {
               // echo "--name-->".$customer_info_arr."----->".$customer_info_arrs['mobile_number'][$i]."---".$customer_info_arrs['email'][$i]."<BR>";//DB::insert('insert into customer (client_contact_person_name,client_contact_person_email_ids,client_contact_person_mobile_number) values(?,?)',($customer_info_arr,$customer_info_arrs['email'][$i],$customer_info_arrs['mobile_number'][$i])); //THIS IS SAMPLE INSERT MODULEING
                $myItems[] = ['client_contact_person_name'=>$customer_info_arr,'client_contact_person_email_ids'=>$customer_info_arrs['mobile_number'][$i],'client_contact_person_mobile_number'=>$customer_info_arrs['email'][$i]];//http://itsolutionstuff.com/post/how-to-insert-multiple-records-in-laravel-5example.html
            }//echo "<pre>";            print_r($myItems);
            $insert_customer=DB::table("customer")->insert($myItems);

            if($insert_customer){
               Session::flash('alert-success', 'customer basic information added successfully !');
                return view('form'); }//echo "succcess"."<BR>";
            else
                return view('home'); //echo "failed"."<BR>";
            //https://stackoverflow.com/questions/31980457/laravel-5-get-ajax-array-post-in-controller
            //https://stackoverflow.com/questions/30496740/php-how-to-save-data-from-array-to-mysql-using-laravel-5
            //http://itsolutionstuff.com/post/bootstrap-form-validation-example-with-demo-using-validatorjs-pluginexample.html
             /* DB::table('customer')->insert(
                    array(
                        'client_contact_person_name' => $customer_info_arr,
                        'client_contact_person_email_ids' => $customer_info_arrs['mobile_number'][$i],
                        'client_contact_person_mobile_number' =>$customer_info_arrs['email'][$i]
                    )
                );*///https://laravel.io/forum/04-30-2014-saving-dynamically-created-form-field-array-to-db-laravel-way
                /*$member = new Member;
                $member->first = Input::get("member_first.$key");
                $member->save();
                $i++;*/
	}

}
