<?php
echo "information--->"."<BR>";
?>
<!----div class="all-padding-six" style="margin-top:-5px;">
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">MFI Head Office Account Setup</h4>
            </div>
            <div id="collapse1" class="panel-collapse collapse in">
                <div class="panel-body clear-padding">
                    <ul class="list-unstyled clear-margin-bottom">
                        <li class="left_link_list">
                            MFI Basic Information  <span class="pull-right glyphicon glyphicon-ok" style="color: green;">&nbsp;</span>
                        </li>
                        <li class="left_link_list">
                            Head Ofiice Location <span class="pull-right glyphicon glyphicon-ok" style="color: green;">&nbsp;</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div--->
