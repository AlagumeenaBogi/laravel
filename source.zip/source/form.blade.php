@extends('layouts.dashboard')
@section('section')
<div class="row">
            <div class="col-sm-12"><div class="col-sm-2"></div><div class="col-sm-8">
                <div class="flash-message">
                    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                    @if(Session::has('alert-' . $msg))
                    <p class="alert alert-{{ $msg }} alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>{{ Session::get('alert-' . $msg) }}</p>
                    @endif
                    @endforeach
                </div>
                    <!----------<div class="alert alert-success alert-dismissable">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div>----------->
            </div><div class="col-sm-2"></div></div>
            <div class="col-sm-3 clear-right-padding">            
                <div class="all-padding-six" style="margin-top:-5px;">
                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Customer Account Setup</h4>
                            </div>
                            <div id="collapse1" class="panel-collapse collapse in">
                                <div class="panel-body clear-padding">
                                    <ul class="list-unstyled clear-margin-bottom">
                                        <li class="left_link_list">
                                           <a href="{{ url ('forms') }}"> Customer Basic Information  <span class="pull-right glyphicon glyphicon-ok" style="color: green;">&nbsp;</span> </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <div class="col-sm-9">
            <div class="well">
                <form class="form-horizontal" method="post" name="customer_information_form" id="customer_information_form" action="forms">
		    <h2 class="view-info-underline">Customer Basic information</h2>
                    <input type='hidden' name='_token' value="<?=csrf_token();?>">
                    <div class="alert alert-warning alert-dismissible" role="alert">Please add New Customer information to the platform.<br/><br/>
                        <i class="fa fa-lightbulb-o"></i>
                        Adding Customer help<br/></div>
                    <div class="addmore_branch">
                        <h5 class="add_branch"></h5>
                        <div class="form-group" >
                            <div class="col-sm-3 text_right">
                                <label  class="control-label" >Customer name <span class="star">*</span></label>
                            </div>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon glyphicon glyphicon-user"></span>
                                    <input type="text" id="contact_person_name" name="contact_person_name[]" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="form-group" >
                            <div class="col-sm-3 text_right">
                                <label class="control-label" >Mobile number <span class="star">*</span></label>
                            </div>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon glyphicon glyphicon-phone"></span>
                                    <input type="text" id="mobile_number" name="mobile_number[]" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="form-group" >
                            <div class="col-sm-3 text_right">
                                <label  class="control-label" >Email ID <span class="star">*</span></label>
                            </div>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon">@</span>
                                    <input type="text" id="email" name="email[]" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="pull-right">
                            <a class="btn btn-default-own btn-xs addmore_link" onclick="addmore('addmore_branch','add_branch','addmore_link','Customer')" >
                                <i class="fa fa-plus"></i> Add More
                            </a>
                        </div>
                        <div class="clear"></div>
                    </div>


                    <div class="form-group"> </div><br>
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <!---button type="submit" class="btn btn-default-own pull-right" name="branch_office_submit">
                                <span class="glyphicon glyphicon-ok"></span>Submit
                            </button--->
                            <input type='submit' name='submit' value='submit' class="btn btn-default-own pull-right">
                            <button type="button" onclick="location.href='federation_information.php'" class="btn btn-primary pull-right" style="margin-right:5%" name="head_office_submit" >
                                    <span class="glyphicon glyphicon-share-alt"></span>Skip
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
</div>

@endsection
<!-----
2.Add More ---done
9.Insert functionality ---done
10.Insert Functionality with addmore concept ---done
11.Submit next redirect tha other page selection process ---done
15.left menu  ---done
14.success added alert  ---done
3.Validation---done

1.FORM DESIGN (datepicker,select box,check box,radio buttion,image field)
4.Ajax
5.Geo Location (MULTIPLE SELECTION OPTION)
6.Popup Box
7.left menu (Manuvally done )
8.link path header menu (dashboard only pending
12.customer - add customer - customer list ===>Please prepare
13.Mail Functionalinality
16.pagenation
17.Cookies-------------------------------->