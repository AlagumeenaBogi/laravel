<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
	<meta charset="utf-8"/>
	<title>Invoice Module for Laravel 5</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport"/>
	<meta content="" name="description"/>
	<meta content="" name="author"/>

	<link rel="stylesheet" href="{{ asset("assets/stylesheets/styles.css") }}" />
           
</head>
<body>
	@yield('body')

<script src="{{ asset("assets/scripts/frontend.js") }}" type="text/javascript"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script>
Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Aromatic Rice',
            y: 56.33
        }, {
            name: 'Roasted Flax Seeds ',
            y: 24.03,
            sliced: true,
            selected: true
        }, {
            name: 'Dates Palm Jagger',
            y: 10.38
        }, {
            name: 'Traditional Millet Jwar',
            y: 4.77
        }, {
            name: 'Dates Palm Sugar',
            y: 0.91
        }, {
            name: 'Black Pepper',
            y: 0.2
        }]
    }]
});

Highcharts.chart('current_asset', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: 0,
        plotShadow: false
    },
    
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: true,
                distance: -50,
                style: {
                    fontWeight: 'bold',
                    color: 'white'
                }
            },
            startAngle: -90,
            endAngle: 90,
            center: ['50%', '75%']
        }
    },
    series: [{
        type: 'pie',
        name: 'Browser share',
        innerSize: '50%',
        data: [
            ['Cash in Hand',   10.38],
            ['Cash in Bank',       56.33],
            {
                name: 'Proprietary or Undetectable',
                y: 0.2,
                dataLabels: {
                    enabled: false
                }
            }
        ]
    }]
});
</script>
<!--
<script type="text/javascript">
                            	$(function () {
									$('#portfolio_at_risk_chart').highcharts({
										chart: {
											plotBackgroundColor: null,
											plotBorderWidth: null,
											plotShadow: false
										},
										exporting: {
											enabled: false
										},

										credits: {
											enabled: false
										},

										title: {
											text: ''
										},
										tooltip: {
											pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
										},
										plotOptions: {
											pie: {
													allowPointSelect: true,
													cursor: 'pointer',
													dataLabels: {
															enabled: true,
															format: '<b>{point.name}</b>: {point.percentage:.1f} %<br>Amount : {point.y:.1f}',
															style: {
																	color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
															}
													}
											}
										},
										series: [{
											type: 'pie',
                                                                                        name: 'Federation',
											data: [portfolio_at_risk]
										}
                                                                            ]
									});
								});
                            </script>
//data: [['Current' ,4261444.00],['1-30 days late' ,3588996.00],['31-60 days late' ,3474903.00],['61-90 days late' ,3430581.00],['91-120 days late' ,3420489.00],['More than 120 days late' ,11641415.00]]
							
------>
</body>
</html>