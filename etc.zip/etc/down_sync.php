<?php
//ini_set('memory_limit', '-1');
//set_time_limit(0);
	error_reporting("0");

	$field_agent_mobile_number = $_REQUEST['mobile_no'];
//$token = $_REQUEST['token'];
//echo "mobile no----->".$field_agent_mobile_number;
	if(!$field_agent_mobile_number)
		{
			echo "Mobile Number is Empty";
			exit;
		}
                
		
$final_arry = array();
//$finalarry1 = array();
/* connect to the db */
//Microfinance Global Database
$microfinance_global_host = "localhost";  // server to connect to.
$microfinance_global_database_username = "microfin_microfn";  // mysql password to access the database with.
$microfinance_global_database_password = '_#$y&;Hb-5#D';  // mysql password to access the database with.
$microfinance_global_database = "microfin_global";  // the name of the database.
$link_microfinance_global = mysql_connect($microfinance_global_host, $microfinance_global_database_username, $microfinance_global_database_password) or die("Cannot Microfinance Client Database"); 
mysql_select_db($microfinance_global_database, $link_microfinance_global);


	
	/*----- Select Field Agent Details -----*/
	
	$select_field_agent_details = mysql_fetch_object(mysql_query("SELECT field_agent_id, account_level, account_level_id, client_id,field_officer_agent_extensions FROM field_agents WHERE  mobile_number='$field_agent_mobile_number'     ORDER BY field_agent_id ASC LIMIT 0, 1", $link_microfinance_global));
        //echo "SELECT field_agent_id, account_level, account_level_id, client_id,field_officer_agent_extensions FROM field_agents WHERE  mobile_number='$field_agent_mobile_number'     ORDER BY field_agent_id ASC LIMIT 0, 1";
	//echo "<br>db-->".$link_microfinance_global;
	$field_agent_id = $select_field_agent_details->field_agent_id;
       // echo "field_agent_id->".$field_agent_id;
	$field_agent_account_level = $select_field_agent_details->account_level;
	$field_agent_account_level_id = $select_field_agent_details->account_level_id;
	$field_client_id = $select_field_agent_details->client_id;
       // $field_client_id=43;
        $field_agent_photo= $select_field_agent_details->field_officer_agent_extensions;
        
     // echo   $field_agent_id;//external_customer_loanemi
     // echo $field_client_id;
	//echo $field_agent_account_level;
      //  echo $field_agent_account_level_id;
        
	
	
	/*----- Field Agent Database Connection -----*/

	$client_database_name = mysql_fetch_object(mysql_query("SELECT database_name FROM clients WHERE client_id = '$field_client_id'", $link_microfinance_global))->database_name;
	$client_storage_database_name = $client_database_name."_storage";
	$client_downsync_database_name = $client_database_name."_downsync";
    $client_reports_database_name = $client_database_name."_reports";


	//Client Storage Database
	$client_storage_host = "localhost"; // server to connect to.
	$client_storage_database_username = "microfin_microfn";  // mysql password to access the database with.
	$client_storage_database_password = '_#$y&;Hb-5#D';  // mysql password to access the database with.
	$link_client_storage_database = mysql_connect($client_storage_host, $client_storage_database_username, $client_storage_database_password, true) or die("Cannot Microfinance Storage Database");
	mysql_select_db($client_storage_database_name, $link_client_storage_database);
	
	
	
	//Client Downsync Database
	$client_downsync_host = "localhost"; // server to connect to.
	$client_downsync_database_username = "microfin_microfn"; // mysql password to access the database with.
	$client_downsync_database_password = '_#$y&;Hb-5#D';  // mysql password to access the database with.
	$link_client_downsync_database = mysql_connect($client_downsync_host, $client_downsync_database_username, $client_downsync_database_password, true) or die("Cannot Microfinance Downsync Database");
	mysql_select_db($client_downsync_database_name, $link_client_downsync_database);
	
	
	
	
	/*----------------------------------------------------------------------------------------------------*/
	
	
	
	/*
	====================================================================================================
	||                                                                                                ||
	||                                          Masters                                               ||
	||                                                                                                || 
	====================================================================================================
	*/	
	
	
 	

 	/*$customerQuery = "SELECT wpk_customer_id, dpk_customer_id as dpk_id, group_id, customer_cin, id_card FROM customers WHERE field_agent_id = $field_agent_id";
 	//echo "customer--------->".$customerQuery ;
 	$customer = array();
	$customer_result = mysql_query($customerQuery, $link_client_downsync_database);
	if(mysql_num_rows($customer_result))
		{
			while($post = mysql_fetch_object($customer_result))
				{
					$customer_array[] = $post;

				}
//echo "<pre>";
//print_r($customer_array);
			$customer['customer'] = $customer_array;
		}*/
//echo "<br>hai";
//$final_arry1 = $customer;
//print_r($final_arry1);
		/*$field_info1 = array();
$selct_fieldagent="SELECT field_agent_id,field_officer_agent_extensions FROM field_agents WHERE mobile_number='$field_agent_mobile_number'";
        //echo "SELECT field_agent_id,field_officer_agent_extensions FROM field_agents WHERE mobile_number='$field_agent_mobile_number'";
	
        
	$field_info_result1 = mysql_query($selct_fieldagent, $link_microfinance_global);
	if(mysql_num_rows($field_info_result1))
		{
			while($post = mysql_fetch_object($field_info_result1))
				{
                            //echo $post;
                                       //  $post+=$client_database_name;
					$field_info_array1[] = $post;
                                     //   print_r($mfi_info_array);
				}
			$field_info1['fieldagentinfo'] = $field_info_array1;
		}*/


	/*----- MFI Info -----*/

	$mfiInfoQuery = "SELECT affliation_id as mfi_registration_id, affliation_name as mfi_name FROM affliations WHERE affiliation_method_id = '2' AND affliation_type = '1' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$mfi_info = array();
	$mfi_info_result = mysql_query($mfiInfoQuery, $link_client_downsync_database);
	if(mysql_num_rows($mfi_info_result))
		{
			while($post = mysql_fetch_object($mfi_info_result))
				{
                                       //  $post+=$client_database_name;
					$mfi_info_array[] = $post;
                                     //   print_r($mfi_info_array);
				}
			$mfi_info['mfi_info'] = $mfi_info_array;
		}

                //print_r($mfi_info);

   /*Database Name*/
         $databasename=array();         
         $client_database_names = "SELECT database_name FROM clients WHERE client_id = '$field_client_id'";       
         
         $mfi_dataB_result = mysql_query($client_database_names, $link_microfinance_global);
	if(mysql_num_rows($mfi_dataB_result))
		{
			while($post = mysql_fetch_object($mfi_dataB_result))
				{
                                       //  $post+=$client_database_name;
					$mfi_database_array[] = $post;
                                     //   print_r($mfi_info_array);
				}
			$databasename['Data_Base'] = $mfi_database_array;
		}
                 
             // print_r($databasename);
         // $client_database_name
        //  $databasename['Data_Base']=$client_database_name;              

	/*----- Branch Info -----*/

	$branchInfoQuery = "SELECT affliation_id as branch_id, affliation_name as branch_name FROM affliations WHERE affiliation_method_id = '2' AND affliation_type = '2' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$branch_info = array();
	$branch_info_result = mysql_query($branchInfoQuery, $link_client_downsync_database);
	if(mysql_num_rows($branch_info_result))
		{
			while($post = mysql_fetch_object($branch_info_result))
				{
					$branch_info_array[] = $post;
				}
			$branch_info['branch_info'] = $branch_info_array;
		}

	
	
	
	/*----- Federation Info -----*/	
	
	$federationInfoQuery = "SELECT affliation_id as federation_id, affliation_name as federation_name FROM affliations WHERE affiliation_method_id = '2' AND affliation_type = '3' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$federation_info = array();
	$federation_info_result = mysql_query($federationInfoQuery, $link_client_downsync_database);
	if(mysql_num_rows($federation_info_result))
		{
			while($post = mysql_fetch_object($federation_info_result))
				{
					$federation_info_array[] = $post;
				}
			$federation_info['federation_info'] = $federation_info_array;
		}



         

	/*----- Cluster Info -----*/

	$clusterInfoQuery = "SELECT affliation_id as cluster_id, affliation_name as cluster_name FROM affliations WHERE affiliation_method_id = '2' AND affliation_type = '4' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$cluster_info = array();
	$cluster_info_result = mysql_query($clusterInfoQuery, $link_client_downsync_database);
	if(mysql_num_rows($cluster_info_result))
		{
			while($post = mysql_fetch_object($cluster_info_result))
			{
			$cluster_info_array[] = $post;
			}
			$cluster_info['cluster_info'] = $cluster_info_array;
		}



	/*----- Banks -----*/


	$bankQuery = "SELECT affliation_id as bank_id, affliation_name as bank_name FROM affliations WHERE affiliation_method_id = '1' AND affliation_type = '1' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$bankdetails = array();
	$bankdetails_result = mysql_query($bankQuery, $link_client_downsync_database);
	if(mysql_num_rows($bankdetails_result))
	{
		while($post = mysql_fetch_object($bankdetails_result))
			{
				$bankdetails_array[] = $post;
			}
		$bankdetails['bank'] = $bankdetails_array;
	}

	
	
	
	/*----- Insurance Companies -----*/
	
	$insuranceQuery = "SELECT affliation_id as insurance_company_id, affliation_name as insurance_company_name FROM affliations WHERE affiliation_method_id = '1' AND affliation_type = '2' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$insurancdetails = array();
	$insurancdetails_result = mysql_query($insuranceQuery, $link_client_downsync_database);
	if(mysql_num_rows($insurancdetails_result))
		{
			while($post = mysql_fetch_object($insurancdetails_result))
				{
					$insurancdetails_array[] = $post;
				}
			$insurancdetails['insurance_company'] = $insurancdetails_array;
		}



	/*----- Projects -----*/
	

	$projectQuery = "SELECT affliation_id as government_project_id, affliation_name as government_project_name FROM affliations WHERE affiliation_method_id = '1' AND affliation_type = '3' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$project_details = array();
	$project_details_result = mysql_query($projectQuery, $link_client_downsync_database);
	if(mysql_num_rows($project_details_result))
		{
			while($post = mysql_fetch_object($project_details_result))
				{
					$project_details_array[] = $post;
				}
			$project_details['project'] = $project_details_array;
		}

	
	
	
	/*----- Donors -----*/
	
	$donorQuery = "SELECT affliation_id as donor_id, affliation_name as donor_name FROM affliations WHERE affiliation_method_id = '1' AND affliation_type = '4' AND account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	
	$donor_productdetails = array();
	$donor_productdetails_result = mysql_query($donorQuery, $link_client_downsync_database);
	if(mysql_num_rows($donor_productdetails_result))
		{
			while($post = mysql_fetch_object($donor_productdetails_result))
			{
				$donor_productdetails_array[] = $post;
			}
			$donor_productdetails['donor'] = $donor_productdetails_array;
		}

 	
 	
 	
 	
 	/*----- Ledgers -----*/
 	
 /*	$ledger_query = "SELECT l.group_id, l.wpk_ledger_id, l.ledger_type, l.ledger_name, l.closing_balance, l.closing_balance_value, l.closing_balance_date FROM ledgers AS l, groups AS g WHERE l.group_id = g.wpk_group_id AND g.fo_id = '$field_agent_id'";
 	
 	$ledger = array();
	$ledger_result = mysql_query($ledger_query, $link_client_downsync_database);
	if(mysql_num_rows($ledger_result))
		{
			while($post = mysql_fetch_object($ledger_result))
				{
					$ledger_array[] = $post;
				}
			$ledger['ledger'] = $ledger_array;
		}*/

 	
 	
 	
 	/*----- Field Agent Details -----*/
 	
 	$fieldQuery = "SELECT mobile_number, email_id, date_of_birth, clin, app_registration_no FROM field_agents WHERE wpk_field_agent_id = $field_agent_id";
 	
	$field_agents = array();
	$field_agents_result = mysql_query($fieldQuery, $link_client_downsync_database);
	if(mysql_num_rows($field_agents_result))
		{
			while($post = mysql_fetch_object($field_agents_result))
				{
					$field_agents_array[] = $post;
				}
			$field_agents['field_agents'] = $field_agents_array;
		}

	
	
	/*----- Field Agent Villages -----*/

 	$villageQuery = "SELECT vid, village_name FROM villages WHERE fo_id = $field_agent_id";
 	
 	$village = array();
	$village_result = mysql_query($villageQuery, $link_client_downsync_database);
	if(mysql_num_rows($village_result))
		{
			while($post = mysql_fetch_object($village_result))
				{
					$village_array[] = $post;
				}
			$village['village'] = $village_array;
		}
		
		
		
	/*----- Field Agent Groups -----*/	

 	$groupQuery = "SELECT wpk_group_id as group_id, group_cin, group_name, village_id FROM groups WHERE fo_id = $field_agent_id";
 	
	$group = array();
	$group_result = mysql_query($groupQuery, $link_client_downsync_database);
	if(mysql_num_rows($group_result))
		{
			while($post = mysql_fetch_object($group_result))
				{
					$group_array[] = $post;
				}
			$group['groups'] = $group_array;
		}


       /*----- Field Agent Log Groups -----*/	

 	$log_groupQuery = "SELECT * FROM log_groups WHERE fo_id = $field_agent_id";
 	//echo $log_groupQuery;
	$log_group = array();
	$log_group_result = mysql_query($log_groupQuery, $link_client_downsync_database);
	if(mysql_num_rows($log_group_result))
		{
			while($post = mysql_fetch_object($log_group_result))
				{
					$log_group_array[] = $post;
				}
			$log_group['log_groups'] = $log_group_array;
		}
          
     //print_r($log_group);

/*----- Field Agent Log Groups Settings -----*/	

 	$log_group_settingsQuery = "SELECT * FROM log_group_settings WHERE fo_id = $field_agent_id";
 	
	$log_group_settings = array();
	$log_group_settings_result = mysql_query($log_group_settingsQuery, $link_client_downsync_database);
	if(mysql_num_rows($log_group_settings_result))
		{
			while($post = mysql_fetch_object($log_group_settings_result))
				{
					$log_group_settings_array[] = $post;
				}
			$log_group_settings['log_group_settings'] = $log_group_settings_array;
		}

        /*----- Field Agent Log Groups Producgt Settings-----*/	

 	$log_groupQuery = "SELECT * FROM log_group_product_settings WHERE fo_id = $field_agent_id";
 	
	$log_group_product_settings = array();
	$log_group_product_settings_result = mysql_query($log_groupQuery, $link_client_downsync_database);
	if(mysql_num_rows($log_group_product_settings_result))
		{
			while($post = mysql_fetch_object($log_group_product_settings_result))
				{
					$log_group_product_settings_array[] = $post;
				}
			$log_group_product_settings['log_group_product_settings'] = $log_group_product_settings_array;
		}

 	
         /*----- Field Agent Log  Groups Loan Producgt Settings-----*/	

	$log_group_loan_Query = "SELECT * FROM log_group_loan_product_sett WHERE fo_id = $field_agent_id";
 	//echo $log_group_loan_Query;
	$log_group_loan_product_sett = array();
	$log_group_loan_product_sett_result = mysql_query($log_group_loan_Query, $link_client_downsync_database);
	if(mysql_num_rows($log_group_loan_product_sett_result))
		{
			while($post = mysql_fetch_object($log_group_loan_product_sett_result))
				{
					$log_group_loan_product_sett_array[] = $post;
				}
			$log_group_loan_product_sett['log_group_loan_product_sett'] = $log_group_loan_product_sett_array;
		}
 	

 /*----- Field Agent Log Groups internal loan disbursement -----*/	

 	$log_internal_loan_disbursement_Query = "SELECT * FROM log_internal_loan_disbursement WHERE fo_id = $field_agent_id";
 	//echo $log_groupQuery;
	$log_internal_loan_disbursement = array();
	$log_internal_loan_disbursement_result = mysql_query($log_internal_loan_disbursement_Query, $link_client_downsync_database);
	if(mysql_num_rows($log_internal_loan_disbursement_result))
		{
			while($post = mysql_fetch_object($log_internal_loan_disbursement_result))
				{
					$log_internal_loan_disbursement_array[] = $post;
				}
			$log_internal_loan_disbursement['log_internal_loan_disbursement'] = $log_internal_loan_disbursement_array;
		}

 /*----- Field Agent Log Groups Meeting -----*/
$log_group_meetingQuery = "SELECT * FROM log_group_meeting WHERE fo_id = $field_agent_id";
 	//echo $log_groupQuery;
	$log_group_meeting = array();
	$log_group_meeting_result = mysql_query($log_group_meetingQuery, $link_client_downsync_database);
	if(mysql_num_rows($log_group_meeting_result))
		{
			while($post = mysql_fetch_object($log_group_meeting_result))
				{
					$log_group_meeting_array[] = $post;
				}
			$log_group_meeting['log_group_meeting'] = $log_group_meeting_array;
		}

 /*----- Customer External loan Request-----*/
	$log_external_loan_requestQuery = "SELECT * FROM log_external_loan_request WHERE fo_id = $field_agent_id";
 	//echo $log_groupQuery;
	$log_external_loan_request = array();
	$log_external_loan_request_result = mysql_query($log_external_loan_requestQuery, $link_client_downsync_database);
	if(mysql_num_rows($log_external_loan_request_result))
		{
			while($post = mysql_fetch_object($log_external_loan_request_result))
				{
					$log_external_loan_request_array[] = $post;
				}
			$log_external_loan_request['log_external_loan_request'] = $log_external_loan_request_array;
		}
 	/*----- Field Agent Customers -----*/


  $customerQuery = "SELECT `wpk_customer_id`,dpk_customer_id AS dpk_id,`customer_cin`,
`group_id`,`customer_name`,`date_of_birth`,`gender`,`date_of_join`,`mobile_no`,`father_name`,
`mother_name`,`spouse_name`,`nominee_name`,`door_no`,`address`,`street_name`,`district`,`village_id`,
`id_proff`,`address_proff`,`signature_proff`,`aadhaar_card`,`photo`,`id_card`,`postal_code`,`status`
 FROM customers WHERE field_agent_id = $field_agent_id";
 	
 	$customer = array();
	$customer_result = mysql_query($customerQuery, $link_client_storage_database);
	if(mysql_num_rows($customer_result))
		{
			while($post = mysql_fetch_object($customer_result))
				{
					$customer_array[] = $post;
				}
			$customer['customer'] = $customer_array;
		}

	//print_r($customer);
                
                
                
                
                /*-------------field agent photo---------*/
	/*----- Loan Products -----*/

 	$loan_product_query = "SELECT loan_product_id AS product_id, account_level AS org_type, account_level_id AS org_id, loan_product_name AS product_name, loan_tenure_minimum_installment as min_install, loan_tenure_maximum_installment as max_install, minimum_loan_amount as min_amount, maximum_loan_amount as max_amount, loan_interest_rate, loan_interest_type_id, moratorium_period FROM loan_products  WHERE status = '1' AND account_level=$field_agent_account_level AND account_level_id=$field_agent_account_level_id";
 	
	$loan_productdetails = array();
	$loan_productdetails_result = mysql_query($loan_product_query, $link_client_storage_database);
	if(mysql_num_rows($loan_productdetails_result))
		{
			while($post = mysql_fetch_object($loan_productdetails_result))
				{
					$loan_productdetails_array[] = $post;
				}
			$loan_productdetails['loan_products'] = $loan_productdetails_array;
		}

 	
 	
 	/*----- Savings Product -----*/
 	
 	$savings_product_query = "SELECT savings_product_id, account_level, account_level_id, savings_product_name, minimum_savings_amount, maximum_savings_amount, compulsory_savings_amount, savings_interest_rate FROM savings_products WHERE status = '1' AND account_level=$field_agent_account_level AND account_level_id=$field_agent_account_level_id";
	$savings_productdetails = array();
	$savings_productdetails_result = mysql_query($savings_product_query, $link_client_storage_database);
	if(mysql_num_rows($savings_productdetails_result))
		{
			while($post = mysql_fetch_object($savings_productdetails_result))
				{
					$savings_productdetails_array[] = $post;
				}
			$savings_productdetails['savings_products'] = $savings_productdetails_array;
		}
		
		
	
	/*----- Fixed Deposit Product -----*/
 	
 	$fixed_deposit_product_query = "SELECT fixed_deposit_product_id, account_level, account_level_id, fixed_deposit_product_name, fixed_deposit_period_minimum_month, fixed_deposit_period_maximum_month, fixed_deposit_minimum_amount, fixed_deposit_maximum_amount, fixed_deposit_interest_rate FROM fixed_deposit_products WHERE status = '1' AND account_level=$field_agent_account_level AND account_level_id=$field_agent_account_level_id";
 	
	$fixed_deposit_productdetails = array();
	$fixed_deposit_productdetails_result = mysql_query($fixed_deposit_product_query, $link_client_storage_database);
	if(mysql_num_rows($fixed_deposit_productdetails_result))
		{
			while($post = mysql_fetch_object($fixed_deposit_productdetails_result))
				{
					$fixed_deposit_productdetails_array[] = $post;
				}
			$fixed_deposit_productdetails['fixed_deposit_products'] = $fixed_deposit_productdetails_array;
		}
		
                
                
		

	/*----- Insurance Products -----*/ 
 	
 	$insurance_product_query = "SELECT insurance_product_id, account_level, account_level_id, insurance_product_name, insurance_premium_duration,insurance_coverage_amount,insurance_premium_amount FROM insurance_products WHERE status = '1' AND account_level=$field_agent_account_level AND account_level_id=$field_agent_account_level_id";
 	 
	$insurance_productdetails = array();
	$insurance_productdetails_result = mysql_query($insurance_product_query, $link_client_storage_database);
	if(mysql_num_rows($insurance_productdetails_result))
		{
			while($post = mysql_fetch_object($insurance_productdetails_result))
				{
					$insurance_productdetails_array[] = $post;
				}
			$insurance_productdetails['insurance_products'] = $insurance_productdetails_array;
		}
		
	
	
	
	/*----- Subscription Products -----*/
 	
 	$subscription_product_query = "SELECT subscription_product_id, account_level, account_level_id, subscription_type_id, subscription_product_name, compulsory_subscription_amount FROM subscription_products WHERE status = '1' AND account_level=$field_agent_account_level AND account_level_id=$field_agent_account_level_id";
 	
	$subscription_productdetails = array();
	$subscription_productdetails_result = mysql_query($subscription_product_query, $link_client_storage_database);
	if(mysql_num_rows($subscription_productdetails_result))
		{
			while($post = mysql_fetch_object($subscription_productdetails_result))
				{
					$subscription_productdetails_array[] = $post;
				}
			$subscription_productdetails['subscription_products'] = $subscription_productdetails_array;
		}
                
                
                /*-----  Savings Account table -----*/
 	
 	$savings_account_query = "SELECT user_id,savings_account_number,from_account_level_id,savings_account_id,savings_interest_rate FROM savings_accounts WHERE status = '1' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$savings_accountdetails = array();
	$savings_accountdetails_result = mysql_query($savings_account_query, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result))
				{
					$savings_accountdetails_array[] = $post;  
				}
			$savings_accountdetails['savings_account_det'] = $savings_accountdetails_array;  
		}
                
                
                $fixdep_account_query = "SELECT user_id,fixed_deposit_account_number,from_account_level_id,fixed_deposit_account_id,fixed_deposit_interest_rate FROM fixed_deposit_accounts WHERE status = '1' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$fixdep_accountdetails = array();  
	$fixed_accountdetails_result = mysql_query($fixdep_account_query, $link_client_storage_database);
	if(mysql_num_rows($fixed_accountdetails_result))
		{
			while($post = mysql_fetch_object($fixed_accountdetails_result))
				{
					$fix_accountdetails_array[] = $post;  
				}
			$fixdep_accountdetails['fixdepos_account_det'] = $fix_accountdetails_array;  
		} 
                
                
                
                $insurance_account_query = "SELECT user_id,insurance_policy_number,from_account_level_id,insurance_policy_id,insurance_premium_amount FROM insurance_policies WHERE status = '1' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$insurance_accountdetails = array();  
	$insurance_accountdetails_result = mysql_query($insurance_account_query, $link_client_storage_database);
	if(mysql_num_rows($insurance_accountdetails_result))
		{
			while($post = mysql_fetch_object($insurance_accountdetails_result))
				{
					$insure_accountdetails_array[] = $post;  
				}
			$insurance_accountdetails['insurance_account_det'] = $insure_accountdetails_array;  
		} 
                
               // $savings_accountdetails_update = array();
                $savings_account_query2 = "SELECT savings_account_id FROM savings_accounts WHERE status = '2' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$savings_accountdetails2 = array();
	$savings_accountdetails_result = mysql_query($savings_account_query2, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result))
				{
					$savings_accountdetails_array2[] = $post;  
				}
			$savings_accountdetails2['savings_account_det_update'] = $savings_accountdetails_array2;  
		}
                
                 $savings_account_query3 = "SELECT fixed_deposit_account_id FROM fixed_deposit_accounts WHERE status = '2' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$savings_accountdetails3 = array();
	$savings_accountdetails_result1 = mysql_query($savings_account_query3, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result1))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result1))
				{
					$savings_accountdetails_array3[] = $post;  
				}
			$savings_accountdetails3['fixed_deposit_account_det_update'] = $savings_accountdetails_array3;  
		}
                
                
                $savings_account_query4 = "SELECT insurance_policy_id  FROM insurance_policies WHERE status = '2' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id";
 	
	$savings_accountdetails4 = array();
	$savings_accountdetails_result12 = mysql_query($savings_account_query4, $link_client_storage_database);  
	if(mysql_num_rows($savings_accountdetails_result12))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result12))
				{
					$savings_accountdetails_array4[] = $post;  
				}
			$savings_accountdetails4['insurance_account_det_update'] = $savings_accountdetails_array4;  
		}
                 //$savings_accountdetails_update['savings_account_det_update']='1';
                
       $savings_account_query1 = "SELECT from_account_level,from_account_level_id,to_account_level,to_account_level_id,savings_account_id,approved_withdrawal_amount,approved_time,approved_user_id,wpk_savings_withdrawal_request_id FROM savings_withdrawal_request WHERE status = '2' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id AND from_account_leve_type_id='2' AND to_account_leve_type_id ='2'";
 	
	$savings_accountdetails_withd = array();
	$savings_accountdetails_result1 = mysql_query($savings_account_query1, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result1))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result1))
				{
					$savings_accountdetails_array1[] = $post;  
				}
			$savings_accountdetails_withd['savings_withdrawa_det'] = $savings_accountdetails_array1;  
		}
	
		
		 $savings_account_query12 = "SELECT from_account_level,from_account_level_id,to_account_level,to_account_level_id,fixed_deposit_account_id,approved_withdrawal_amount,approved_time,approved_user_id,wpk_fixed_deposit_withdrawal_request_id FROM fixed_deposit_withdrawal_request WHERE status = '2' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id AND from_account_level_type_id='2' AND to_account_level_type_id ='2'";
 	          //echo $savings_account_query12.'haaa';nghjhjh
	$savings_accountdetails_withd_fix = array();
	$savings_accountdetails_result12 = mysql_query($savings_account_query12, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result12))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result12))
				{
					$savings_accountdetails_array12[] = $post;  
				}
			$savings_accountdetails_withd_fix['fixdeps_withdrawa_det'] = $savings_accountdetails_array12;  
		}
	
                
                 $savings_account_query15 = "SELECT from_account_level,from_account_level_id,to_account_level,to_account_level_id,insurance_policy_id,approved_claim_amount,aproved_time,approve_user_id,wpk_insurance_claim_request_id FROM insurance_claim_request WHERE status = '3' AND to_account_level=$field_agent_account_level AND to_account_level_id=$field_agent_account_level_id AND from_account_level_type_id='2' AND to_account_level_type_id ='2'";     
 	          //echo $savings_account_query15;
	$insure_accountdetails_withd5 = array();
	$savings_accountdetails_result15 = mysql_query($savings_account_query15, $link_client_storage_database);
	if(mysql_num_rows($savings_accountdetails_result15))
		{
			while($post = mysql_fetch_object($savings_accountdetails_result15))
				{
					$savings_accountdetails_array22[] = $post;  
				}
			$insure_accountdetails_withd5['insurance_withdrawa_det'] = $savings_accountdetails_array22;   
		}

	/*----- Messages -----*/
		

 	$messages_query = "SELECT message_id AS message_board_id, message_subject AS subject, message_content AS title FROM messages WHERE field_agent_id  = '$field_agent_id'";
 	
	$messages = array();
	$messages_result = mysql_query($messages_query, $link_client_storage_database);
	
	if(mysql_num_rows($messages_result) > 0)
		{
			while($post = mysql_fetch_object($messages_result))
				{

					$messages_result_array[] = $post; 
				}
			$messages['message_board'] = $messages_result_array;
		}
		
	
	
	
	/*----- Account Level -----*/

 	$account_level_query = "SELECT user_level_id, level_name FROM user_level WHERE status = '1' AND user_level_id<5";
 	
	$account_leveldetails = array();
	$account_leveldetails_result = mysql_query($account_level_query, $link_microfinance_global);
	if(mysql_num_rows($account_leveldetails_result))
		{
			while($post = mysql_fetch_object($account_leveldetails_result))
				{
					$account_leveldetails_array[] = $post;
				}
			$account_leveldetails['account_level'] = $account_leveldetails_array;
		}
	
	
	/*----- Loan Categories -----*/
		

 	$loan_category_query = "SELECT loan_category_id, loan_category_name FROM loan_categories WHERE status = '1'";
 	
	$loan_category = array();
	$loan_category_result = mysql_query($loan_category_query, $link_microfinance_global);
	
	if(mysql_num_rows($loan_category_result) > 0)
		{
			while($post = mysql_fetch_object($loan_category_result))
				{
					$loan_category_array[] = $post;
				}
			$loan_category['loan_categories'] = $loan_category_array;
		}
	
	
	

	/*----- Loan Repayment Frequency -----*/
		

 	$loan_repayment_frequency_query = "SELECT loan_repayment_frequency_id, repayment_frequency FROM loan_repayment_frequency WHERE status = '1'";
 	
	$loan_repayment_frequency = array();
	$loan_repayment_frequency_result = mysql_query($loan_repayment_frequency_query, $link_microfinance_global);
	
	if(mysql_num_rows($loan_repayment_frequency_result) > 0)
		{
			while($post = mysql_fetch_object($loan_repayment_frequency_result))
				{
					$loan_repayment_frequency_array[] = $post;
				}
			$loan_repayment_frequency['loan_repayment_frequency'] = $loan_repayment_frequency_array;
		}
		
		
	
	
	
	/*----- Transaction Mode -----*/
		

 	$transaction_mode_query = "SELECT transaction_mode_id, transaction_mode_name FROM transaction_mode WHERE status  = '1'";
 	
	$transaction_mode = array();
	$transaction_mode_result = mysql_query($transaction_mode_query, $link_microfinance_global);
	
	if(mysql_num_rows($transaction_mode_result) > 0)
		{
			while($post = mysql_fetch_object($transaction_mode_result))
				{
					$transaction_mode_array[] = $post;
				}
			$transaction_mode['transaction_mode'] = $transaction_mode_array;
		}	
	
	
	
	
	/*----- Savings Type -----*/
	
	$savings_type_query = "SELECT savings_type_id, savings_type_name FROM transaction_mode WHERE status  = '1'";
 	
	$savings_type = array();
	$savings_type_result = mysql_query($savings_type_query, $link_microfinance_global);
	
	if(mysql_num_rows($savings_type_result) > 0)
		{
			while($post = mysql_fetch_object($savings_type_result))
				{
					$savings_type_array[] = $post;
				}
			$savings_type['savings_type'] = $savings_type_array;
		}	
	
	
	
	/*----- Subscription Type -----*/
	
	$subscription_type_query = "SELECT subscription_type_id, subscription_type_name FROM transaction_mode WHERE status  = '1'";
 	
	$subscription_type = array();
	$subscription_type_result = mysql_query($subscription_type_query, $link_microfinance_global);
	
	if(mysql_num_rows($subscription_type_result) > 0)
		{
			while($post = mysql_fetch_object($subscription_type_result))
				{
					$subscription_type_array[] = $post;
				}
			$subscription_type['subscription_type'] = $subscription_type_array;
		}	
	
	
	
	/*
	====================================================================================================
	||                                                                                                ||
	||                                      Transactions                                              ||
	||                                                                                                || 
	====================================================================================================
	*/	
		
		
	/*----- Internal Loan Schedule -----*/	

	//$internal_loan_schedule = "SELECT e.wpk_loan_schedule_id, e.group_id, e.member_id, e.loan_account_id, e.loan_account_no, e.due_date, e.due_amount, e.principal_amount, e.interest_amount, e.paid_amount, e.paid_date,e.status FROM member_loan_schedule AS e, groups AS g WHERE g.wpk_group_id = e.group_id AND g.fo_id = '$field_agent_id'";
                $internal_loan_schedule = "SELECT * FROM member_loan_schedule AS e, groups AS g WHERE g.wpk_group_id = e.group_id AND g.fo_id = '$field_agent_id'";
 
	$internal_loan_schedule_info = array();
	$internal_loan_schedule_info_result = mysql_query($internal_loan_schedule, $link_client_downsync_database);
	if(mysql_num_rows($internal_loan_schedule_info_result))
		{
			while($post = mysql_fetch_object($internal_loan_schedule_info_result))
				{
					$internal_loan_schedule_info_array[] = $post;
				}
			$internal_loan_schedule_info['member_loan_schedule'] = $internal_loan_schedule_info_array;
		}

	
	
	
	/*----- External Group Loan Schedule -----*/
	$external_group_loan_schedule = "SELECT * FROM external_group_loan_schedule  WHERE field_agent_id = '$field_agent_id'";
 
	$external_group_loan_schedule_info = array();
	$external_group_loan_schedule_info_result = mysql_query($external_group_loan_schedule, $link_client_downsync_database);
	if(mysql_num_rows($external_group_loan_schedule_info_result))
		{
			while($post = mysql_fetch_object($external_group_loan_schedule_info_result))
				{
					$external_group_loan_schedule_info_array[] = $post;
				}
			$external_group_loan_schedule_info['external_group_loanemi'] = $external_group_loan_schedule_info_array;
		}
		
	
	$external_group_loan_schedule = "SELECT group_id, member_id, loan_account_no, due_date, due_amount, principal_amount, interest_amount, paid_amount, paid_date FROM member_loanemi WHERE fo_id = $field_agent_id";
 
	$external_group_loan_schedule_info = array();
	$external_group_loan_schedule_info_result = mysql_query($external_group_loan_schedule, $link_client_downsync_database);
	if(mysql_num_rows($external_group_loan_schedule_info_result))
		{
			while($post = mysql_fetch_object($external_group_loan_schedule_info_result))
				{
					$external_group_loan_schedule_info_array[] = $post;
				}
			$external_group_loan_schedule_info['external_group_loanemi'] = $external_group_loan_schedule_info_array;
		}
		
	
	
	/*----- External Customer Loan Schedule -----*/
	
 $external_customer_loan_schedule = "SELECT group_id,customer_id,loan_account_id,loan_account_no,total_loan_amount,due_date,due_amount,principal_amount,interest_amount,paid_date,paid_amount  FROM external_customer_loan_schedule WHERE field_agent_id = $field_agent_id and group_id=83";
 
	$external_customer_loan_schedule_info = array();
	$external_customer_loan_schedule_info_result = mysql_query($external_customer_loan_schedule, $link_client_downsync_database);
	if(mysql_num_rows($external_customer_loan_schedule_info_result))
		{
			while($post = mysql_fetch_object($external_customer_loan_schedule_info_result))
				{
					$external_customer_loan_schedule_info_array[] = $post;
				}
			$external_customer_loan_schedule_info['external_customer_loanemi'] = $external_customer_loan_schedule_info_array;
		}
	
//print_r($external_customer_loan_schedule);


	/*
	====================================================================================================
	||                                                                                                ||
	||                                          Reports                                               ||
	||                                                                                                || 
	====================================================================================================
	*/	

	
	
	/*----- meeting_summary_report -----*/
	
	
	
	/* To Work */
	

	/*----- Field Agent Porfolio Report -----*/
	
	$field_agent_portfolio_report_query = "SELECT mfi_name, branch_name, federation_name, cluster_name, total_shgs, total_villages, total_members, number_of_loan_outstanding, outstanding_amount, repayment_amount, compulsory_subscription_amount, fee_paid_by_number_of_members, fee_amount, number_of_policies, premium_collected, current_premium_due, number_of_member_compulsory_savings, member_compulsory_savings_deposit, member_compulsory_savings_withdraw, member_compulsory_savings_current_balance, number_of_member_voluntary_savings, member_voluntary_savings_deposit, member_voluntary_savings_withdraw, member_compulsory_voluntary_current_balance FROM  field_agent_portfolio_report WHERE field_agent_id = '$field_agent_id'";
	//echo $field_agent_portfolio_report_query;
	$field_agent_portfolio_report = array();
	$field_agent_portfolio_report_result = mysql_query($field_agent_portfolio_report_query, $link_client_downsync_database);
	if(mysql_num_rows($field_agent_portfolio_report_result))
		{
			while($post = mysql_fetch_object($field_agent_portfolio_report_result))
				{
					$field_agent_portfolio_report_array[] = $post;
				}
			$field_agent_portfolio_report['field_agent_portfolio_report'] = $field_agent_portfolio_report_array;
		}
	
	
	
	
	
	/*----- Trial Liability -----*/
	
	$trial_liability_query = "SELECT t.trial_balance_id as order_id, t.wpk_group_id as group_id, t.category_level, t.category_name as group_sub_group_name, t.opening_balance, t.debit as debit_amount, t.credit as credit_amount, t.closing_balance, t.previous_year_closing_balance FROM trial_balance AS t, groups AS g  WHERE t.wpk_group_id = g.wpk_group_id AND g.fo_id = '$field_agent_id' AND t.account_type_id = 1 ORDER BY t.trial_balance_id ASC";
	
	$trial_liability = array();
	$trial_liability_result = mysql_query($trial_liability_query, $link_client_downsync_database);
	if(mysql_num_rows($trial_liability_result))
		{
			while($post = mysql_fetch_object($trial_liability_result))
				{
					$trial_liability_array[] = $post;
				}
			$trial_liability['trial_liability_reports'] = $trial_liability_array;
		}



	/*----- Trial Asset -----*/

	$trial_asset_query = "SELECT t.trial_balance_id as order_id, t.wpk_group_id as group_id, t.category_level, t.category_name as group_sub_group_name, t.opening_balance, t.debit as debit_amount, t.credit as credit_amount, t.closing_balance, t.previous_year_closing_balance FROM trial_balance AS t, groups AS g  WHERE t.wpk_group_id = g.wpk_group_id AND g.fo_id = '$field_agent_id' AND t.account_type_id = 2 ORDER BY t.trial_balance_id ASC";
	
	$trial_asset = array();
	$trial_asset_result = mysql_query($trial_asset_query, $link_client_downsync_database);
	if(mysql_num_rows($trial_asset_result))
		{
			while($post = mysql_fetch_object($trial_asset_result))
				{
					$trial_asset_array[] = $post;
				}
			$trial_asset['trial_assets_reports'] = $trial_asset_array;
		}

	
	
	
	/*----- Trial Income -----*/
	
	$trial_income_query = "SELECT t.trial_balance_id as order_id, t.wpk_group_id as group_id, t.category_level, t.category_name as group_sub_group_name, t.opening_balance, t.debit as debit_amount, t.credit as credit_amount, t.closing_balance, t.previous_year_closing_balance FROM trial_balance AS t, groups AS g  WHERE t.wpk_group_id = g.wpk_group_id AND g.fo_id = '$field_agent_id' AND t.account_type_id = 3 ORDER BY trial_balance_id ASC";
	
	$trial_income = array();
	$trial_income_result = mysql_query($trial_income_query, $link_client_downsync_database);
	if(mysql_num_rows($trial_income_result))
		{
			while($post = mysql_fetch_object($trial_income_result))
				{
					$trial_income_array[] = $post;
				}
			$trial_income['trial_income_reports'] = $trial_income_array;
		}
		
		


	/*----- Trial Expenses -----*/

	$trial_expenses_query = "SELECT t.trial_balance_id as order_id, t.wpk_group_id as group_id, t.category_level, t.category_name as group_sub_group_name, t.opening_balance, t.debit as debit_amount, t.credit as credit_amount, t.closing_balance, t.previous_year_closing_balance FROM trial_balance AS t, groups AS g  WHERE t.wpk_group_id = g.wpk_group_id AND g.fo_id = '$field_agent_id' AND t.account_type_id = 4 ORDER BY trial_balance_id ASC";
	
	$trial_expenses = array();
	$trial_expenses_result = mysql_query($trial_expenses_query, $link_client_downsync_database);
	if(mysql_num_rows($trial_expenses_result))
		{
			while($post = mysql_fetch_object($trial_expenses_result))
				{
					$trial_expenses_array[] = $post;
				}
			$trial_expenses['trial_expenses_reports'] = $trial_expenses_array;
		}
		
		
	/*----- Receipt Report -----*/
	
	$receipt_query = "SELECT v.wpk_voucher_id, v.wpk_group_id, v.voucher_date, v.voucher_number, v.particulars, v.narration FROM vouchers AS v, groups AS g WHERE g.fo_id = '$field_agent_id' AND v.voucher_type_id = 1 AND v.wpk_group_id = g.wpk_group_id";
	
	$receipt = array();
	$receipt_result = mysql_query($receipt_query, $link_client_downsync_database);
	if(mysql_num_rows($receipt_result) > 0)
		{
			while($post = mysql_fetch_object($receipt_result))
				{
					$receipt_array[] = $post;
				}
			$receipt['receipt'] = $receipt_array;
		}

	
	/*----- cashbook Report -----*/
	
	$cashbook_query = "SELECT v.wpk_voucher_id, v.wpk_group_id, v.voucher_date, v.voucher_number, v.particulars, v.narration FROM vouchers AS v, groups AS g WHERE g.fo_id = '$field_agent_id' AND v.particulars like 'cash%' AND v.wpk_group_id = g.wpk_group_id";
	
	$cashbook = array();
	$cashbook_result = mysql_query($cashbook_query, $link_client_downsync_database);
	if(mysql_num_rows($cashbook_result) > 0)
		{
			while($post = mysql_fetch_object($cashbook_result))
				{
					$cashbook_array[] = $post;
				}
			$cashbook['cashbook'] = $cashbook_array;
		}
                /*----- bankbook Report -----*/
	
	$bankbook_query = "SELECT v.wpk_voucher_id, v.wpk_group_id, v.voucher_date, v.voucher_number, v.particulars, v.narration FROM vouchers AS v, groups AS g WHERE g.fo_id = '$field_agent_id' AND v.particulars not like 'cash%' AND v.wpk_group_id = g.wpk_group_id";
	
	$bankbook = array();
	$bankbook_result = mysql_query($bankbook_query, $link_client_downsync_database);
	if(mysql_num_rows($bankbook_result) > 0)
		{
			while($post = mysql_fetch_object($bankbook_result))
				{
					$bankbook_array[] = $post;
				}
			$bankbook['bankbook'] = $bankbook_array;
		}
	
	/*----- Payment Report -----*/
	
	$payment_query = "SELECT v.wpk_voucher_id, v.wpk_group_id, v.voucher_date, v.voucher_number, v.particulars, v.narration FROM vouchers AS v, groups AS g WHERE g.fo_id = '$field_agent_id' AND v.voucher_type_id = 2 AND v.wpk_group_id = g.wpk_group_id";
	
	$payment = array();
	$payment_result = mysql_query($payment_query, $link_client_downsync_database);
	if(mysql_num_rows($payment_result))
		{
			while($post = mysql_fetch_object($payment_result))
				{
					$payment_array[] = $post;
				}
			$payment['payment'] = $payment_array;
		}	



	
	/*----- Par Report -----*/
	
	$par_reports_query = "SELECT p.par_reports_id, p.group_id, p.particulars_name_id, p.amount, p.percentage,p.current_year FROM par_reports AS p, groups AS g WHERE p.group_id = g.wpk_group_id AND g.fo_id = $field_agent_id";
	
	$par_reports = array();
	$par_reports_result = mysql_query($par_reports_query, $link_client_downsync_database);
	if(mysql_num_rows($par_reports_result))
		{
			while($post = mysql_fetch_object($par_reports_result))
				{
					$par_reports_array[] = $post;
				}
			$par_reports['par_reports'] = $par_reports_array;
	 	}
	 	
	 	
	
	
	
	/*----- Loan Outstanding Report -----*/	

	/*$loan_outstanding_reports_query = "SELECT o.loan_outstanding_report_id as auto_id, o.wpk_group_id as group_id, o.loan_category_name as product_purpose_id, o.disbursement_amount, o.outstanding_amount, o.outstanding_percentage FROM loan_outstanding_report AS o, groups AS g WHERE o.wpk_group_id = g.wpk_group_id AND o.field_agent_id = '$field_agent_id' AND o.status = 1";
	
	$loan_outstanding_reports = array();
	$loan_outstanding_reports_result = mysql_query($loan_outstanding_reports_query, $link_client_downsync_database);
	if(mysql_num_rows($loan_outstanding_reports_result))
		{
			while($post = mysql_fetch_object($loan_outstanding_reports_result))
				{
					$loan_outstanding_reports_array[] = $post;
				}
			$loan_outstanding_reports['loan_outstanding_reports'] = $loan_outstanding_reports_array;
		}*/


/*----- Customer Super Report for App-----*/	

	$loan_outstanding_reports_query = "SELECT `field_agent_id`,`group_id`,`from_level_id` as customer_id,`product_id`,`product_name`,`disburse_date`,`disburse_amount`,`opening_loan_outstanding`,`interest`,`ovedues`,`prepayment`,`amont_paid` as amount_paid,`closing_loan_outstanding` FROM $client_reports_database_name.crons_super_report WHERE `field_agent_id`= '$field_agent_id'";
	
	$loan_outstanding_reports = array();
	$loan_outstanding_reports_result = mysql_query($loan_outstanding_reports_query);
	if(mysql_num_rows($loan_outstanding_reports_result))
		{
			while($post = mysql_fetch_object($loan_outstanding_reports_result))
				{
					$loan_outstanding_reports_array[] = $post;
				}
			$loan_outstanding_reports['loan_outstanding_reports'] = $loan_outstanding_reports_array;
		}


	
	
	
	/*----- Tablet MFI Info -----*/
	
	$tablet_mfi_info = "SELECT mfi_name, contact_person_name, contact_person_designation, contact_mobile_no, total_groups, total_customers, no_of_customer_savings, no_of_customer_loan, no_of_subscription FROM tablet_mfi_info WHERE account_level = '1'";
 
	$tab_mfi_info = array();
	$tab_mfi_info_result = mysql_query($tablet_mfi_info, $link_client_downsync_database);
	if(mysql_num_rows($tab_mfi_info_result))
		{
			while($post = mysql_fetch_object($tab_mfi_info_result))
				{
					$tab_mfi_info_array[] = $post;
				}
			$tab_mfi_info['tab_mfi_info'] = $tab_mfi_info_array;
		}



	/*----- Tablet Field Agent Level Info -----*/

	$tablet_branch_info = "SELECT mfi_name as branch_name, contact_person_name, contact_person_designation, contact_mobile_no, total_groups, total_customers, no_of_customer_savings, no_of_customer_loan, no_of_subscription FROM tablet_mfi_info WHERE account_level = '$field_agent_account_level' AND account_level_id = '$field_agent_account_level_id'";
	$tab_branch_info = array();
	$tab_branch_info_result = mysql_query($tablet_branch_info, $link_client_downsync_database);
	if(mysql_num_rows($tab_branch_info_result))
		{
			while($post = mysql_fetch_object($tab_branch_info_result))
				{
					$tab_branch_info_array[] = $post;
				}
			$tab_branch_info['tab_branch_info'] = $tab_branch_info_array;
		} 

/*************Disbursement records from storage database****************/
	
         /********************************Demand report for customer****************/
               $demnad_for_customer_info = "SELECT * FROM $client_reports_database_name.crons_headoffice_demand_report WHERE fieldagent_id = '$field_agent_id' ";//
	$demand_customer_info = array();
	$demand_customer_info_result = mysql_query($demnad_for_customer_info, $link_client_downsync_database);
	if(mysql_num_rows($demand_customer_info_result))
		{
			while($post = mysql_fetch_object($demand_customer_info_result))
				{
					$demand_customer_info_array[] = $post;
				}
			$demand_customer_info['demand_customer_info'] = $demand_customer_info_array;
		} 
                
          /**********************/
                
	$final_arry = array_merge($account_leveldetails,$databasename, $mfi_info, $branch_info, $federation_info, $cluster_info, $bankdetails, $insurancdetails, $project_details,$donor_productdetails,  $field_agents, $village, $group,$customer,$log_group,$log_group_settings,$log_group_product_settings,$log_group_loan_product_sett,$log_internal_loan_disbursement,$log_group_meeting,$log_external_loan_request,$insurance_accountdetails,$fixdep_accountdetails,$loan_productdetails,$savings_accountdetails,$savings_accountdetails2,$savings_accountdetails3,$savings_accountdetails4,$savings_accountdetails_withd,$savings_accountdetails_withd_fix,$insure_accountdetails_withd5,$savings_productdetails,$savings_type,$fixed_deposit_productdetails,$insurance_productdetails, $subscription_productdetails,$messages, $loan_category,$loan_repayment_frequency, $transaction_mode,  $subscription_type,$internal_loan_schedule_info, $external_group_loan_schedule_info,$external_customer_loan_schedule_info,$field_agent_portfolio_report, $trial_liability,$trial_asset, $trial_income, $trial_expenses, $receipt,$cashbook,$bankbook, $payment, $par_reports,$loan_outstanding_reports,$tab_mfi_info, $tab_branch_info);//$ledger//,,,,,,,,,,,,, , , , , , , ,, , 
        //, $,,, 
          //  print_r($final_arry);
        //$final_arry = array_merge($account_leveldetails,$databasename , $mfi_info, $branch_info, $federation_info, $cluster_info,$bankdetails, $insurancdetails, $project_details, $donor_productdetails,  $field_agents, $village, $group,$log_group,$log_external_loan_request,$customer,$insurance_accountdetails,$fixdep_accountdetails,$loan_productdetails,$savings_accountdetails,$savings_accountdetails2,$savings_accountdetails3,$savings_accountdetails4,$savings_accountdetails_withd,$savings_accountdetails_withd_fix,$insure_accountdetails_withd5,$savings_productdetails,$savings_type,$fixed_deposit_productdetails, $insurance_productdetails, $subscription_productdetails);//,,$log_group_meeting,$external_customer_loan_schedule_info,, $messages, $loan_category, $loan_repayment_frequency, $transaction_mode,  $subscription_type, $internal_loan_schedule_info, $external_group_loan_schedule_info,  $field_agent_portfolio_report, $loan_outstanding_reports, $tab_mfi_info, $tab_branch_info,$demand_customer_info
        // ,, ,,
       // ,,
	$microfin =array(); 
	$microfin['Microfin'] = $final_arry;   
	//$microfin['Microfin'] ="asdfa";
	
	header("Content-type: application/json");
	echo print_r(json_encode($microfin),true);
?>

