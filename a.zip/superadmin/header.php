<?
ob_start();
session_start();
//echo "header";
include("../settings.php");
//include("../config/database_connection.php");
include("db_connect.php");
include("../config/functions.php");
//$microfin_functions_url = "/home/sjdtmbt/public_html/functions";
 //echo  $actual_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]".'dssdsfsfsfs';
require_once($microfin_functions_url ."/sms/demo_sms_history.php");
require_once($microfin_functions_url ."/email/demo_email_history.php");
if($_SESSION[global_user_id] != "")
{
    $actual_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
    $url_file_name = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']); 
    $skip_urls = array("start.php", "index.php", "final", "mail_link_page.php", "");
    if(!in_array($url_file_name, $skip_urls)) {  
        //echo "UPDATE global_users SET last_view_url = '$actual_url' WHERE global_user_id = '$_SESSION[global_user_id]'"; 
        $update_last_view_url = "UPDATE global_users SET last_view_url = '$actual_url' WHERE global_user_id = '$_SESSION[global_user_id]'";
        mysql_query($update_last_view_url, $link_microfinance_global) or die($msg_or_url = "Error : ".mysql_error());
    }
}
$password=str_shuffle("12345");

?>
<!DOCTYPE html>
<html>
  <head>
  <title>Microfinance.in</title>
  <link rel="icon" type="image/png" href="<?=$microfin_final_url;?>/themes/images/ek-microfin-favicon.png">
  <link rel="stylesheet" type="text/css" href="<?=$microfin_final_url;?>/themes/css/default.css" />
  <link href="<?=$microfin_final_url;?>/themes/css/bootstrap.css" rel="stylesheet">
  <link href="<?= $microfin_final_url ?>/themes/css/font-awesome.min.css" rel="stylesheet"> 
  <link href="<?=$microfin_final_url;?>/themes/css/one_fin_bootstrap.css" rel="stylesheet">
  <link href="<?=$microfin_final_url;?>/themes/css/bootstrap-theme.css" rel="stylesheet">
  <link href="<?=$microfin_final_url;?>/themes/css/includes/sidebar.css" rel="stylesheet">
  
  <script src="<?=$microfin_final_url?>/themes/js/jquery.js"></script>
  <link rel="stylesheet" href="<?=$microfin_final_url?>/themes/js/theme/jquery-ui.css">
  <script src="<?=$microfin_final_url?>/themes/js/ui/jquery-ui.js"></script>
  <script src="<?=$microfin_final_url?>/themes/js/bootstrap.js"></script>
  <script src="<?=$microfin_final_url?>/themes/js/validator/validator.js"></script> 
  <script src="<?=$microfin_final_url?>/themes/js/jqBootstrapValidation.js"></script>

  <style>

      img.btn_close {

	float: right;
    margin: -28px -28px 0 0;
}
.modalDialog {
	position: fixed;
	font-family: Arial, Helvetica, sans-serif;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	background: black;
	z-index: 99999;
	opacity:0;
	-webkit-transition: opacity 400ms ease-in;
	-moz-transition: opacity 400ms ease-in;
	transition: opacity 400ms ease-in;
	pointer-events: none;
        overflow:auto;
}
.modalDialog:target {
	opacity:1;

       	pointer-events: auto;
         overflow:auto;


}
 .tabsdemo input[type=radio] {
          position: absolute;
          top: -9999px;
          left: -9999px;
      }
      .tabsdemo {
        width: 650px;
        float: none;
        list-style: none;
        position: relative;
        padding: 0;
        margin: 75px auto;
      }
      .tabsdemo li{
        float: left;
      }

      .tabsdemo label {
          display: block;
          padding: 10px 20px;
          border-radius: 2px 2px 0 0;
          color: #08C;
          font-size: 24px;
          font-weight: normal;
          font-family: 'Lily Script One', helveti;
          background: #ccc;
          cursor: pointer;
          position: relative;
          top: 3px;
          -webkit-transition: all 0.2s ease-in-out;
          -moz-transition: all 0.2s ease-in-out;
          -o-transition: all 0.2s ease-in-out;
          transition: all 0.2s ease-in-out;
      }
      .tabsdemo label:hover {
        background: rgba(255,255,255,0.5);
        top: 0;
      }

      [id^=tabdemo]:checked + label {
        background: #08C;
        color: white;
        top: 0;
      }

      [id^=tabdemo]:checked ~ [id^=tabdemo-content] {
          display: block;
      }
      .tabdemo-content{
        z-index: 2;
        display: none;
        text-align: left;
        width: 100%;
        font-size: 20px;
        line-height: 140%;
        padding-top: 10px;
        background: #FFFFFF;
        padding: 15px;
        color: white;
        position: absolute;
        top: 53px;
        left: 0;
        box-sizing: border-box;
        -webkit-animation-duration: 0.5s;
        -o-animation-duration: 0.5s;
        -moz-animation-duration: 0.5s;
        animation-duration: 0.5s;
      }
      .clear {
    clear: both;
}
.web_dialog_overlay
{
   position: fixed;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;
   height: 100%;
   width: 100%;
   margin: 0;
   padding: 0;
   background: #000000;
   opacity: .15;
   filter: alpha(opacity=15);
   -moz-opacity: .15;
   z-index: 101;
   display: none;
}
.web_dialog
{
   display: none;
   position: fixed;
   width: 500px;
   height: 300px;
   top: 50%;
   left: 50%;
   margin-left: -190px;
   margin-top: -100px;
   background-color: #FFFFFF ;
   border: 2px solid #FFFFFF;
   padding: 0px;
   z-index: 102;
   font-family: Verdana;
   font-size: 10pt;
}
.web_dialog_title
{
   border-bottom: solid 2px #FFFFFF;
   background-color: #3399FF;
   padding: 4px;
   color: White;
   font-weight:bold;
}
.web_dialog_title a
{
   color: White;
   text-decoration: none;
}
.align_right
{
   text-align: right;
}
  </style>
  <script>
  $(document).ready(function(){
    $(function(){
	var shrinkHeader = 100;
	$(window).scroll(function() {
	    var scroll = getCurrentScroll();
	    if ( scroll >= shrinkHeader ) {
		$('.top').addClass('shrink');
	    } else {
		$('.top').removeClass('shrink');
	    }
	});
	
	function getCurrentScroll() {
	    return window.pageYOffset || document.documentElement.scrollTop;
	}
	
	window.setTimeout(function() {
	    $(".alert_status").fadeOut("slow");
	}, 5000);
	
	$(window).scroll(function() {
            if($(this).scrollTop() != 0)
                $('#toTop').fadeIn();	
            else
                $('#toTop').fadeOut();
        });
        $('#toTop').click(function() {
                $('body,html').animate({scrollTop:0},800);
        });
	
    });
    $(".modalDialog").show();
    //$('#error').hide();
    //$('#email_error').hide();
    //$('#mobile_error').hide();

$("#name_demo").on("input", function(){
  var regexpname = /[^a-z|^A-Z|^\s]/;
  if($(this).val().match(regexpname))
  {
      alert("Special characters & Numbers Not allowed");
    $(this).val( $(this).val().replace(regexpname,'') );
  }

});
$(document).on("focusout", "#email_demo", function(){

  var email_value = $(this).val();
  var reg = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
  var is_success = reg.test(email_value);

  if(!is_success){
    //$("#email_id").focus();
    alert("Please Enter Valid Email");
    return false;
  }
  else
      {
          //alert(email_value);
          var type='Only_email_validation';
          $.get("ajax_demo.php",{type:type,email_value:email_value},
                function (resp)
              {
               if(resp=='1')
                   {
                       $('#email_error').show();
                alert("Email Id already there-Please Login");
                return false;





                   }
                   else
                       {
                   $('#email_error').hide();
               return true;
                       }
      });
}

});
$(document).on("focusout", "#mobile_demo", function()
{

  var mobile_no = $(this).val();
          if (/^\d{10}$/.test(mobile_no))
        {
            //alert("value is ok");
            var type='Only_mobile_validation';
          $.get("ajax_demo.php",{type:type,mobile_no:mobile_no},
                function (resp)
              {
               if(resp=='1')
                   {
                       $('#mobile_error').show();
                alert("Mobile no already there-Please Login");
                //$("#mobile_demo").focus();
                return false;





                   }
                   else
                       {
                   $('#mobile_error').hide();
               return true;
                       }
      });
        }
  else
      {
          //$("#mobile_demo").focus();
    alert("Please Enter Valid Mobile No");
    return false;

}

});

    $("#org_demo").on("input", function(){
        //alert("fdf");
    var regexpname = /[^a-z|^A-Z|^\s]/;
  if($(this).val().match(regexpname))
  {
      alert("Special characters & Numbers Not allowed");
    $(this).val( $(this).val().replace(regexpname,'') );
  }

});
/*---------------------------Registration Submit----------------------------------------------*/
$("#check_submit").click(function (event)
      {
          //alert("dsds");
         var email_value = $("#email_demo").val();
         var name_demo=$("#name_demo").val();
         var org_demo=$("#org_demo").val();
         var password_demo=$("#password_demo").val();
         var confirmpassword_demo=$("#confirmpassword_demo").val();

         var mobile_no=$("#mobile_demo").val();
         //alert("----"+email_value);
         if(email_value =='' &&  mobile_no =='' && name_demo=='' && org_demo=='' && password_demo=='' && confirmpassword_demo=='' )//&& &&   && confirmpassword_demo==' '
         {

$('input[type="email"],input[type="text"],input[type="password"]').css("border","2px solid red");
$('input[type="email"],input[type="text"],input[type="password"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
         }
         else
             {

          if (password_demo != confirmpassword_demo)
        {

            alert("Password and Confirm Password should be same-Enter same Password") ;
           $("#confirmpassword_demo").val("");
           $("#confirmpassword_demo").focus();
           return false;
        }

             }
  /*-----------------------------------------Registeration submit--------------------------------------------------------*/

    //$client_id=
    event.preventDefault();
var password_val=$('#get_password').val();
          //alert(password_val);
          var type="Only_registration";
$.get("../ajax_demo.php",{type:type,email_value:email_value,name_demo:name_demo,mobile_no:mobile_no,org_demo:org_demo,password_demo:password_demo,confirmpassword_demo:confirmpassword_demo,password_val:password_val},
         //$.get("ajax_demo.php",
              function (resp)
              {
                  ShowDialog(true);
                  document.getElementById('display_text').innerHTML="Demo Login";
                    $('.plan_img').hide();
              $('#demo_email_mobile_check').hide();
              $("#openModal").hide();
              $('#login_actionsubmit').hide();
             $('#demo_onetime_check').show();
             $('#login_button').show();
              });
    //$sql="Insert into demo_users(First_name,org_name,email_id,mobile_number,password,onetime_password.login_from_time,status) values()"




});

/*----------------------------------------------------------Registration submit over----------------------------------------------*/
$("#btnShowModal").click(function (e)
      {
         ShowDialog(true);
         e.preventDefault();
      });

      $("#btnClose").click(function (e)
      {
         HideDialog();
         e.preventDefault();

      });
/*---------------------------Login Action---------------------------------------------------------------------------------------*/
                $('#login_demo').click(function(e)
                {
                     $('#error').hide();
                    //alert('login_Action');
                    var email_valuedemo = $("#email_demologin").val();

         var password_valuedemo=$("#password_demologin").val();

         if(email_valuedemo =='' && password_valuedemo=='')
         {

$('input[type="text"],input[type="password"]').css("border","2px solid red");
$('input[type="text"],input[type="password"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
}
else
    {
var reg = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
 if (!reg.test(email_valuedemo))
 {
     alert("Please Enter an Valid Email");
email_valuedemo.focus;
 return false;
}
e.preventDefault();
    var type="Only_Login_validation";
              $.get("../ajax_demo.php",{type:type,email_valuedemo:email_valuedemo,password_valuedemo:password_valuedemo},
         //$.get("ajax_demo.php",
              function (resp)
              {
             if(resp=='1')
                 {
                     //alert(resp);
                     window.location="demo.php";
                      $('#error').hide();
                 }
                 else
                     {
                         $('#error_forgot').hide();
                      $('#error').show();

                     document.getElementById('error').innerHTML="Sorry, we couldn't log you in with that email ID and password. Try again?";
                     $("#email_demologin").val("");
                     $("#password_demologin").val("");
                 }
              });
    }
                });


/*-----------------------------Login Action Over-----------------------------------------------------------------*/
/*-------------------------------------Forgot Password Login--------------------------------------------------*/
$('#forgot_password').click(function(e)
{
//alert('fff');
    ShowDialog(true);
    document.getElementById('display_text').innerHTML="Forgot Password";
      $('.plan_img').hide();
    $("#openModal").hide();

    $('#demo_onetime_check').hide();
    $('#login_button').hide();
    $('#demo_email_mobile_check').show();
    $('#login_actionsubmit').show();


$('#login_submit').click(function(e)
{
    var email_mobile_value=$('#email_mobiledemo').val();
    //alert(email_mobile_value);
    if(email_mobile_value=='')
        {
            $('input[type="text"]').css("border","2px solid red");
$('input[type="text"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
}
else
    {

    //alert("fff");
   e.preventDefault();
   var password_val=$('#get_password').val();
       var type='Forgot_password_validation';
        $.get("ajax_demo.php",{type:type,email_mobile_value:email_mobile_value,password_val:password_val},
    function (res)
{
    //alert(res);
    if(res=='1')
        {
            //alert("rer");
            $("#openModal").show();
            $('#error_forgot').show();
            $('#error').hide();
            return false;
            
        }
        else
{
                $('#error_email_mobile').show();
            $('#email_mobiledemo').val("");
}
});
    }
        });
        });
        $('#close').click(function()
        {
            $("#openModal").remove();
           var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
            //window.location.href="192.168.1.2/~microfinance/final/start.php";
        });
        $('#close1').click(function()
        {
            $("#openModal").remove();
           var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
            //window.location.href="192.168.1.2/~microfinance/final/start.php";
        });
    });


     function check_password()
      {
         var password1=document.getElementById('get_password').value;
        // alert(password1);
        var onetime_password= document.getElementById('onetimepassword').value;
        //alert(onetime_password);
        if(onetime_password==password1)
            {
                location.href="demo.php";
            }
            else
            {
                alert("Enter correct One Time Password");
            }

      }

   function ShowDialog(modal)
   {
      $("#overlay").show();
      $("#dialog").fadeIn(300);

      if (modal)
      {
         $("#overlay").unbind("click");
      }
      else
      {
         $("#overlay").click(function (e)
         {
            HideDialog();
         });
      }
   }

   function HideDialog()
   {
      $("#overlay").hide();
      $("#dialog").remove();
        $('.plan_img').show();
      var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
   }
 
  </script>
</head>
<body>
<div id="top" class="top">
    <div id="header">
        <div class="header_wrapper">
            <div class="logo" style="padding-top: 10px;">
                <a href="index.php" style="min-height: 100px;" ><img src="<?= $microfin_final_url; ?>/themes1/images/logo.png"></a>
            </div>
            <div class="logo-small" style="padding-top: 10px;">
                <a href="index.php"><img src="<?= $microfin_final_url; ?>/themes1/images/logo.png" /></a>
            </div>
            <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-right: 0px;">
                <div class="top_menu" style="margin-top: 20px;">
                    <div style="float: right; height: 30px; padding-top: 5px; padding-right: 15px;">
			<?php if(!$_SESSION['global_user_id']) { ?>
			    <a style="color:#EA1D25;" href="<?=$microfin_final_url?>superadmin/start.php">Sign in </a> &nbsp; | &nbsp; <a style="color:#EA1D25;" href="<?=$microfin_final_url?>start.php">Sign Up </a>
			<?php } else { ?>
			    <a style="color:#EA1D25;" href="<?=$microfin_final_url?>logout.php">Logout </a>
			<?php } ?>
                    </div>
                    <div class="clear"></div>
                    <ul class="nav navbar-nav menu" style="margin-top: 5px;">
			<li <?if($cur_file_name == "index.php"){?>class='active'<?}?>><a href="<?=$microfin_final_url?>index.php">Home</a> </li>
			<li <?if($cur_file_name == "about.php"){?>class='active'<?}?>><a href="<?=$microfin_final_url?>about.php">About</a></li>
			<?
                        /*if($demo_user_login_id=="")
                        {?>
			<li <?if($cur_file_name == ""){?>class='active'<?}?>><a href="#openModal">Demo</a></li>
                        <?}  else
                            {?> <li <?if($cur_file_name == "demo.php"){?>class='active'<?}?>><a href="demo.php">Demo</a></li>
                        <?}*/?>
			<li <?if($cur_file_name == "contact.php"){?>class='active'<?}?>><a href="<?=$microfin_final_url?>contact.php">Contact</a></li>
			<!---li <?if($cur_file_name == "support.php"){?>class='active'<?}?>><a href="support.php">Support</a></li-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
        
        

       <!-----------------------------------------Demo Login Page-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->



<div id="openModal" class="modalDialog">
    <div class="contain">

<ul class="tabsdemo" >

        <li>
          <input type="radio" checked name="tabsdemo" id="tabdemo1">
          <label for="tabdemo1">Login</label>
          <div id="tabdemo-content1" class="tabdemo-content animated fadeIn">
              <form class="form-horizontal" id="demo_loginform" method="post">
<div id="demo_email_check"class="form-group">
     <a id="close"  style="padding-left:580px;">close</a>
							    <div class="col-md-6" style="padding-top:50px;">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="text" placeholder="Enter Email Id" name="email_demologin" id="email_demologin" class="form-control checkrecords">
								    </div>

							    </div>
						    </div>
              <div class="clear"></div>
              <br>

              <div id="demo_email_password"class="form-group">
							    <div class="col-md-6">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Enter Password" name="password_demologin" id="password_demologin" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
              <br>
               <div id="login_action" class="form-group" style="padding:5px;">
							    <div class="col-md-5">
								    <button type="submit" class="btn btn-lg btn-default" name="login_demo" value="Login" id="login_demo" style="margin-left:-5px; margin-bottom: 5px;">Login</button>
							    </div>
                              <div class="col-md-6">
                              <a  id="forgot_password" style="color:red;">Forgot Password?</a>
                              </div>
                   <div class="clear"></div>
			<div id="error"  style="font-size:15px;background:#980000  ;color:white; margin-left: 10px; display:none;" >Enter registered Email ID (Or) Mobile Number</div>
                        <div  id="error_forgot" style="font-size:15px;background:#009933  ;color:white; margin-left: 10px; display:none;" >Email Id sent to your registered Mobile no/E-mail Id</div>

                          </div>
              </form>
          </div>
        </li>

        <!-----------------------------------------Demo Registration Page-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->
        <li>
          <input type="radio" name="tabsdemo" id="tabdemo2">
          <label for="tabdemo2">Register</label>
                    <div id="tabdemo-content2" class="tabdemo-content animated fadeIn">
                        <form class="form-horizontal" id="demo_registerform" method="post">
                        <div id="demo_name_check"class="form-group">
                             <a id="close1"  style="padding-left:580px;">close</a>
							    <div class="col-md-12" style="padding-top:50px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									    <input type="text" placeholder="Enter Full Name" name="name_demo" id="name_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                             <div id="demo_org_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-cog"></i></span>
									    <input type="text" placeholder="Enter Organization Name" name="org_demo" id="org_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_email_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="email" placeholder="Enter Email Id" name="email_demo" id="email_demo"  class="form-control checkrecords">
								    </div>
                                                                <div id="email_error" class="text-danger" style="display:none;">Email Id is already there</div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                         <div id="demo_email_password"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Enter Password" name="password_demo" id="password_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_email_confirmpassword"class="form-group" style="padding-top:5px;">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Confirm Password" name="confirmpassword_demo" id="confirmpassword_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_mobile_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
									    <input type="text" placeholder="Enter Mobile No" name="mobile_demo" id="mobile_demo"class="form-control checkrecords" >
								    </div>
                                                                 <div id="mobile_error"  class="text-danger" style="display:none;">Mobile No is already there</div>

							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <input type="text" id="get_password" name="hidden_input" value="<?=$password;?>" hidden/>
           <div id="submit_button" class="form-group" style="padding-top:5px; ">
							    <div class="col-md-12">
								    <button type="submit" class="btn btn-lg btn-default" name="submit_btn" value="submit" id="check_submit"  style="margin-left:-5px; margin-bottom: 5px;" >Submit</button>
							    </div>


						    </div>
                        </form>
          </div>
        </li>

</ul>
</div>
    </div>


  <!-----------------------------------------One TIme Password Generation-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->
 <div id="overlay" class="web_dialog_overlay"></div>

<div id="dialog" class="web_dialog">


       <form name="demo_login_form"  method ="post">
   <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
      <tr>
         <td class="web_dialog_title"><div id="display_text"></div></td>
         <td class="web_dialog_title align_right">
            <a href="#" id="btnClose">close</a>
         </td>
      </tr>
      <tr>
          <td >
              <div id="demo_onetime_check" class="form-group" style="display:none;">
							    <div class="col-md-12" style="padding-top:50px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="text" placeholder="Enter One Time Password" name="onetimepassword" id="onetimepassword" class="form-control">
								    </div>

							    </div>
						    </div>
          </td>
      </tr>

      <tr>
          <td >
                          <div id="login_button" class="form-group" style="padding:5px; display:none;">
							    <div class="col-md-12">
								    <button type="button" class="btn btn-lg btn-default" name="login_btn" value="Login" onclick="check_password()" id="check_login" style="margin-left:-5px; margin-bottom: 5px;" id="login_btn" >Login</button>
							    </div>


						    </div>
          </td>

      </tr>
      <tr>

          <td style="padding-top:30px;">
         <div id="demo_email_mobile_check"class="form-group" style="padding-top: 10px;display:none;">
							    <div class="col-md-12">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="text" placeholder="Enter Email Id or Mobile No" name="email_mobiledemo" id="email_mobiledemo" class="form-control checkrecords">
								    </div>
							    </div>
             <div id="error_email_mobile" class="text-danger" style="display:none;">Enter Valid Email-Id /Mobile No</div>
						    </div>
          </td>
      </tr>
      <tr>
          <td >
                          <div id="login_actionsubmit" class="form-group" style="padding-top:15px;" style="display:none;">
							    <div class="col-md-8">
								    <button type="submit" class="btn btn-lg btn-default" name="login_submit" value="Submit" id="login_submit" style="margin-left:-5px; margin-bottom: 5px;">Submit</button>
							    </div>
                              <div class="col-md-6">

                              </div>

                          </div>

          </td>

      </tr>




   </table>
       </form>
</div>