    </div>
	<div id="footer">
		<div class="container text-center">
		  <p class="text-muted credit"><a href="http://www.ekgaon.com/" target="_blank" style="color: #777">ekgaon</a> one village one world network</p>
		</div>
	</div>
	<div id="toTop"><span class="glyphicon glyphicon-chevron-up"></span></div>
  </body>
</html>
