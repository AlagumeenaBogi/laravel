<?php
    session_start();
    $cur_file_name = basename($_SERVER['PHP_SELF']);
    include("db_connect.php");
    $password=str_shuffle("12345");
     // $microfin_final_url       = "http://192.168.1.12/~sjdtmbt/";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Ekgaon Microfinance</title>
        <link rel="icon" type="image/png" href="<?= $microfin_final_url; ?>/themes/images/ek-microfin-favicon.png">
        <!-- Bootstrap Core CSS -->
        <link href="<?= $microfin_final_url; ?>/themes1/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= $microfin_final_url; ?>/themes1/css/microfinance.css" rel="stylesheet">
        <link href="header_demo.css" rel="stylesheet">
        <!-- Custom CSS -->
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->
        <link href="<?= $microfin_final_url; ?>/themes1/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <script src="<?=$microfin_final_url?>/themes/js/jquery.js"></script>
        <script type="text/javascript">

   $(document).ready(function ()
   {

    //alert("eee");
    //$('link#style').attr('href', 'header_demo.css');
    // $("#cover").show();
    $(".modalDialog").show();
    //$('#error').hide();
    //$('#email_error').hide();
    //$('#mobile_error').hide();

$("#name_demo").on("input", function(){
  var regexpname = /[^a-z|^A-Z|^\s]/;
  if($(this).val().match(regexpname))
  {
      alert("Special characters & Numbers Not allowed");
    $(this).val( $(this).val().replace(regexpname,'') );
  }

});

$(document).on("focusout", "#email_demo", function(){

  var email_value = $(this).val();
  var reg = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
  var is_success = reg.test(email_value);

  if(!is_success){
    //$("#email_id").focus();
    alert("Please Enter Valid Email");
    return false;
  }
  else
      {
          //alert(email_value);
          var type='Only_email_validation';
          $.get("ajax_demo.php",{type:type,email_value:email_value},
                function (resp)
              {
               if(resp=='1')
                   {
                       $('#email_error').show();
                alert("Email Id already there-Please Login");
                return false;





                   }
                   else
                       {
                   $('#email_error').hide();
               return true;
                       }
      });
}

});
$(document).on("focusout", "#mobile_demo", function(){

  var mobile_no = $(this).val();
          if (/^\d{10}$/.test(mobile_no))
        {
            //alert("value is ok");
            var type='Only_mobile_validation';
          $.get("ajax_demo.php",{type:type,mobile_no:mobile_no},
                function (resp)
              {
               if(resp=='1')
                   {
                       $('#mobile_error').show();
                alert("Mobile no already there-Please Login");
                //$("#mobile_demo").focus();
                return false;





                   }
                   else
                       {
                   $('#mobile_error').hide();
               return true;
                       }
      });
        }
  else
      {
          //$("#mobile_demo").focus();
    alert("Please Enter Valid Mobile No");
    return false;

}

});

   $("#org_demo").on("input", function(){
        //alert("fdf");
    var regexpname = /[^a-z|^A-Z|^\s]/;
  if($(this).val().match(regexpname))
  {
      alert("Special characters & Numbers Not allowed");
    $(this).val( $(this).val().replace(regexpname,'') );
  }

});
/*---------------------------Registration Submit----------------------------------------------*/
$("#check_submit").click(function (event)
      {
          //alert("dsds");
         var email_value = $("#email_demo").val();
         var name_demo=$("#name_demo").val();
         var org_demo=$("#org_demo").val();
         var password_demo=$("#password_demo").val();
         var confirmpassword_demo=$("#confirmpassword_demo").val();

         var mobile_no=$("#mobile_demo").val();
         //alert("----"+email_value);
         if(email_value =='' &&  mobile_no =='' && name_demo=='' && org_demo=='' && password_demo=='' && confirmpassword_demo=='' )//&& &&   && confirmpassword_demo==' '
         {

$('input[type="email"],input[type="text"],input[type="password"]').css("border","2px solid red");
$('input[type="email"],input[type="text"],input[type="password"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
         }
         else
             {

          if (password_demo != confirmpassword_demo)
        {

            alert("Password and Confirm Password should be same-Enter same Password") ;
           $("#confirmpassword_demo").val("");
           $("#confirmpassword_demo").focus();
           return false;
        }

             }
  /*-----------------------------------------Registeration submit--------------------------------------------------------*/

    //$client_id=
    event.preventDefault();
var password_val=$('#get_password').val();
          //alert(password_val);
          var type="Only_registration";
$.get("ajax_demo.php",{type:type,email_value:email_value,name_demo:name_demo,mobile_no:mobile_no,org_demo:org_demo,password_demo:password_demo,confirmpassword_demo:confirmpassword_demo,password_val:password_val},
         //$.get("ajax_demo.php",
              function (resp)
              {
                  ShowDialog(true);
                  document.getElementById('display_text').innerHTML="Demo Login";
              $('#demo_email_mobile_check').hide();
              $("#openModal").hide();
             $('#login_actionsubmit').hide();
             $('#demo_onetime_check').show();
             $('#login_button').show();
              });
    //$sql="Insert into demo_users(First_name,org_name,email_id,mobile_number,password,onetime_password.login_from_time,status) values()"




});

/*----------------------------------------------------------Registration submit over----------------------------------------------*/
$("#btnShowModal").click(function (e)
      {
         ShowDialog(true);
         e.preventDefault();
      });

      $("#btnClose").click(function (e)
      {
         HideDialog();
         e.preventDefault();
      });
/*---------------------------Login Action---------------------------------------------------------------------------------------*/
                $('#login_demo').click(function(e)
                {
                     $('#error').hide();
                    //alert('login_Action');
                    var email_valuedemo = $("#email_demologin").val();

         var password_valuedemo=$("#password_demologin").val();

         if(email_valuedemo =='' && password_valuedemo=='')
         {

$('input[type="text"],input[type="password"]').css("border","2px solid red");
$('input[type="text"],input[type="password"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
}
else
    {
var reg = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
 if (!reg.test(email_valuedemo))
 {
     alert("Please Enter an Valid Email");
email_valuedemo.focus;
 return false;
}
e.preventDefault();
    var type="Only_Login_validation";
              $.get("ajax_demo.php",{type:type,email_valuedemo:email_valuedemo,password_valuedemo:password_valuedemo},
         //$.get("ajax_demo.php",
              function (resp)
              {
             if(resp=='1')
                 {
                     //alert(resp);
                     window.location="demo.php";
                      $('#error').hide();
                 }
                 else
                     {
                         $('#error_forgot').hide();
                      $('#error').show();

                     document.getElementById('error').innerHTML="Sorry, we couldn't log you in with that email ID and password. Try again?";
                     $("#email_demologin").val("");
                     $("#password_demologin").val("");
                 }
              });
    }
                });


/*-----------------------------Login Action Over-----------------------------------------------------------------*/
/*-------------------------------------Forgot Password Login--------------------------------------------------*/
$('#forgot_password').click(function(e)
{
//alert('fff');
    ShowDialog(true);
    document.getElementById('display_text').innerHTML="Forgot Password";
    $("#openModal").hide();
    $('#demo_onetime_check').hide();
    $('#login_button').hide();
    $('#demo_email_mobile_check').show();
    $('#login_actionsubmit').show();


$('#login_submit').click(function(e)
{
    var email_mobile_value=$('#email_mobiledemo').val();
    //alert(email_mobile_value);
    if(email_mobile_value=='')
        {
            $('input[type="text"]').css("border","2px solid red");
$('input[type="text"]').css("box-shadow","0 0 3px red");
alert("Please fill all fields...!!!!!!");
return false;
}
else
    {

    //alert("fff");
   e.preventDefault();
   var password_val=$('#get_password').val();
       var type='Forgot_password_validation';
        $.get("ajax_demo.php",{type:type,email_mobile_value:email_mobile_value,password_val:password_val},
    function (res)
{
    //alert(res);
    if(res=='1')
        {
            $("#openModal").show();
            $('#error_forgot').show();
            $('#error').hide();
           /// HideDialog();
        }
        else

                $('#error_email_mobile').show();
            $('#email_mobiledemo').val("");
});
    }
        });
        });
        $('#close').click(function()
        {
            $("#openModal").remove();
           var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
            //window.location.href="192.168.1.2/~microfinance/final/start.php";
        });
        $('#close1').click(function()
        {
            $("#openModal").remove();
           var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
            //window.location.href="192.168.1.2/~microfinance/final/start.php";
        });
});


     function check_password()
      {
         var password1=document.getElementById('get_password').value;
        // alert(password1);
        var onetime_password= document.getElementById('onetimepassword').value;
        //alert(onetime_password);
        if(onetime_password==password1)
            {
                location.href="http://192.168.1.2/~microfinance/final/demo.php";
            }
            else
            {
                alert("Enter correct One Time Password");
            }

      }

   function ShowDialog(modal)
   {
      $("#overlay").show();
      $("#dialog").fadeIn(300);

      if (modal)
      {
         $("#overlay").unbind("click");
      }
      else
      {
         $("#overlay").click(function (e)
         {
            HideDialog();
         });
      }
   }

    function HideDialog()
   {
      $("#overlay").hide();
      $("#dialog").remove();
        $('.plan_img').show();
      var loc = window.location.href,
    index = loc.indexOf('#');

if (index > 0) {
  window.location = loc.substring(0, index);
}
   }
</script>
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container" style="padding-right: 0px;">
                    <!--div style="height: 50px; border: 1px solid red;"></div-->
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="<?=$microfin_final_url?>/index.php"><img src="<?= $microfin_final_url; ?>/themes1/images/logo.png"></a>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <div class="top_menu">
                                    <div style="float: right; height: 30px; padding-top: 5px; padding-right: 15px;">
                                        <?php if(!$_SESSION['global_user_id']) { ?>
                                            <a style="color:#EA1D25;" href="start.php">Sign in </a> &nbsp; | &nbsp; <a style="color:#EA1D25;" href="start.php">Sign Up </a>
                                        <?php } else { ?>
                                            <a style="color:#EA1D25;" href="logout.php">Logout </a>
                                        <?php } ?>
                                    </div>
                                    <div class="Clear"></div>
                                    <ul class="nav navbar-nav menu">
                                            <li <?if($cur_file_name == "index.php"){?>class='active'<?}?>><a href="index.php">Home</a> </li>
                                            <li <?if($cur_file_name == "about.php"){?>class='active'<?}?>><a href="about.php">About</a></li>
                                          <?
                       /* if($_SESSION['demo_user_login_id']=="")
                        {?>
			<li <?if($cur_file_name == "demo.php"){?>class='active'<?}?>><a href="#openModal">Demo</a></li>
                        <?}  else{?>
                            <li <?if($cur_file_name == "demo.php"){?>class='active'<?}?>><a href="demo.php">Demo</a></li>
                        <?}*/?>

                                            <li <?if($cur_file_name == "contact.php"){?>class='active'<?}?>><a href="contact.php">Contact</a></li>
                                            <!---li <?if($cur_file_name == "support.php"){?>class='active'<?}?>><a href="support.php">Support</a></li--->
                                    </ul>
                            </div>
                    </div>
                    <div class="Clear"></div>
                    <!-- /.navbar-collapse -->
            </div>
                <!-- /.container -->
        </nav>
        <!-- Page Content -->




         <!-----------------------------------------Demo Login Page-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->



<div id="openModal" class="modalDialog" style="display:none;">
    <div class="contain">

<ul class="tabs" >

        <li>
          <input type="radio" checked name="tabs" id="tab1">
          <label for="tab1">Login</label>
          <div id="tab-content1" class="tab-content animated fadeIn">
              <form class="form-horizontal" id="demo_loginform" method="post">
<div id="demo_email_check"class="form-group">
     <a id="close"  style="padding-left:580px;">close</a>
							    <div class="col-md-6" style="padding-top:50px;">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="text" placeholder="Enter Email Id" name="email_demologin" id="email_demologin" class="form-control checkrecords">
								    </div>

							    </div>
						    </div>
              <div class="clear"></div>
              <br>

              <div id="demo_email_password"class="form-group">
							    <div class="col-md-6">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Enter Password" name="password_demologin" id="password_demologin" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
              <br>
               <div id="login_action" class="form-group" style="padding:5px;">
							    <div class="col-md-5">
								    <button type="submit" class="btn btn-lg btn-default" name="login_demo" value="Login" id="login_demo" style="margin-left:-5px; margin-bottom: 5px;">Login</button>
							    </div>
                              <div class="col-md-6">
                              <a  id="forgot_password" style="color:red;">Forgot Password?</a>
                              </div>
                   <div class="clear"></div>
			<div id="error"  style="font-size:15px;background:#FF0000 ;color:white; margin-left: 10px; display:none;" >Enter registered Email ID (Or) Mobile Number</div>
                        <div  id="error_forgot" style="font-size:15px;background:#33FF99 ;color:black; margin-left: 10px; display:none;" >Email Id sent to your registered Mobile no/E-mail Id</div>

                          </div>
              </form>
          </div>
        </li>

        <!-----------------------------------------Demo Registration Page-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->
        <li>
          <input type="radio" name="tabs" id="tab2">
          <label for="tab2">Register</label>
                    <div id="tab-content2" class="tab-content animated fadeIn">
                        <form class="form-horizontal" id="demo_registerform" method="post">
                        <div id="demo_name_check"class="form-group">
                             <a id="close1"  style="padding-left:580px;">close</a>
							    <div class="col-md-12" style="padding-top:50px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									    <input type="text" placeholder="Enter Full Name" name="name_demo" id="name_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                             <div id="demo_org_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-cog"></i></span>
									    <input type="text" placeholder="Enter Organization Name" name="org_demo" id="org_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_email_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="email" placeholder="Enter Email Id" name="email_demo" id="email_demo"  class="form-control checkrecords">
								    </div>
                                                                <div id="email_error" class="text-danger" style="display:none;">Email Id is already there</div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                         <div id="demo_email_password"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Enter Password" name="password_demo" id="password_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_email_confirmpassword"class="form-group" style="padding-top:5px;">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="password" placeholder="Confirm Password" name="confirmpassword_demo" id="confirmpassword_demo" class="form-control checkrecords">
								    </div>
							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <div id="demo_mobile_check"class="form-group">
							    <div class="col-md-12" style="padding-top:5px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>
									    <input type="text" placeholder="Enter Mobile No" name="mobile_demo" id="mobile_demo"class="form-control checkrecords" >
								    </div>
                                                                 <div id="mobile_error"  class="text-danger" style="display:none;">Mobile No is already there</div>

							    </div>
						    </div>
                        <div class="clear"></div>
                        <br>
                        <input type="text" id="get_password" name="hidden_input" value="<?=$password;?>" hidden/>
           <div id="submit_button" class="form-group" style="padding-top:5px; ">
							    <div class="col-md-12">
								    <button type="submit" class="btn btn-lg btn-default" name="submit_btn" value="submit" id="check_submit"  style="margin-left:-5px; margin-bottom: 5px;" >Submit</button>
							    </div>


						    </div>
                        </form>
          </div>
        </li>

</ul>
</div>
    </div>


  <!-----------------------------------------One TIme Password Generation-------------------------------------------

  *
  *--------------------------------------------------------------------------------------------------------------------->
 <div id="overlay" class="web_dialog_overlay"></div>

<div id="dialog" class="web_dialog">


       <form name="demo_login_form"  method ="post">
   <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
      <tr>
         <td class="web_dialog_title"><div id="display_text"></div></td>
         <td class="web_dialog_title align_right">
            <a href="#" id="btnClose">close</a>
         </td>
      </tr>
      <tr>
          <td >
              <div id="demo_onetime_check" class="form-group" style="display:none;">
							    <div class="col-md-12" style="padding-top:50px;">
								    <div class="input-group">
									    <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
									    <input type="text" placeholder="Enter One Time Password" name="onetimepassword" id="onetimepassword" class="form-control">
								    </div>

							    </div>
						    </div>
          </td>
      </tr>

      <tr>
          <td >
                          <div id="login_button" class="form-group" style="padding:5px; display:none;">
							    <div class="col-md-12">
								    <button type="button" class="btn btn-lg btn-default" name="login_btn" value="Login" onclick="check_password()" id="check_login" style="margin-left:-5px; margin-bottom: 5px;" id="login_btn" >Login</button>
							    </div>


						    </div>
          </td>

      </tr>
      <tr>

          <td style="padding-top:30px;">
         <div id="demo_email_mobile_check"class="form-group" style="padding-top: 10px;display:none;">

							    <div class="col-md-12">
								    <div class="input-group">
									   <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									    <input type="text" placeholder="Enter Email Id or Mobile No" name="email_mobiledemo" id="email_mobiledemo" class="form-control checkrecords">
								    </div>
							    </div>
             <div id="error_email_mobile" class="text-danger" style="display:none;">Enter Valid Email-Id /Mobile No</div>
						    </div>
          </td>
      </tr>
      <tr>
          <td >
                          <div id="login_actionsubmit" class="form-group" style="padding-top:15px;" style="display:none;">
							    <div class="col-md-8">
								    <button type="submit" class="btn btn-lg btn-default" name="login_submit" value="Submit" id="login_submit" style="margin-left:-5px; margin-bottom: 5px;">Submit</button>
							    </div>
                              <div class="col-md-6">

                              </div>

                          </div>

          </td>

      </tr>




   </table>
       </form>
</div>
