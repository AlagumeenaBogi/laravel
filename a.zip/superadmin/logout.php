<?
	ob_start();
	session_start();
	include("../config/database_connection.php");
        echo "--URL--->".$microfin_final_url."<BR>";
	$user_id = $_SESSION['global_user_id'];
	$ip_address = $_SERVER['REMOTE_ADDR'];
	$current_time = time();
	mysql_query("INSERT INTO login_history (global_user_id, log_type_id, ip_address, time) VALUES ('$user_id', '2', '$ip_address', '$current_time')", $link_microfinance_global);
	
	$_SESSION['client_id'] = "";
	$_SESSION['global_user_id'] = "";
	session_unset();
	header("Location:".$microfin_final_url."/superadmin/start.php");
//	header("Location:".$microfin_final_url."/start.php");
	
?>
