<?
include("../../dash_header.php");
$report_name='LOAN PRODUCT PERFORMANE MONITORING REPORT';
?>
<script>
function generate_lppr(pids,mbtids,bids,fdate,tdate) { /*--new_cron_function*/
//alert(pids+"---"+mbtids+"---"+bids);
var pid=$("#"+pids).val();
var mbtid=$("#"+mbtids).val();
var bid=$("#"+bids).val();
//alert(pid+"---"+mbtid+"---"+bid);
if(mbtid == "") {
	alert("Please select the MBT");
	return false;
}
if(bid == "") {
	alert("Please Select the Branch");
	return false;
}
if(pid == "") {
	alert("Please select the Loan product");
	return false;
}
//var rand=Math.random();
 setTimeout(function(){   document.getElementById("ajaxloader").style.display="block";}, 10);
	$.get('loan_performance_ajax.php',{productid:pid,fromdate:fdate,todate:tdate,bid:bid,mbtid:mbtid},
		function (resp) {
		//alert(resp);
               
                 if(resp != '')
                    {
                        
			document.getElementById('divlevel').innerHTML = resp;
                      document.getElementById("ajaxloader").style.display="none";
                    }
               else
                   {
                      alert("Please Select the Current Financial Year and not generated the cron this year.");
                   }
                  
	     }
	);


}
</script>
<div class="page-content inset">
	
    <div class="row">
	
	<div class="col-md-12">
		<ol class="breadcrumb">
                        <li><a href="#">Dashboard</a></li>
                        <li><a href="#">Reports</a> </li>
                        <li class="active"><?=$report_name;?></li>
                    </ol>
	</div>
	
	<div class="col-md-12">
		<div class="alert alert-info alert-dismissible" role="alert">
		    Please You Can View the <?=$report_name;?>.
		</div>
	</div>
	<div class="col-sm-3 clear-right-padding">
			<? include ("left_menu_reports.php"); ?>
	</div>
	<div class="col-sm-9">
	        <div class="well">
	         <form class="form-horizontal" method="post" name="loan_ledger_rep_form" id="loan_ledger_rep_form">
			<h2 class="view-info-underline"><?=$report_name;?></h2>
<!------------------------ MBT Type creation----------------------------------------------------------------------->
<div class="col-sm-12">
    <div class="col-sm-3">
        <label class="control-label"> <b>Select the MBT Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <select class="form-control" name="mbt_type" id="mbt_type">
            <option value="">Select MBT Name</option>
            <option value="0">All MBT</option>
            <?php
            $fd = mysql_query("SELECT * FROM mfi_registration WHERE mfistatus=1 AND status=1");
            $count=mysql_num_rows($fd);
            if($count >0)
            {
                while($res = mysql_fetch_object($fd)) {
                echo "<option value='".$res->iid."'>".str_replace("-"," ",$res->mfiname)."</option>";
                }
                mysql_free_result($fd);
            }
            ?>
        </select>
    </div>
</div>
<br><br><br>

<!-----------------------------------MBT type created--------------------------------------------------------------------->

<!------------------------ Level Type creation----------------------------------------------------------------------->


<div class="col-sm-12">
    <div class="col-sm-3">
     <label class="control-label"> <b>Select the Branch Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <select class="form-control" name="level_type" id="level_type">
        <option value=" ">Select Level</option>
        <option value="0">All Branches</option>
        <?php
        $fd = mysql_query("SELECT bid,branchofficename FROM sjdt1_alagumeena.branch_registration WHERE approve_status=1 AND status=1 AND bid in (2024,2022,2021,2008,2007,2001)");
        while($res = mysql_fetch_object($fd)) {
        echo "<option value='".$res->bid."'>".str_replace("-"," ",$res->branchofficename)."</option>";
        }
        mysql_free_result($fd);
        ?>
        </select>
    </div>
</div><BR><BR><BR>
<!-----------------------------------level type created--------------------------------------------->
<!------------------------ Product Type creation----------------------------------------------------------------------->
<div class="col-sm-12">
    <div class="col-sm-3">
    <label class="control-label"> <b>Select the Product Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
    <select class="form-control" name="product_type" id="product_type" >
    <option value="">Select Products </option>
    <option value="0">All Products</option>
   <?php
	$pnames = mysql_query("SELECT * FROM sjdt1_alagumeena.loan_purpose");
	while($res=mysql_fetch_object($pnames)){
		echo "<option value='".$res->id."'>".$res->purposename."</option>";
	}
	mysql_free_result($pnames);

    ?>

    </select>
    </div>
</div><BR><BR><BR>
<!---div class="container">			
                        <button class="btn btn-primary btn-lg ladda-button" data-style="expand-right" data-size="l" ><span class="ladda-label">large</span></button>
		</div-->
<!-----------------------------------Product type created--------------------------------------------------------------------->
                            <div class="col-sm-12">
                            <div class="col-sm-3"></div>
                            <div class="col-sm-6">
                            <!--button  type="button" class="btn btn-primary btn-lg" onclick="generate_lppr(document.getElementById('product_type').value,document.getElementById('mbt_type').value,document.getElementById('level_type').value,'','');">GO</button--->
                            <a href="#" class="btn btn-default btn-lg"  onclick="return generate_lppr('product_type','mbt_type','level_type','','');">Show Report</a>
                            </div>
                            <div class="col-sm-3"></div>
                            </div><BR><BR><BR>
<!-----------------------------------BUTTON--------------------------------------------------------------------->

                <div id="ajaxloader" style=" display: none;">
                    <div  align="center">
                        <img src="<?=$microfin_application_url;?>/themes/images/ajax-loader.gif" width="54" height="55"><br /><br />
                        <span >Please wait loading reports..</span>
                    </div>
                </div>
<!-----------------------------------LOADER--------------------------------------------------------------------->

            <div class="row">
            <div class="col-md-12">
            <div id="divlevel">
                
            </div>

            </div>
            </div>

		 </form>
		 
	        </div>
	</div>	
    </div>
</div>	

<!----script src=<?=$microfin_application_url;?>"/loader/dist/spin.min.js"></script>
<script src=<?=$microfin_application_url;?>"/loader/dist/ladda.min.js"></script>
<script>
// Bind normal buttons
Ladda.bind( 'div:not(.progress-demo) button', { timeout: 2000 } );
// Bind progress buttons and simulate loading progress
Ladda.bind( '.progress-demo buttons', {
callback: function( instance ) {
    var progress = 0;
    var interval = setInterval( function() {
            progress = Math.min( progress + Math.random() * 0.1, 1 );
            instance.setProgress( progress );

            if( progress === 1 ) {
                    instance.stop();
                    clearInterval( interval );
            }
    }, 200 );
}
} );

</script--->
<!---link rel="stylesheet" href=<?=$microfin_application_url;?>"/loader/dist/ladda-themeless.min.css">
<link rel="stylesheet" href=<?=$microfin_application_url;?>"/loader/css/prism.css"-->
<?include ("../../dash_footer.php");
?>






