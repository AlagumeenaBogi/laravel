<?
include("../../dash_header.php");
$report_name='LOAN SUMMARY REPORT';
$to_year='2017';
?>
<script>
function generate_loan_summary(type,mbt_ids,branch_ids,fo_ids,cbos_ids,fdate,tdate) { /*--new_cron_function*/
//alert(fdate+"---"+mbt_ids+"---"+tdate+"--"+branch_ids+"---"+fo_ids+"---"+cbos_ids);
var mbt_id=$("#"+mbt_ids).val();
var branch_id=$("#"+branch_ids).val();
var fo_id=$("#"+fo_ids).val();
var cbos_id=$("#"+cbos_ids).val();
var rand=Math.random();
if(mbt_id == "") {
	alert("Please select the MBT");
	return false;
}
if(branch_id == "") {
	alert("Please select the Branch Name");
	return false;
}
if(fo_id == "") {
	alert("Please select the Field officer Name");
	return false;
}
if(cbos_id == "") {
	alert("Please select the CBOS Name");
	return false;
}
if(fdate == "") {
	alert("Please Select the From Date");
	return false;
}
if(tdate == "") {
	alert("Please select the To Date");
	return false;
}
if(mbt_id !='' && branch_id !='' && fo_id!='' && cbos_id != '' && fdate !='' && tdate !='')
{

        setTimeout(function(){   document.getElementById("ajaxloader").style.display="block";}, 10);
	$.get('loan_summary_ajax.php',{type:type,mbt_id:mbt_id,branch_id:branch_id,fo_id:fo_id,cbos_id:cbos_id,fromdate:fdate,todate:tdate},
		function (resp) {
		//alert(resp);
                if(resp != '')
                    {
			document.getElementById('divlevel').innerHTML = resp;
                         document.getElementById("ajaxloader").style.display="none";
                    }
               else
                   {
                      alert("Please Select the Current Financial Year and not generated the cron this year.");
                   }
	     }
	);
}

}
function mbt_wise_branch_display(type,mbt_id_name)
{
    var mbt_id=$("#"+mbt_id_name).val();
    //alert("--name-->"+mbt_id_name+"--val-->"+mbt_id+"--type-->"+type);
    if(mbt_id == "") {
    alert("Please select the MBT Name");
    return false;
    }
    	$.get('loan_summary_ajax.php',{type:type,mbt_id:mbt_id},
		function (resp) {
		//alert(resp);
                if(resp != '')
                    {
                        //alert(resp);
			document.getElementById('branch_append_div').innerHTML = resp;
                    }
               else
                   {
                      alert("Please Select the Runing MBT Name.");
                   }
	     }
	);
}
function branch_wise_fo_display(type,branch_id_name)
{
    var branch_id=$("#"+branch_id_name).val();
    //alert("--branchname-->"+branch_id_name+"--val-->"+branch_id+"--type-->"+type);
    if(branch_id == "") {
    alert("Please select the branch Name");
    return false;
    }
    	$.get('loan_summary_ajax.php',{type:type,branch_id:branch_id},
		function (resp) {
		//alert(resp);
                if(resp != '')
                    {
                       // alert(resp);
			document.getElementById('fo_append_div').innerHTML = resp;
                    }
               else
                   {
                      alert("Please Select the Runing Branch Name.");
                   }
	     }
	);
}
function fo_wise_cbos_display(type,fo_id_name)
{
    var fo_id=$("#"+fo_id_name).val();
    //alert("--fo-->"+fo_id_name+"--val-->"+fo_id+"--type-->"+type);
    if(fo_id == "") {
    alert("Please select the branch Name");
    return false;
    }
    	$.get('loan_summary_ajax.php',{type:type,fo_id:fo_id},
		function (resp) {
		//alert(resp);
                if(resp != '')
                    {
                       // alert(resp);
			document.getElementById('cbos_append_div').innerHTML = resp;
                    }
               else
                   {
                      alert("Please Select the Runing Field Officer Name.");
                   }
	     }
	);
}
</script>
<div class="page-content inset">
	
    <div class="row">
	
	<div class="col-md-12">
		<ol class="breadcrumb">
                        <li><a href="#">Dashboard</a></li>
                        <li><a href="#">Reports</a> </li>
                        <li class="active"><?=$report_name;?></li>
                    </ol>
	</div>
	
	<div class="col-md-12">
		<div class="alert alert-info alert-dismissible" role="alert">
		    Please You Can View the <?=$report_name;?>.
		</div>
	</div>
	
	<div class="col-sm-3 clear-right-padding">
			<? include ("left_menu_reports.php"); ?>
	</div>
	<div class="col-sm-9">
	        <div class="well">
	         <form class="form-horizontal" method="post" name="loan_ledger_rep_form" id="loan_ledger_rep_form">
			<h2 class="view-info-underline"><?=$report_name;?></h2>
<!------------------------ MBT Type creation----------------------------------------------------------------------->
                        <div class="col-sm-12">
                            <div class="col-sm-3">
                                <label class="control-label"> <b>Select the MBT Name: <span class="star">*</span> </b> </label>
                            </div>
                            <div class="col-sm-6">
                                <select class="form-control" name="mbt_type" id="mbt_type" onchange="mbt_wise_branch_display('mbt_wise_branch_display','mbt_type')">
                                    <option value="">Select MBT Name</option>
                                    <option value="0">All MBT</option>
                                    <?php
                                   
                                    $fd = mysql_query("SELECT * FROM mfi_registration WHERE mfistatus=1 AND status=1",$global_database);
                                    $count=mysql_num_rows($fd);
                                    if($count >0)
                                    {
                                        while($res = mysql_fetch_object($fd)) {
                                        echo "<option value='".$res->iid."'>".str_replace("-"," ",$res->mfiname)."</option>";
                                        }
                                        //mysql_free_result($fd);
                                    }
                                    ?>
                                </select>
                            </div>
                        </div></br></br></br>    
<!-----------------------------------level type created--------------------------------------------->
              
<div class="col-sm-12">
    <div class="col-sm-3">
     <label class="control-label"> <b>Select the Branch Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <div id="branch_append_div">
                <select class="form-control" name="branch_type" id="branch_type" >
                <option value=" ">Select Branch Name</option>        
                </select>
        </div>
    </div>
</div><BR><BR><BR>
<!-----------------------------------Field officer created--------------------------------------------->
              
<div class="col-sm-12">
    <div class="col-sm-3">
     <label class="control-label"> <b>Select the Field officer Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <div id="fo_append_div">
                <select class="form-control" name="fo_type" id="fo_type" >
                <option value=" ">Select Field officer Name</option>        
                </select>
        </div>
    </div>
</div><BR><BR><BR>
<!-----------------------------------cbos created--------------------------------------------->
              
<div class="col-sm-12">
    <div class="col-sm-3">
     <label class="control-label"> <b>Select the CBOS Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <div id="cbos_append_div">
                <select class="form-control" name="cbos_type" id="cbos_type" >
                <option value=" ">Select CBOS Name</option>        
                </select>
        </div>
    </div>
</div><BR><BR><BR>
<!-----------------------------------FROM DATE--------------------------------------------------------------------->

                        <div class="col-sm-12">                        
                            <div class="col-sm-3">
                            <label class="control-label"><b>From Date: <span class="star">*</span></b></label>
                            </div>
                            <div  class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-addon glyphicon glyphicon-calendar"></span>
                                    <input class="form-control datepicker" type="text" id="from_date" name="from_date" value="<?echo date('d-m-Y');?>">
                                </div>
                            </div>
                        </div></br></br></br> 
<!-----------------------------------TO DATE--------------------------------------------------------------------->
                       <div class="col-sm-12">                        
                            <div class="col-sm-3">
                            <label class="control-label"><b>To Date: <span class="star">*</span></b></label>
                            </div>
                            <div  class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-addon glyphicon glyphicon-calendar"></span>
                                    <input class="form-control datepicker_all_year" type="text" id="to_date" name="to_date" value="<? echo '31-04-'.$to_year;?>"  >
                                </div>
                            </div>
                       </div></br></br></br>                        
                      
<!-----------------------------------BUTTON-------------------------------------------------------------------->

                        <div class="col-sm-12">
                            <div class="col-sm-3"></div>
                            <div class="col-sm-6">
                                <button class="btn btn-default btn-lg" type="button" onclick="generate_loan_summary('loan_summary','mbt_type','branch_type','fo_type','cbos_type','from_date','to_date');" >Show Reports</button>
                            </div>
                            <div class="col-sm-3"></div>
                        </div><BR><BR><BR>
<!-----------------------------------LOADER-------------------------------------------------------------------->

                        <div id="ajaxloader" style=" display: none;">
                            <div  align="center">
                                <img src="<?=$microfin_application_url;?>/themes/images/ajax-loader.gif" width="54" height="55"><br /><br />
                                <span >Please wait loading reports..</span>
                            </div>
                        </div>
<!-----------------------------------AJAX CONTENT-------------------------------------------------------------------->

                    <div class="row">
                        <div class="col-md-12">
                            <div id="divlevel">                
                            </div>
                        </div>
                    </div>
			
			
		 </form>
		 
	        </div>
	</div>	
    </div>
</div>	
<?
include ("../../dash_footer.php");
?>






