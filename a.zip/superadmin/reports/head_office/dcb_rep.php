<?
include("../../dash_header.php");
$report_name='Demand Collection Balance REPORT';
$to_year='2017';
?>
<style>
    .hover-color
    {
 color: red
    }
    .filter_con
    {
          font-size:13px;
         float: left;
          position: relative;
          min-height: 1px;
          padding-right: 15px;
          padding-left: 15px;
         width: 11.1111111%;

}

         #tabbable{font-size: 14px;}
         .ui-widget-header {
            background:#b9cd6d;
            border: 1px solid #b9cd6d;
            color: #FFFFFF;
            font-weight: bold;
         }

</style>
<script>
    function gettab_value()
{
    //alert(id);
    var mbt_id=$("#mbt_type").val();
    if(mbt_id == '')
        {
            alert("Plese Select the MBT Name");
            return false;
        }
}
</script>

<div class="page-content inset">
	<div class="row">

		<div class="col-md-12">
                    <ol class="breadcrumb">
                        <li><a   target="_blank"     href="#">Dashboard</a></li>
                        <li><a   target="_blank"     href="#">Reports</a> </li>
                        <li class="active"><?=$report_name;?></li>
                    </ol>
			<h1><?=$report_name;?></h1>
		</div>

		<div class="col-md-12">
			<div class="alert alert-info alert-dismissible" role="alert">
				Please You Can View the<?=$report_name;?>.
			</div>
		</div>
	<div class="col-sm-3 clear-right-padding">
			<? include ("left_menu_reports.php"); ?>
	</div>
		<div class="col-sm-9">
			<div class="well">
            <form class="form-horizontal" method="post" name="branch_demand_collection_form" id="branch_demand_collection_form">


                <!---demand--><h2 class="view-info-underline"><?=$report_name;?></h2>
                <br>
                <br>

					<br>
                                       <!------------------------ MBT Type creation----------------------------------------------------------------------->
                        <div class="col-sm-12">
                            <div class="col-sm-3">
                                <label class="control-label"> <b>Select the MBT Name: <span class="star">*</span> </b> </label>
                            </div>
                            <div class="col-sm-6">
                                <select class="form-control" name="mbt_type" id="mbt_type">
                                    <option value="">Select MBT Name</option>
                                    <option value="0">All MBT</option>
                                    <?php
                                    $fd = mysql_query("SELECT * FROM mfi_registration WHERE mfistatus=1 AND status=1");
                                    $count=mysql_num_rows($fd);
                                    if($count >0)
                                    {
                                        while($res = mysql_fetch_object($fd)) {
                                        echo "<option value='".$res->iid."'>".str_replace("-"," ",$res->mfiname)."</option>";
                                        }
                                        mysql_free_result($fd);
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
<div class="tabbable">

  <ul class="nav nav-tabs nav-justified">
    <li class="active"><a   target="_blank"     href="#demand" data-toggle="tab" onclick="gettab_value()">Demand</a></li>
    <li><a   target="_blank"     data-toggle="tab" href="#collection" onclick="gettab_value()">Collection</a></li>
    <li><a   target="_blank"     data-toggle="tab" href="#balance" onclick="gettab_value()">Balance</a></li>
   </ul>
       <br>
         <br>

         <div class="col-sm-12">

             <input type="hidden" name="get_text" id="level_text"/>
             <input type="hidden" name="get_text" id="level_value"/>
             <input type="hidden" name="get_text" id="nav_tab_value"/>
             <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(1,'nav_tab_value','level_value','level_text','div_demand_collection');">Today</a>
             </div>
             <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(2 ,'nav_tab_value','level_value','level_text','div_demand_collection');">This Week</a>
             </div>
             <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(3,'nav_tab_value','level_value','level_text','div_demand_collection');">Next Week</a>
             </div>
             <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(4,'nav_tab_value','level_value','level_text','div_demand_collection');">This Month</a>
             </div>
             <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(5,'nav_tab_value','level_value','level_text','div_demand_collection');">Next Month</a>
             </div>
              <div class="filter_con" style="padding:0px;">
                <a   target="_blank"     href="javascript:my_function(6,'nav_tab_value','level_value','level_text','div_demand_collection');">Next 2 Months</a>
             </div>
              <div class="filter_con" style="padding:0px;">
                <a   target="_blank"     href="javascript:my_function(7,'nav_tab_value','level_value','level_text','div_demand_collection');">Next 3 Months</a>
             </div>
              <div class="filter_con" style="padding:0px;">
                <a   target="_blank"     href="javascript:my_function(8,'nav_tab_value','level_value','level_text','div_demand_collection');">Next 6 Months</a>
             </div>
              <div class="filter_con">
                <a   target="_blank"     href="javascript:my_function(9,'nav_tab_value','level_value','level_text','div_demand_collection');">1 Year</a>
             </div>
             </div>
        
                                         <br>
                                        <br>
                                        <br>
                                        <br>

                <!---demand--><!--h2 class="view-info-underline">Branch Demand Collection  Report</h2>
            
                <div><h3>Date  01-04-2014 To 31-03-2015</h3></div-->
                <div class="tab-content" style="min-height: 500px;">
               
                <div class="tab-pane fade in active" id="demand">
                        <div><h3>Demand</h3></div>
                <table class="table table-hover table-stripeds table-curved table-bordered">
            <tbody>

        <tr>
            <th align="left">
                <div>Branch ID</div>
            </th>
            <th align="left">
                <div>Branch Name</div>
            </th>
            <th align="left">
                <div>Principal Opening Loan O/S</div>
            </th>
            <th align="left" >
                <div>Current Due</div>
            </th>
            <th align="left">
                <div>Overdue</div>
            </th>
            <th align="left">
                <div>Total due</div>
            </th>
        </tr>
        
        <tr>
     
	 <td align="left">2001</td> 	<td align="left">Tranqubar</td>
        <td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        </tr>
        <tr>

 <td align="left">2002</td> 	<td align="left">Avudayarkovil</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
        </tr>
        <tr>

 <td align="left">2003</td> 	<td align="left">Sirkazhi</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
        </tr>
        <tr>
            
 <td align="left">2004</td> 	<td align="left">Karaikal </td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        </tr>
        <tr>
            
 <td align="left">2005</td> 	<td align="left">Vallioor</td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
</tr>
<tr>
        
            <td  align="right" colspan="2"><b>TOTAL</b></d>
            <td align="right">0</td>
            <td align="right">7291.58</td>
            <td align="right">8895.78</td>
            <td align="right">174999.36</td>
           
</tr>
                </tbody>
                </table>
                </div>
                <!--collection><h2 class="view-info-underline"></h2-->
                <div class="tab-pane fade" id="collection">
                <div><h3>Collection</h3></div>
                <!--div><h3>Date  01-04-2014 To 31-03-2015</h3></div-->

                 <table class="table table-hover table-stripeds table-curved table-bordered">
            <tbody>

        <tr>
             <th align="left">
            Branch ID
            </th>
            <th align="left">
            Branch Name
            </th>
            <th align="left">
                Principal Opening Loan O/S
            </th>
            <th align="left" >
             Current Due
            </th>
            <th align="left" >
                Overdue
            </th>
            <th align="left" >
                Total due
            </th>
            <th align="left">
               Received
            </th>
            <th align="left" >
               Prepayment
            </th>
            <th align="left" >
               Principal Closing Loan Outstanding
            </th>
        </tr>
        
          <tr>
     	 <td align="left">2001</td> 	<td align="left">Tranqubar</td>
        <td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">3,125.99</td>
         <td align="right">0</td>
          <td align="right">25,000</td>
        </tr>
        <tr>
 <td align="left">2001</td> 	<td align="left">Tranqubar</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
<td align="right">4624.99</td>
         <td align="right">0</td>
          <td align="right">50,000</td>
        </tr>
        <tr>

 <td align="left">2003</td> 	<td align="left">Sirkazhi</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
<td align="right">4624.99</td>
         <td align="right">0</td>
          <td align="right">50,000</td>
        </tr>
        <tr>
             <td align="left">2004</td> 	<td align="left">Karaikal </td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">1041.66</td>
         <td align="right">0</td>
          <td align="right">25,000</td>
        </tr>
        <tr>
            
 <td align="left">2005</td> 	<td align="left">Vallioor</td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">3,125.99</td>
         <td align="right">0</td>
          <td align="right">25,000</td>
</tr>

<tr>
           
            <td  align="right" colspan='2'><b>TOTAL</b></td>
            <td align="right">0</td>
            <td align="right">7291.58</td>
            <td align="right">8895.78</td>
            <td align="right">174999.36</td>
            <td align="right">16543.62</td>
            <td align="right">0</td>
            <td align="right">1,75,000</td>
          
</tr>
                </tbody>
                </table>
                </div>

<!----balance-->                <!--h2 class="view-info-underline"></h2-->
<div class="tab-pane fade" id="balance">
<div><h3>Balance</h3></div>
                <!--div><h3>Date  01-04-2014 To 31-03-2015</h3></div-->

                 <table class="table table-hover table-stripeds table-curved table-bordered">
            <tbody>

        <tr>
             <th align="left"rowspan="2">
                <div>Branch ID</div>
            </th>
            <th align="left"rowspan="2">
                <div>Branch Name</div>
            </th>
            <th align="left"rowspan="2">
                <div>Principal Opening Loan O/S</div>
            </th>
            <th align="left"colspan="3">
                <div>Dues</div>
            </th>

            <th align="left" rowspan="2">
                <div>Collection</div>
            </th>
            <th align="left" rowspan="2">
                <div>Balance</div>
            </th>
        </tr>
        <tr>
            <th align="left">
                <div>Currentdue</div>
            </th>
            <th align="left">
                <div>Overdue</div>
            </th>
            <th align="left">
                <div>Total due</div>
            </th>
        </tr>
     <tr>
     
	 <td align="left">2001</td> 	<td align="left">Tranqubar</td>
        <td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">3,125.99</td>
         <td align="right">21874.01</td>
        </tr>
        <tr>

 <td align="left">2001</td> 	<td align="left">Tranqubar</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
<td align="right">4624.99</td>
              <td align="right">45375.01</td>
        </tr>
        <tr>

 <td align="left">2003</td> 	<td align="left">Sirkazhi</td>
<td align="right">0</td>
<td align="right">2083.33</td>
<td align="right">2541.66</td>
<td align="right">49999.92</td>
<td align="right">4624.99</td>

          <td align="right">45375.01</td>
        </tr>
        <tr>
            
 <td align="left">2004</td> 	<td align="left">Karaikal </td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">1041.66</td>
         <td align="right">23958.34</td>
        </tr>
        <tr>
            
             <td align="left">2005</td> 	<td align="left">Vallioor</td>
<td align="right">0</td>
	<td align="right">1041.66</td>
	<td align="right">1270.82</td>
	<td align="right">24999.84</td>
        <td align="right">3,125.99</td>
        <td align="right">21874.01</td>
</tr>
<tr>
           
            <td align="right" colspan='2'><b>TOTAL</b></td>
            <td align="right">0</td>
            <td align="right">7291.58</td>
            <td align="right">8895.78</td>
            <td align="right">174999.36</td>
            <td align="right">16543.62</td>

            <td align="right">1,58,456.38</td>
            
</tr>

                 </tbody>
                </table>
</div>
                </div>
 </div>

        <span class="text-muted">Report Generated On <?=date("D M j, Y ");?> at <?=date("h:i A");?></span>
					</form>
			 </div>
		 </div>

	</div>
</div>
<?
include ("../../dash_footer.php");
?>






