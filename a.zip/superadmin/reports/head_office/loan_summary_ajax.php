<?php
include("../../db_connect.php");
error_reporting("0");
$iid = $_SESSION['iid'];
$type=$_GET['type']; //echo "--type-->".$type."  	";
$mbt_id = $_GET['mbt_id']; //echo "--->".$mbt_id."  	";
$branch_id_arr=$_GET['branch_id']; //echo $branch_id."  	"; 
$fo_id_arr=$_GET['fo_id']; //echo $fo_id."  	"; 
$finyear=$_SESSION['fromyear'];
$fdate = explode("-",$_GET['fromdate']);
$fromdate = mktime(0,0,0,$fdate[1],$fdate[0],$fdate[2]);
$tdate = explode("-",$_GET['todate']);
$todate = mktime(0,0,0,$tdate[1],$tdate[0],$tdate[2]);
if($type == 'mbt_wise_branch_display')
{
     $display_branch_content="<select class='form-control' name='branch_type' id='branch_type' onchange=branch_wise_fo_display('branch_wise_fo_display','branch_type')>
<option value=' '>Select Branch Name Ajax</option>
<option value='0##$mbt_id'>All Branches</option>"; 
     if($mbt_id =='0')
     {
           $mbt_id_filter="";
           $mbt_id_display="";
     }
      else
      {
            $mbt_id_filter="AND iid='$mbt_id'";
            $mbt_id_display=$mbt_id." - ";
      }
      
      
     $mbt_database_name_get="SELECT database_name FROM mfi_registration WHERE status=1 and mfistatus=1 $mbt_id_filter";     
     $mbt_database_name_query=mysql_query($mbt_database_name_get,$global_database);
     $count=mysql_num_rows($mbt_database_name_query);
     //echo "--step1".$mbt_database_name_get."  	--step3glo_name-->".$global_database_name."---".$global_database."  	--step4-->".$count."  	-------------------------------------------------------------------------------  	";
     if($count >0)
     {
         $mbt_db_count=1;
         while($mbt_database_name_fetch=mysql_fetch_array($mbt_database_name_query))
         {
               $mbt_database_name=$mbt_database_name_fetch['database_name'];
                //echo "---step5arr_dtabase_name--->  	<pre>".print_r($mbt_database_name)."  	--step5_single_name-->".$mbt_db_count."--mbt_count---".$mbt_database_name."  	";
                    if($mbt_database_name != '')
                    {
                        if($global_database != '')
                        {                            
                             mysql_select_db($mbt_database_name, $global_database);                           
                            
                             if($mbt_id =='0')
                                   $mbt_id_wise_branch_filter="";
                              else
                                    $mbt_id_wise_branch_filter="AND iid='1001'"; //$mbt_id
                              
                            $branch_details_get="SELECT * FROM $mbt_database_name.branch_registration  WHERE approve_status=1 AND status=1 $mbt_id_wise_branch_filter";                          
                            $branch_details_query=mysql_query($branch_details_get,$global_database);
                            $branch_count=mysql_num_rows($branch_details_query);
                            //echo "--step6mbt_count".$mbt_db_count."---mbt_id->".$mbt_id."-->".$branch_details_get."  	--step7-->".$branch_count."  	"; 
                            if($branch_count >0)
                            {
                                $mbt_wise_branch_count=1;
                                while($branch_name_fetch=mysql_fetch_array($branch_details_query))
                                {
                                    $branchofficename=$branch_name_fetch['branchofficename'];
                                    $bid=$branch_name_fetch['bid'];
                                    //echo "--step8-->".$branchofficename."---".$mbt_id."  	";//echo "<pre>";//print_r($branchofficename);                                   
                                    $display_branch_content.="<option value='".$bid."##".$mbt_id."'>".$mbt_id_display.$branchofficename."</option>";                                   
                                    $mbt_wise_branch_count++;
                                }
                                
                            }

                        }  
                    }
             $mbt_db_count++;
          }
     }
     
    $display_branch_content.="</select>";
    echo $display_branch_content;
     
}
if($type == 'branch_wise_fo_display')
{
   $arr_val=explode("##",$branch_id_arr);
   $branch_mbt_id=$arr_val[1];
   $branch_id=$arr_val[0];
   //echo $arr_val[0].$arr_val[1];"  	";
     $display_fo_content="<select class='form-control' name='fo_type' id='fo_type' onchange=fo_wise_cbos_display('fo_wise_cbos_display','fo_type')>
<option value=' '>Select Field Officer Name Ajax</option>
<option value='0##$branch_id##$branch_mbt_id'>All Field Officer</option>"; 
     if($branch_mbt_id =='0')
     {
           $branch_mbt_id_filter="";
           $branch_mbt_id_display="";
     }
      else
      {
            $branch_mbt_id_filter="AND iid='$branch_mbt_id'";
            $branch_mbt_id_display=$branch_mbt_id." - ";
      }
      
      
     $mbt_database_name_get="SELECT database_name FROM mfi_registration WHERE status=1 and mfistatus=1 $branch_mbt_id_filter";     
     $mbt_database_name_query=mysql_query($mbt_database_name_get,$global_database);
     $count=mysql_num_rows($mbt_database_name_query);
     //echo "--step1".$mbt_database_name_get."  	--step3glo_name-->".$global_database_name."---".$global_database."  	--step4-->".$count."  	-------------------------------------------------------------------------------  	";
     if($count >0)
     {
         $mbt_db_count=1;
         while($mbt_database_name_fetch=mysql_fetch_array($mbt_database_name_query))
         {
               $mbt_database_name=$mbt_database_name_fetch['database_name'];
                //echo "---step5arr_dtabase_name--->  	<pre>".print_r($mbt_database_name)."  	--step5_single_name-->".$mbt_db_count."--mbt_count---".$mbt_database_name."  	";
                    if($mbt_database_name != '')
                    {
                        if($global_database != '')
                        {                            
                             mysql_select_db($mbt_database_name, $global_database);                           
                            
                             if($branch_mbt_id =='0')
                                   $mbt_id_wise_fo_filter="";
                              else
                                    $mbt_id_wise_fo_filter="AND br.iid=1001"; //$branch_mbt_id
                              
                               if($branch_id=='0')
                                   $branch_id_wise_fo_filter="";
                              else
                                    $branch_id_wise_fo_filter="AND fg.bid=$branch_id AND br.bid=$branch_id";//
                              
                            $fo_details_get="SELECT distinct fg.fieldofficer_addr_id, fg.bid, br.bid, br.iid FROM $mbt_database_name.fieldofficer_geography as fg, $mbt_database_name.branch_registration as br where fg.bid=br.bid $mbt_id_wise_fo_filter $branch_id_wise_fo_filter";
                            $fo_details_query=mysql_query($fo_details_get,$global_database);
                            $fo_count=mysql_num_rows($fo_details_query);
                           // echo "--step6mbt_count".$mbt_db_count."---mbt_id->".$branch_mbt_id."-->".$fo_details_get."  	--step7-->".$fo_count."  	"; 
                            if($fo_count >0)
                            {
                                $mbt_wise_fo_count=1;
                                while($fo_name_fetch=mysql_fetch_array($fo_details_query))
                                {
                                    $fo_id=$fo_name_fetch['fieldofficer_addr_id'];
			            $q_select_fo_name=mysql_query("select foname from $mbt_database_name.fieldofficer_address_info where fid=$fo_id and status=1 and approve_status=1",$global_database);
					while($r_select_fo_name=mysql_fetch_array($q_select_fo_name))
						{
                                                     $fo_name=$r_select_fo_name['foname'];
                                                      //echo "--step8-->".$foofficename."---".$branch_mbt_id."  	";//echo "<pre>";//print_r($foofficename);                                   
                                                   $display_fo_content.="<option value='".$fo_id."##".$branch_id."##".$branch_mbt_id."'>".$branch_mbt_id_display.$fo_name."</option>";                                   
                                                }
                                     $mbt_wise_fo_count++;
                                }
                                
                            }

                        }  
                    }
             $mbt_db_count++;
          }
     }
     
    $display_fo_content.="</select>";
    echo $display_fo_content;
}
if($type == 'fo_wise_cbos_display')
{
   $arr_val=explode("##",$fo_id_arr);
   $fo_id=$arr_val[0];
   $branch_mbt_id=$arr_val[2];
   $branch_id=$arr_val[1];
   //echo $arr_val[0].$arr_val[1];"  	";
     $display_cbos_content="<select class='form-control' name='cbos_type' id='cbos_type'>
<option value=' '>Select CBOS Name Ajax</option>
<option value='0##$fo_id##$branch_id##$branch_mbt_id'>All CBOS</option>"; 
     if($branch_mbt_id =='0')
     {
           $branch_mbt_id_filter="";
           $branch_mbt_id_display="";
     }
      else
      {
            $branch_mbt_id_filter="AND iid='$branch_mbt_id'";
            $branch_mbt_id_display=$branch_mbt_id." - ";
      }
      
      
     $mbt_database_name_get="SELECT database_name FROM mfi_registration WHERE status=1 and mfistatus=1 $branch_mbt_id_filter";     
     $mbt_database_name_query=mysql_query($mbt_database_name_get,$global_database);
     $count=mysql_num_rows($mbt_database_name_query);
     //echo "--step1".$mbt_database_name_get."  	--step3glo_name-->".$global_database_name."---".$global_database."  	--step4-->".$count."  	-------------------------------------------------------------------------------  	";
     if($count >0)
     {
         $mbt_db_count=1;
         while($mbt_database_name_fetch=mysql_fetch_array($mbt_database_name_query))
         {
               $mbt_database_name=$mbt_database_name_fetch['database_name'];
                //echo "---step5arr_dtabase_name--->  	<pre>".print_r($mbt_database_name)."  	--step5_single_name-->".$mbt_db_count."--mbt_count---".$mbt_database_name."  	";
                    if($mbt_database_name != '')
                    {
                        if($global_database != '')
                        {                            
                             mysql_select_db($mbt_database_name, $global_database);                           
                            
                             if($branch_mbt_id =='0')
                                   $mbt_id_wise_fo_filter="";
                              else
                                    $mbt_id_wise_fo_filter="AND br.iid=1001"; //$branch_mbt_id
                              
                               if($branch_id=='0')
                                   $branch_id_wise_fo_filter="";
                              else
                                    $branch_id_wise_fo_filter="AND r.iid=$branch_id AND br.bid=$branch_id";//
                              
                              if($fo_id == '0')
                                  $fo_filter="";
                              else
                                  $fo_filter="AND relation=$fo_id";
                            
                            $cbos_details_get="SELECT r.rid, r.iid, r.rosca_name, br.bid, br.iid FROM rosca as r, branch_registration as br WHERE r.iid=br.bid $mbt_id_wise_fo_filter $branch_id_wise_fo_filter $fo_filter";
                            $cbos_details_query=mysql_query($cbos_details_get,$global_database);
                            $cbos_count=mysql_num_rows($cbos_details_query);
                            //echo "--step6mbt_count".$mbt_db_count."---mbt_id->".$branch_mbt_id."-->".$cbos_details_get."  	--step7-->".$cbos_count."  	"; 
                            if($cbos_count >0)
                            {
                                $mbt_wise_cbos_count=1;
                                while($cbos_name_fetch=mysql_fetch_array($cbos_details_query))
                                {
                                    $cbos_id=$cbos_name_fetch['rid'];
                                    $cbos_name=$cbos_name_fetch['rosca_name'];
                                    //echo "--step8-->".$cbosofficename."---".$branch_mbt_id."  	";//echo "<pre>";//print_r($cbosofficename);                                   
                                    $display_cbos_content.="<option value='".$cbos_id."##".$fo_id."##".$branch_id."##".$branch_mbt_id."'>".$branch_mbt_id_display.$cbos_name."</option>";                                   
                                             
                                     $mbt_wise_cbos_count++;
                                }
                                
                            }

                        }  
                    }
             $mbt_db_count++;
          }
     }
     
    $display_cbos_content.="</select>";
    echo $display_cbos_content;
}
if($type == 'loan_summary')
{
    echo '<h2>Loan Audit Report</h2><table class="table table-hover table-striped table-curved">	<tbody><tr >
		<th>S.No</th>
		<th>Grading Date</th>
		<th>CBO Id</th>
		<th>CBO Name</th>
		<th>Grade</th>
	</tr>  	<tr><td>1</td><td>28-05-2016</td><td>31413</td><td align="left" style="padding-left: 20px;">Valar Kanni JLG Appurajapuram</td><td>B</td></tr>  	<tr ><td>2</td><td>31-05-2016</td><td>31412</td><td align="left" style="padding-left: 20px;">Valar Saisakthi JLG Thilayadi</td><td>A</td></tr>  	<tr ><td>3</td><td>01-06-2016</td><td>31415</td><td align="left" style="padding-left: 20px;">Valar Malligai JLG Memathure</td><td>B</td></tr>  	<tr ><td>4</td><td>28-05-2016</td><td>31414</td><td align="left" style="padding-left: 20px;">valar Bismi JLG porayar</td><td>A</td></tr>  	<tr ><td>5</td><td>28-05-2016</td><td>31414</td><td align="left" style="padding-left: 20px;">valar Bismi JLG porayar</td><td>A</td></tr>  	<tr ><td>6</td><td>28-05-2016</td><td>31413</td><td align="left" style="padding-left: 20px;">Valar Kanni JLG Appurajapuram</td><td>A</td></tr>
      </tbody></table>


<h2>Loan Requests Report</h2><table class="table table-hover table-striped table-curved">
	<tbody><tr >
		<th>S.No</th>
		<th>Loan Request Date</th>
		<th>CBO Id</th>
		<th>CBO Name</th>
		<th>Loan Members</th>
		<th>Total Loan Amount</th>
	</tr>  	<tr ><td>1</td><td>01-04-2016</td><td>31331</td><td align="left" style="padding-left: 20px;">Valar Ganapathi</td><td>16</td><td align="right" style="padding-right: 20px;">260000</td></tr>  	<tr ><td>2</td><td>01-04-2016</td><td>31333</td><td align="left" style="padding-left: 20px;">Valar Kalayanaramar - Memisal</td><td>16</td><td align="right" style="padding-right: 20px;">240000</td></tr>  	<tr ><td>3</td><td>01-04-2016</td><td>31334</td><td align="left" style="padding-left: 20px;">Valar Priya - Memisal</td><td>19</td><td align="right" style="padding-right: 20px;">285000</td></tr>  	<tr ><td>4</td><td>01-04-2016</td><td>31338</td><td align="left" style="padding-left: 20px;">Valar Chinna Pillai Amman - Manthankudi</td><td>20</td><td align="right" style="padding-right: 20px;">300000</td></tr>  	<tr ><td>5</td><td>01-04-2016</td><td>31339</td><td align="left" style="padding-left: 20px;">Valar Kadal Pura - Pattankadu</td><td>15</td><td align="right" style="padding-right: 20px;">225000</td>  <tr style="font-weight: bold;" class="oddrow">
									<td style="height: 35px; text-align: left;" colspan="4">Total</td>									
									<td align="right" style="padding-right: 20px;">71</td>									
									<td align="right" style="padding-right: 20px;">13100000</td>
								</tr></tr></tbody></table>


<h2>Loan Requests Report</h2><table class="table table-hover table-striped table-curved">
	<tbody><tr >
		<th rowspan="2">S.No</th>
		<th rowspan="2">Loan Request Date</th>
		<th rowspan="2">CBO Id</th>
		<th rowspan="2">CBO Name</th>
		<th colspan="2">Approved List</th>
		<th colspan="2">Rejected List</th>
	</tr>
	<tr >
		<th>Members</th>
		<th>Amount</th>
		<th>Members</th>
		<th>Amount</th>
	</tr>  	<tr ><td>1</td><td>01-04-2016</td><td>31331</td><td align="left" style="padding-left: 20px;">Valar Ganapathi</td><td>16</td><td align="right" style="padding-right: 20px;">260000</td><td>---</td><td align="right" style="padding-right: 20px;">---</td></tr>  	<tr ><td>2</td><td>01-04-2016</td><td>31333</td><td align="left" style="padding-left: 20px;">Valar Kalayanaramar - Memisal</td><td>16</td><td align="right" style="padding-right: 20px;">240000</td><td>---</td><td align="right" style="padding-right: 20px;">---</td></tr>  	<tr ><td>3</td><td>01-04-2016</td><td>31334</td><td align="left" style="padding-left: 20px;">Valar Priya - Memisal</td><td>19</td><td align="right" style="padding-right: 20px;">285000</td><td>---</td><td align="right" style="padding-right: 20px;">---</td></tr>  	<tr ><td>4</td><td>01-04-2016</td><td>31338</td><td align="left" style="padding-left: 20px;">Valar Chinna Pillai Amman - Manthankudi</td><td>20</td><td align="right" style="padding-right: 20px;">300000</td><td>---</td><td align="right" style="padding-right: 20px;">---</td></tr>  	<tr ><td>5</td><td>01-04-2016</td><td>31339</td><td align="left" style="padding-left: 20px;">Valar Kadal Pura - Pattankadu</td><td>15</td><td align="right" style="padding-right: 20px;">225000</td><td>---</td><td align="right" style="padding-right: 20px;">---</td></tr>
								<tr style="font-weight: bold;" class="oddrow">
									<td style="height: 35px; text-align: left;" colspan="4">Total</td>
									<td>1537</td>
									<td align="right" style="padding-right: 20px;">24815000</td>
									<td>-</td>
									<td align="right" style="padding-right: 20px;">-</td>
								</tr></tbody></table>

<h2>Loan Requests Report</h2><table class="table table-hover table-striped table-curved">
	<tbody><tr >
		<th>S.No</th>
		<th>Disbursement Date</th>
		<th>CBO Id</th>
		<th>CBO Name</th>
		<th>Loan Members</th>
		<th>Total Loan Amount</th>
	</tr>  	<tr ><td>1</td><td>29-04-2016</td><td>31329</td><td align="left" style="padding-left: 20px;">Sandhanamari - Vilathur</td><td>17</td><td align="right" style="padding-right: 20px;">255000</td></tr>  	<tr ><td>2</td><td>29-04-2016</td><td>31336</td><td align="left" style="padding-left: 20px;">Valar Mahanathi - Pilluvalasai</td><td>20</td><td align="right" style="padding-right: 20px;">365000</td></tr>  	<tr ><td>3</td><td>29-04-2016</td><td>31358</td><td align="left" style="padding-left: 20px;">Valar Mothar Tharasa JLG LNPuram</td><td>15</td><td align="right" style="padding-right: 20px;">250000</td></tr>  	<tr ><td>4</td><td>29-04-2016</td><td>31359</td><td align="left" style="padding-left: 20px;">Valar Kathayeeamman JLG Koothangudi</td><td>22</td><td align="right" style="padding-right: 20px;">440000</td></tr>  	<tr ><td>5</td><td>29-04-2016</td><td>31360</td><td align="left" style="padding-left: 20px;">Valar Annai Kavery JLG Pachalur</td><td>18</td><td align="right" style="padding-right: 20px;">270000</td></tr>  	<tr ><td>6</td><td>29-04-2016</td><td>31364</td><td align="left" style="padding-left: 20px;">Valar Jeniva JLG Seenamangalam</td><td>14</td><td align="right" style="padding-right: 20px;">210000</td></tr>
								<tr style="font-weight: bold;" class="oddrow">
									<td style="height: 35px; text-align: left;" colspan="4">Total</td>
									<td>1350</td>
									<td align="right" style="padding-right: 20px;">21300000</td>
								</tr></tbody></table>

<h2>Loan Requests Report</h2><table class="table table-hover table-striped table-curved">
	<tbody><tr >
		<th>S.No</th>
		<th>Repayment Date</th>
		<th>CBO Id</th>
		<th>CBO Name</th>
		<th>Loan Members</th>
		<th>Total Loan Amount</th>
	</tr>  	<tr ><td>1</td><td>30-04-2016</td><td>3039</td><td align="left" style="padding-left: 20px;">LASAL ROJA WSHG AYYARPADI</td><td>7</td><td align="right" style="padding-right: 20px;">13375</td></tr>  	<tr ><td>2</td><td>27-05-2016</td><td>3039</td><td align="left" style="padding-left: 20px;">LASAL ROJA WSHG AYYARPADI</td><td>7</td><td align="right" style="padding-right: 20px;">10000</td></tr>  	<tr ><td>3</td><td>30-05-2016</td><td>3039</td><td align="left" style="padding-left: 20px;">LASAL ROJA WSHG AYYARPADI</td><td>7</td><td align="right" style="padding-right: 20px;">3377</td></tr>  	<tr ><td>4</td><td>22-06-2016</td><td>3039</td><td align="left" style="padding-left: 20px;">LASAL ROJA WSHG AYYARPADI</td><td>7</td><td align="right" style="padding-right: 20px;">13377</td></tr>  	<tr ><td>5</td><td>21-04-2016</td><td>3143</td><td align="left" style="padding-left: 20px;">LASAL  ROJA  WSHG  THIRUMULLAIVASAL (3)</td><td>6</td><td align="right" style="padding-right: 20px;">11466</td></tr>  	<tr ><td>6</td><td>26-05-2016</td><td>3143</td><td align="left" style="padding-left: 20px;">LASAL  ROJA  WSHG  THIRUMULLAIVASAL (3)</td><td>6</td><td align="right" style="padding-right: 20px;">11442</td></tr></td></tr></tbody></table>';
}

?>

