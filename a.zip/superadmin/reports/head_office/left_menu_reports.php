<div class="col-md-12 all-padding-six">										 
<div class="panel-group" id="accordion">



    <div class="panel-group" id="accordion">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" style="text-decoration:none;"><span  class="glyphicon  glyphicon glyphicon-list-alt">
                            </span> &nbsp;  Loan Reports</a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="panel-body">

   
                          <ul class="list-unstyled clear-margin-bottom">
                                                  <li class="left_link_list"><a href="<?=$microfin_final_url;?>/superadmin/reports/head_office/loan_product_perform_monitor_rep.php"><span class="text-success">Loan Product Performance Monitoring Report</span></a></li>
                                                  <li class="left_link_list"><a href="<?=$microfin_final_url;?>/superadmin/reports/head_office/loan_product_rep.php"><span class="text-success">Loan Product Report</span></a></li>
                                                   <li class="left_link_list"><a href="<?=$microfin_final_url;?>/superadmin/reports/head_office/9bb_rep.php"><span class="text-success">9BB Report</span></a></li>
                                                    <li class="left_link_list"><a href="<?=$microfin_final_url;?>/superadmin/reports/head_office/dcb_rep.php"><span class="text-success">DCB Report</span></a></li>
                                                     <li class="left_link_list"><a href="<?=$microfin_final_url;?>/superadmin/reports/head_office/loan_summary_rep.php"><span class="text-success">Loan Summary Report</span></a></li>
                          </ul>                     

                        </div>
                    </div>
                </div>
</div>
</div>
</div>

