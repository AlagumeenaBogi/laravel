<?php
error_reporting(0);
include("../../db_connect.php");
ini_set('max_execution_time',0);
$iid = $_SESSION['iid']; 
$bid = $_GET['bid'];
$mbtid = $_GET['mbtid'];
$finyear=$_SESSION['fromyear'];
$pid = $_GET['productid']; 
$fdate = explode("-",$_GET['fromdate']);
$fromdate = mktime(0,0,0,$fdate[1],$fdate[0],$fdate[2]);
$tdate = explode("-",$_GET['todate']);
$todate = mktime(0,0,0,$tdate[1],$tdate[0],$tdate[2]);

//echo $fromdate."----".$todate."<BR>";
/*if($fromdate != '' & $todate !='')
    //$date_filter="AND from_date >= '$fromdate' AND to_date <='$todate' ";
    $date_filter=" ";
if($mbtid !='' && $mbtid != '0')
    $mbt_filter="AND mfi_id=$mbtid";
else
    $branch_filter='AND mfi_id =0';

if($bid !='' && $bid != '0')
    $branch_filter="AND branch_id=$bid";
else 
    $branch_filter='AND branch_id =0';

if($pid !='' && $pid != '0')
    $product_filter="AND product_id=$pid";
else 
    $product_filter='AND product_id =0';


$number=time();				  // CREATE RANDOM FILE NAME
$fle_name = $number;
//echo "BRANCH_ID-->".$bid."<BR>";
//echo "PRODUCT_ID-->".$pid."<BR>";


$no_of_loans='0';
$loan_disbursement='0';
$loan_outstanding='0';
$overdues_total='0';

$overdue_5='0';
$overdue_6_to_10='0';
$overdue_11_to_15='0';
$overdue_16_to_30='0';
$overdue_31_to_60='0';
$overdue_60='0';
$overdue_interest_earned='0';

$annual_income_bellow_50thousand='0';
$annual_income_50thou_to_1lakh='0';
$annual_income_1lakh_to_2lakh='0';
$annual_income_2lakh_to_3lakh='0';
$annual_income_3lakh_to_4lakh='0';
$annual_income_4lakh_to_5lakh='0';
$annual_income_5lakh_to_6lakh='0';
$annual_income_6lakh_to_7lakh='0';
$annual_income_7lakh_to_8lakh='0';
$annual_income_8lakh_to_9lakh='0';
$annual_income_9lakh_to_10lakh='0';
$annual_income_above_10lakh='0';

$age_1_to_5='0';
$age_6_to_10='0';
$age_11_to_15='0';
$age_16_to_20='0';
$age_21_to_25='0';
$age_26_to_30='0';
$age_31_to_35='0';
$age_36_to_40='0';
$age_41_to_45='0';
$age_46_to_50='0';
$age_51_to_55='0';
$age_56_to_60='0';

$pwds='0';
$male='0';
$female='0';
$transgender='0';

$salaried='0';
$selfemployed_professionals='0';
$business='0';
$retired='0';
$student='0';
$housewife='0';



$edu_quali_play_school='0';
$edu_quali_primary='0';
$edu_quali_secondary='0';
$edu_quali_high_secondary='0';
$edu_quali_non_graduate='0';
$edu_quali_graduate='0';
$edu_quali_post_graduate='0';
$edu_quali_profession='0';
$edu_quali_doctorate='0';*/

$no_of_loans='839';
$loan_disbursement='13195000';
$loan_outstanding='70251574';
$overdues_total='809288';

$overdue_5='213951';
$overdue_6_to_10='42990';
$overdue_11_to_15='0';
$overdue_16_to_30='492462';
$overdue_31_to_60='4458100';
$overdue_60='1530400';
$overdue_interest_earned='4362842';

$annual_income_bellow_50thousand='99';
$annual_income_50thou_to_1lakh='0';
$annual_income_1lakh_to_2lakh='0';
$annual_income_2lakh_to_3lakh='0';
$annual_income_3lakh_to_4lakh='0';
$annual_income_4lakh_to_5lakh='0';
$annual_income_5lakh_to_6lakh='0';
$annual_income_6lakh_to_7lakh='0';
$annual_income_7lakh_to_8lakh='0';
$annual_income_8lakh_to_9lakh='0';
$annual_income_9lakh_to_10lakh='0';
$annual_income_above_10lakh='0';

$age_1_to_5='0';
$age_6_to_10='0';
$age_11_to_15='0';
$age_16_to_20='1.4';
$age_21_to_25='4.87';
$age_26_to_30='11.13';
$age_31_to_35='21.18';
$age_36_to_40='21.75';
$age_41_to_45='17.14';
$age_46_to_50='18.23';
$age_51_to_55='3.47';
$age_56_to_60='0.73';

$pwds='0';
$male='0.16';
$female='99.74';
$transgender='0';

$salaried='0';
$selfemployed_professionals='100';
$business='0';
$retired='0';
$student='0';
$housewife='0';



$edu_quali_play_school='0.67';
$edu_quali_primary='64.01';
$edu_quali_secondary='26.77';
$edu_quali_high_secondary='8.08';
$edu_quali_non_graduate='0.05';
$edu_quali_graduate='0.16';
$edu_quali_post_graduate='0.16';
$edu_quali_profession='0';
$edu_quali_doctorate='0';

/*$display_select="SELECT sum(no_of_loans) as no_of_loans, sum(loan_disbursement) as loan_disbursement, sum(loan_outstanding) as loan_outstanding, sum(overdues_total) as overdues_total, sum(overdue_5) as overdue_5, sum(overdue_6_to_10) as overdue_6_to_10,sum(overdue_11_to_15) as overdue_11_to_15, sum(overdue_16_to_30) as overdue_16_to_30,  sum(overdue_31_to_60) as overdue_31_to_60, sum(overdue_60) as overdue_60, sum(overdue_interest_earned) as overdue_interest_earned,  sum(annual_income_bellow_50thousand) as annual_income_bellow_50thousand, sum(annual_income_50thou_to_1lakh) as annual_income_50thou_to_1lakh,  sum(annual_income_1lakh_to_2lakh) as annual_income_1lakh_to_2lakh, sum(annual_income_2lakh_to_3lakh) as annual_income_2lakh_to_3lakh, sum(annual_income_3lakh_to_4lakh) as annual_income_3lakh_to_4lakh, sum(annual_income_4lakh_to_5lakh) as annual_income_4lakh_to_5lakh,sum(annual_income_5lakh_to_6lakh) as annual_income_5lakh_to_6lakh, sum(annual_income_6lakh_to_7lakh) as annual_income_6lakh_to_7lakh,sum(annual_income_7lakh_to_8lakh) as annual_income_7lakh_to_8lakh, sum(annual_income_8lakh_to_9lakh) as annual_income_8lakh_to_9lakh,sum(annual_income_9lakh_to_10lakh) as annual_income_9lakh_to_10lakh, sum(annual_income_above_10lakh) as annual_income_above_10lakh , sum(age_1_to_5) as age_1_to_5, sum(age_6_to_10) as age_6_to_10, sum(age_11_to_15) as age_11_to_15, sum(age_16_to_20) as age_16_to_20, sum(age_21_to_25) as age_21_to_25, sum(age_26_to_30) as age_26_to_30, sum(age_31_to_35) as age_31_to_35, sum(age_36_to_40) as age_36_to_40, sum(age_41_to_45) as age_41_to_45, sum(age_46_to_50) as age_46_to_50, sum(age_51_to_55) as age_51_to_55, sum(age_56_to_60) as age_56_to_60, sum(pwds) as pwds, sum(male) as male, sum(female) as female, sum(transgender) as transgender, sum(salaried) as salaried, sum(selfemployed_professionals) as selfemployed_professionals, sum(business) as business, sum(retired) as retired, sum(student) as student,
sum(housewife) as housewife, sum(edu_quali_play_school) as edu_quali_play_school,sum(edu_quali_primary) as edu_quali_primary, sum(edu_quali_secondary) as edu_quali_secondary, sum(edu_quali_high_secondary) as edu_quali_high_secondary, sum(edu_quali_non_graduate) as edu_quali_non_graduate, sum(edu_quali_graduate) as edu_quali_graduate, sum(edu_quali_post_graduate) as edu_quali_post_graduate, 
sum(edu_quali_profession) as edu_quali_profession, sum(edu_quali_doctorate) as edu_quali_doctorate FROM crons_loan_performance_monitoring_report WHERE status=1 $branch_filter $product_filter $date_filter";*/

/*$display_select="SELECT  * FROM sjdt1_alagumeena.crons_loan_performance_monitoring_report_superadmin WHERE status=1 $mbt_filter  $branch_filter $product_filter $date_filter";


//echo $display_select."<BR>";

$display_query=mysql_query($display_select) or die("Error -->".mysql_error());
while($display_query_fet=mysql_fetch_array($display_query)){
    $no_of_loans=$display_query_fet['no_of_loans'];
    $loan_disbursement=$display_query_fet['loan_disbursement'];
    $loan_outstanding=$display_query_fet['loan_outstanding'];
    $overdues_total=$display_query_fet['overdues_total']; 
    
    $overdue_5=$display_query_fet['overdue_5'];
    $overdue_6_to_10=$display_query_fet['overdue_6_to_10'];
    $overdue_11_to_15=$display_query_fet['overdue_11_to_15'];
    $overdue_16_to_30=$display_query_fet['overdue_16_to_30'];
    $overdue_31_to_60=$display_query_fet['overdue_31_to_60'];
     $overdue_60=$display_query_fet['overdue_60'];
    $overdue_interest_earned=$display_query_fet['overdue_interest_earned'];
    
    //echo $loan_disbursement."----".$loan_outstanding."<BR>";
    $annual_income_bellow_50thousand=$display_query_fet['annual_income_bellow_50thousand'];
    $annual_income_50thou_to_1lakh=$display_query_fet['annual_income_50thou_to_1lakh'];
    $annual_income_1lakh_to_2lakh=$display_query_fet['annual_income_1lakh_to_2lakh'];
    $annual_income_2lakh_to_3lakh=$display_query_fet['annual_income_2lakh_to_3lakh'];
    $annual_income_3lakh_to_4lakh=$display_query_fet['annual_income_3lakh_to_4lakh'];
    $annual_income_4lakh_to_5lakh=$display_query_fet['annual_income_4lakh_to_5lakh'];
    $annual_income_5lakh_to_6lakh=$display_query_fet['annual_income_5lakh_to_6lakh'];
    $annual_income_6lakh_to_7lakh=$display_query_fet['annual_income_6lakh_to_7lakh'];
    $annual_income_7lakh_to_8lakh=$display_query_fet['annual_income_7lakh_to_8lakh'];
    $annual_income_8lakh_to_9lakh=$display_query_fet['annual_income_8lakh_to_9lakh'];
    $annual_income_9lakh_to_10lakh=$display_query_fet['annual_income_9lakh_to_10lakh'];
    $annual_income_above_10lakh=$display_query_fet['annual_income_above_10lakh'];  


    $age_1_to_5=$display_query_fet['age_1_to_5'];
    $age_6_to_10=$display_query_fet['age_6_to_10'];
    $age_11_to_15=$display_query_fet['age_11_to_15'];
    $age_16_to_20=$display_query_fet['age_16_to_20'];
    $age_21_to_25=$display_query_fet['age_21_to_25'];
    $age_26_to_30=$display_query_fet['age_26_to_30'];
    $age_31_to_35=$display_query_fet['age_31_to_35'];
    $age_36_to_40=$display_query_fet['age_36_to_40'];
    $age_41_to_45=$display_query_fet['age_41_to_45'];
    $age_46_to_50=$display_query_fet['age_46_to_50'];       
    $age_51_to_55=$display_query_fet['age_51_to_55']; 
    $age_56_to_60=$display_query_fet['age_56_to_60']; 

    
    $male=$display_query_fet['male'];
    $female=$display_query_fet['female'];
    $transgender=$display_query_fet['transgender'];
    $pwds=$display_query_fet['pwds'];
    
    $salaried=$display_query_fet['salaried'];
    $selfemployed_professionals=$display_query_fet['selfemployed_professionals'];
    $business=$display_query_fet['business'];
    $retired=$display_query_fet['retired'];
    $student=$display_query_fet['student'];
    $housewife=$display_query_fet['housewife'];


    $edu_quali_play_school=$display_query_fet['edu_quali_play_school'];
    $edu_quali_primary=$display_query_fet['edu_quali_primary'];
    $edu_quali_secondary=$display_query_fet['edu_quali_secondary'];
    $edu_quali_high_secondary=$display_query_fet['edu_quali_high_secondary'];
    $edu_quali_non_graduate=$display_query_fet['edu_quali_non_graduate'];
    $edu_quali_graduate=$display_query_fet['edu_quali_graduate'];
    $edu_quali_post_graduate=$display_query_fet['edu_quali_post_graduate'];
    $edu_quali_profession=$display_query_fet['edu_quali_profession'];
    $edu_quali_doctorate=$display_query_fet['edu_quali_doctorate'];  */   

   $out_ajax ='
     <div class="row">
       <div class="col-sm-12">
           <div class="col-sm-6">
               <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Reach</strong></span></div></div>
                  <table class="table table-hover table-stripeds table-curved">
         
                    <tbody>
                    <tr>
                            <td align="left">No Of Loans</td>
                            <td class="td">'.$no_of_loans.'</td>
                    </tr>
                    <tr>
                            <td align="left">Loan Disbursement</td>
                            <td class="td">'.number_format($loan_disbursement,2).'</td>
                    </tr>
                    <tr>
                            <td align="left">Loan O/S</td>
                            <td class="td">'.number_format($loan_outstanding,2).'</td>
                    </tr>
                    <tr>
                            <td align="left"><strong>Overdues<strong></td><td></td>
                    </tr>
                    <tr>
                            <td align="left">Total</td>
                            <td class="td">'.number_format($overdues_total,2).'</td>
                    </tr>	
                    <tr>
                            <td align="left">&lt;=5</td>
                            <td class="td">'.number_format($overdue_5,2).'</td>
                    </tr>
                    <tr>
                            <td align="left">6-10</td>
                            <td class="td">'.number_format($overdue_6_to_10,2).'</td>
                    </tr>
                    <tr>
                            <td align="left">11-15</td>
                            <td class="td">'.number_format($overdue_11_to_15,2).'</td>
                    </tr>
                    <tr>
                            <td align="left">16-30</td>
                            <td class="td">'.number_format($overdue_16_to_30,2).'</td>
                    </tr>
                    <tr>
                            <td align="left" class="td">31-60</td>
                            <td class="td">'.number_format($overdue_31_to_60,2).'</td>
                    </tr>
                    <tr>
                            <td align="left">&gt;60</td>
                            <td class="td">'.number_format($overdue_60,2).'</td>
                    </tr>

                    <tr>
                            <td align="left">Interest Earned</td>
                            <td class="td">'.number_format($overdue_interest_earned,2).'</td>
                    </tr>
                    </tbody>
             </table>
           </div>
           <div class="col-sm-6">
              <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Benefited</strong></span></div></div>
                  <table class="table table-hover table-stripeds table-curved">
                    <tbody>
                    <tr>
                            <td align="left"><strong>Annual Income<strong></td><td></td>
                    </tr>
                    <tr>
                            <td align="left">Below 50,000</td>
                            <td class="td">'.$annual_income_bellow_50thousand.'%</td>
                    </tr><tr>
                            <td align="left">50,000-1,00,000</td>
                            <td class="td">'.$annual_income_50thou_to_1lakh.'%</td>
                    </tr><tr>
                            <td align="left">1,00,001-2,00,000</td>
                            <td class="td">'.$annual_income_1lakh_to_2lakh.'%</td>
                    </tr><tr>
                            <td align="left">2,00,001-3,00,000</td>
                            <td class="td">'.$annual_income_2lakh_to_3lakh.'%</td>
                    </tr><tr>
                            <td align="left">3,00,001-4,00,000</td>
                            <td class="td">'.$annual_income_3lakh_to_4lakh.'%</td>
                    </tr><tr>
                            <td align="left">4,00,001-5,00,000</td>
                            <td class="td">'.$annual_income_4lakh_to_5lakh.'%</td>
                    </tr><tr>
                            <td align="left">5,00,001-6,00,000</td>
                            <td class="td">'.$annual_income_5lakh_to_6lakh.'%</td>
                    </tr><tr>
                            <td align="left">6,00,001-7,00,000</td>
                            <td class="td">'.$annual_income_6lakh_to_7lakh.'%</td>
                    </tr><tr>
                            <td align="left">7,00,001-8,00,000</td>
                            <td class="td">'.$annual_income_7lakh_to_8lakh.'%</td>
                    </tr><tr>
                            <td align="left">8,00,001-9,00,000</td>
                            <td class="td">'.$annual_income_8lakh_to_9lakh.'%</td>
                    </tr><tr>
                            <td align="left">9,00,001-10,00,000</td>
                            <td class="td">'.$annual_income_9lakh_to_10lakh.'%</td>
                    </tr><tr>
                            <td align="left">10,00,001 or more</td>
                            <td class="td">'.$annual_income_above_10lakh.'%</td>
                    </tr>
                  </tbody>
               </table>
            </div>
        </div>
        <div class="col-sm-12">
           <div class="col-sm-6">
               <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Age</strong></span></div></div>

               <table class="table table-hover table-stripeds table-curved"><tbody>
                   
                    <tr>
                            <td align="left">1-5</td>
                            <td class="td">'.$age_1_to_5.'%</td>
                    </tr><tr>
                            <td align="left">6-10</td>
                            <td class="td">'.$age_6_to_10.'%</td>
                    </tr><tr>
                            <td align="left">11-15</td>
                            <td class="td">'.$age_11_to_15.'%</td>
                    </tr><tr>
                            <td align="left">16-20</td>
                            <td class="td">'.$age_16_to_20.'%</td>
                    </tr><tr>
                            <td align="left">21-25</td>
                            <td class="td">'.$age_21_to_25.'%</td>
                    </tr><tr>
                            <td align="left">26-30</td>
                            <td class="td">'.$age_26_to_30.'%</td>
                    </tr><tr>
                            <td align="left">31-35</td>
                            <td class="td">'.$age_31_to_35.'%</td>
                    </tr><tr>
                            <td align="left">36-40</td>
                            <td class="td">'.$age_36_to_40.'%</td>
                    </tr><tr>
                            <td align="left">41-45</td>
                            <td class="td">'.$age_41_to_45.'%</td>
                    </tr><tr>
                            <td align="left">46-50</td>
                            <td class="td">'.$age_46_to_50.'%</td>
                    </tr><tr>
                            <td align="left">51-55</td>
                            <td class="td">'.$age_51_to_55.'%</td>
                    </tr><tr>
                            <td align="left">56-60</td>
                            <td class="td">'.$age_56_to_60.'%</td>
                    </tr></tbody></table>
           </div>
           <div class="col-sm-6">
              <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Sex</strong></span></div></div>

                           <table class="table table-hover table-stripeds table-curved">
                                <tbody>
                       <tr>
                            <td align="left">Male</td>
                            <td class="td">'.$male.'%</td>
                    </tr><tr>
                            <td align="left">Female</td>
                            <td class="td">'.$female.'%</td>
                    </tr><tr>
                            <td align="left">Transgender</td>
                            <td class="td">'.$transgender.'%</td>
                    </tr><tr>
                            <td align="left">Pwds</td>
                            <td class="td">'.$pwds.'%</td>
                    </tr></tbody></table>

                     <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Occupation</strong></span></div></div>
                    <table class="table table-hover table-stripeds table-curved"><tbody>
                     
                    <tr>
                            <td align="left">Salaried</td>
                            <td class="td">'.$salaried.'%</td>
                    </tr>
                    <tr>
                            <td align="left">Self Employed/Professionals</td>
                            <td class="td">'.$selfemployed_professionals.'%</td>
                    </tr>
                    <tr>
                            <td align="left">Business</td>
                            <td class="td">'.$business.'%</td>
                    </tr>
                    <tr>
                            <td align="left">Retired</td>
                            <td class="td">'.$retired.'%</td>
                    </tr>
                    <tr>
                            <td align="left">Student</td>
                            <td class="td">'.$student.'%</td>
                    </tr>
                    <tr>
                            <td align="left">Housewife</td>
                            <td class="td">'.$housewife.'%</td>
                    </tr></tbody></table>

           </div>
        </div>
        <div class="col-sm-12">
           <div class="col-sm-6">
               <div class="form-group"><div class="col-md-6"><span class="text-primary"><strong>Education Qualification</strong></span></div></div>

                 <table class="table table-hover table-stripeds table-curved"><tbody>                   
                     <tr>
                            <td align="left">Play School</td>
                            <td class="td">'.$edu_quali_play_school.'%</td>
                    </tr><tr>
                            <td align="left">Primary </td>
                            <td class="td">'.$edu_quali_primary.'%</td>
                    </tr><tr>
                            <td align="left">Secondary</td>
                            <td class="td">'.$edu_quali_secondary.'%</td>
                    </tr><tr>
                            <td align="left">Higher Secondary</td>
                            <td class="td">'.$edu_quali_high_secondary.'%</td>
                    </tr><tr>
                            <td align="left">Non Graduate</td>
                            <td class="td">'.$edu_quali_non_graduate.'%</td>
                    </tr><tr>
                            <td align="left">Graduate</td>
                            <td class="td">'.$edu_quali_graduate.'%</td>
                    </tr><tr>
                            <td align="left">Postgraduate</td>
                            <td class="td">'.$edu_quali_post_graduate.'%</td>
                    </tr><tr>
                            <td align="left">Professional</td>
                            <td class="td">'.$edu_quali_profession.'%</td>
                    </tr><tr>
                            <td align="left">Doctorate</td>
                            <td class="td">'.$edu_quali_doctorate.'%</td>
                    </tr></tbody>
                  </table>
            </div>
            <div class="col-sm-6"></div>
       </div>';

   $out_ajax.=' <div class="col-sm-12" ><div class="col-sm-6"><span class="text-muted">Report Generated On '.date("D M j, Y ").' at '.date("h:i A").' </span></div><div class="col-sm-6"></div></div>';
    
//}
echo $out_ajax;

