<?
include("../../dash_header.php");
$report_name='LOAN PRODUCT BRANCH WISE REPORT';

?>
<script>
function generate_loan_purpose(pids,mbtids,bids,fdate,tdate) { /*--new_cron_function*/
//alert(pid+"---"+mbtid+"---"+bid);
var pid=$("#"+pids).val();
var bid=$("#"+bids).val();
var mbtid=$("#"+mbtids).val();
var rand=Math.random();
if(mbtid == "") {
	alert("Please select the MBT");
	return false;
}
if(bid == "") {
	alert("Please Select the Branch");
	return false;
}
if(pid == "") {
	alert("Please select the Loan product");
	return false;
}
 setTimeout(function(){   document.getElementById("ajaxloader").style.display="block";}, 10);

	$.get('loan_product_ajax.php',{productid:pid,fromdate:fdate,todate:tdate,rand:rand,bid:bid,mbtid:mbtid},
		function (resp) {
		//alert(resp);
                if(resp != '')
                    {
			document.getElementById('divlevel').innerHTML = resp;
                         document.getElementById("ajaxloader").style.display="none";
                    }
               else
                   {
                      alert("Please Select the Current Financial Year and not generated the cron this year.");
                   }
	     }
	);
}
</script>
<div class="page-content inset">
	
    <div class="row">
	
	<div class="col-md-12">
		<ol class="breadcrumb">
                        <li><a href="#">Dashboard</a></li>
                        <li><a href="#">Reports</a> </li>
                        <li class="active"><?=$report_name;?></li>
                    </ol>
	</div>
	
	<div class="col-md-12">
		<div class="alert alert-info alert-dismissible" role="alert">
		    Please You Can View the <?=$report_name;?>.
		</div>
	</div>
	
	<div class="col-sm-3 clear-right-padding">
			<? include ("left_menu_reports.php"); ?>
	</div>
	<div class="col-sm-9">
	        <div class="well">
	         <form class="form-horizontal" method="post" name="loan_ledger_rep_form" id="loan_ledger_rep_form">
			<h2 class="view-info-underline"><?=$report_name;?></h2>
<!------------------------ MBT Type creation----------------------------------------------------------------------->
<div class="col-sm-12">
    <div class="col-sm-3">
        <label class="control-label"> <b>Select the MBT Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <select class="form-control" name="mbt_type" id="mbt_type">
            <option value="">Select MBT Name</option>
            <option value="0">All MBT</option>
            <?php
            $fd = mysql_query("SELECT * FROM mfi_registration WHERE mfistatus=1 AND status=1");
            $count=mysql_num_rows($fd);
            if($count >0)
            {
                while($res = mysql_fetch_object($fd)) {
                echo "<option value='".$res->iid."'>".str_replace("-"," ",$res->mfiname)."</option>";
                }
                mysql_free_result($fd);
            }
            ?>
        </select>
    </div>
</div>
<br><br><br>

<!-----------------------------------MBT type created--------------------------------------------------------------------->

<!------------------------ Level Type creation----------------------------------------------------------------------->


<div class="col-sm-12">
    <div class="col-sm-3">
     <label class="control-label"> <b>Select the Branch Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
        <select class="form-control" name="level_type" id="level_type">
        <option value=" ">Select Level</option>
        <option value="0">All Branches</option>
        <?php
        $fd = mysql_query("SELECT bid,branchofficename FROM sjdt1_alagumeena.branch_registration WHERE approve_status=1 AND status=1 AND bid in (2024,2022,2021,2008,2007,2001)");
        while($res = mysql_fetch_object($fd)) {
        echo "<option value='".$res->bid."'>".str_replace("-"," ",$res->branchofficename)."</option>";
        }
        mysql_free_result($fd);
        ?>
        </select>
    </div>
</div><BR><BR><BR>
<!-----------------------------------level type created--------------------------------------------->
<!------------------------ Product Type creation----------------------------------------------------------------------->
<div class="col-sm-12">
    <div class="col-sm-3">
    <label class="control-label"> <b>Select the Product Name: <span class="star">*</span></b> </label>
    </div>
    <div class="col-sm-6">
    <select class="form-control" name="product_type" id="product_type" >
    <option value="">Select Products </option>
    <option value="0">All Products</option>
   <?php
	$pnames = mysql_query("SELECT * FROM sjdt1_alagumeena.loan_purpose");
	while($res=mysql_fetch_object($pnames)){
		echo "<option value='".$res->id."'>".$res->purposename."</option>";
	}
	mysql_free_result($pnames);

    ?>

    </select>
    </div>
</div><BR><BR><BR>
<!-----------------------------------Product type created--------------------------------------------------------------------->
              <div class="col-sm-12">
                            <div class="col-sm-3"></div>
                            <div class="col-sm-6">
                                <a href="#" class="btn btn-default btn-lg" onclick="generate_loan_purpose('mbt_type','level_type','product_type','','');">Show Reports</a>
                            </div>
                            <div class="col-sm-3"></div>
                        </div><BR><BR><BR>
                         <div id="ajaxloader" style=" display: none;">
                    <div  align="center">
                        <img src="<?=$microfin_application_url;?>/themes/images/ajax-loader.gif" width="54" height="55"><br /><br />
                        <span >Please wait loading reports..</span>
                    </div>
                </div>
            <div class="row">
                <div class="col-md-12">
                    <div id="divlevel">                
                    </div>
                </div>
            </div>
			
			                      
		
			
			<!--span class="text-muted">Report Generated On <?=date("D M j, Y ");?> at <?=date("h:i A");?></span-->
		 </form>
		 
	        </div>
	</div>	
    </div>
</div>	
<?
include ("../../dash_footer.php");
?>






