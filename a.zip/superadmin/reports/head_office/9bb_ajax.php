<?php
include("../../db_connect.php");
error_reporting("0");
$iid = $_SESSION['iid'];
$type=$_GET['type']; //with staff=1 without staff=0
$mbtid = $_GET['mbtid'];
$finyear=$_SESSION['fromyear'];
$fdate = explode("-",$_GET['fromdate']);
$fromdate = mktime(0,0,0,$fdate[1],$fdate[0],$fdate[2]);
$tdate = explode("-",$_GET['todate']);
$todate = mktime(0,0,0,$tdate[1],$tdate[0],$tdate[2]);


echo '<table class="table table-hover table-striped table-curved">    
      <tbody>
        <tr> 
        <th>Particulars</th>
        <th >2016 - 2017</th>
        <th >2015 - 2016</th>
        </tr>
        <tr >
        <td >Loan disbursements(In Rs.)</td><td class="right">20,490,000.00</td>  
        <td class="right">150,705,000.00</td> 
        </tr>
            <tr >
            <td>Number of SHGs given Loans - TOTAL</td>  <td class="right">1296</td>  <td class="right">9075</td> 
            </tr>
            <tr >
            <td>Number of Client borrowers - New</td><td class="right">1296</td><td class="right">9074</td>
            </tr>

            <tr >
            <td>Number of Client borrowers - Re-loaned</td><td class="right">0</td><td class="right">1</td>
            </tr>

            <tr >
            <td>Number of Client borrowers - TOTAL</td>
            <td class="right">1296</td>   <td class="right">9075</td> 
            </tr>

            <tr >
            <td>Average per captia loan size (In Rs.)</td><td class="right">15810.19</td>  <td class="right">16606.61</td>
            </tr>

            <tr >
            <td>Average loan size per SHG (In Rs.)</td><td class="right">259367.09</td>  <td class="right">246250</td>
            </tr>

            <tr >
            <td>Active borrowers at end of the year</td><td class="right">1296</td> <td class="right">9075</td>
            </tr>

            <tr >
            <td>Number of SHGs enrolled(incl.groups pending under orientation)</td><td class="right">183</td><td class="right">565</td>
            </tr>

            <tr >
            <td>Number of members enrolled (incl.Clients pending under orientation)</td><td class="right">2686</td><td class="right">7657</td>
            </tr>

            <tr >
            <td>On Time Repayment Rate (%)</td><td class="right">45.10 % </td><td class="right">74.40 % </td>
            </tr>        
        </tbody>
    </table>
    


    <table class="table table-hover table-striped table-curved">
     <tbody>
            <tr > 
            <th colspan="3" ><strong>Loan Disbursement-Branch-wise(in Rs.)</strong></td></th>
            <tr >
            <th >BRANCHES</th>
            <th>2016 - 2017</th>
            <th>2015 - 2016</th>
            </tr>
                <tr ><td>Tranqubar</td>
                <td class="right">3,370,000.00</td>
                <td class="right">18,840,000.00</td>
                </tr><tr ><td>Avudayarkovil</td>
                <td class="right">3,445,000.00</td>
                <td class="right">22,510,000.00</td>
                </tr><tr ><td>Sirkazhi</td>
                <td class="right">4,305,000.00</td>
                <td class="right">24,090,000.00</td>
                </tr><tr ><td>Karaikal </td>
                <td class="right">2,930,000.00</td>
                <td class="right">28,325,000.00</td>
                </tr><tr ><td>Vallioor</td>
                <td class="right">4,115,000.00</td>
                <td class="right">28,505,000.00</td>
                </tr><tr ><td>Aranthanki</td>
                <td class="right">2,325,000.00</td>
                <td class="right">28,435,000.00</td>
                </tr><tr >
                <td align="center"><strong>TOTAL</strong></td>
                <td class="right"><strong>20,490,000.00</strong></td> 
                <td class="right"><strong>150,705,000.00</strong></td>
                </tr>              
            </tbody>
       </table>
       
       <table class="table table-hover table-striped table-curved">
            <tbody>
               <tr > 
                <th colspan="5"><strong>Loan Disbursement-Product-wise</strong></th></tr>
                <tr >
                <th >Type of Product</th>
                <th colspan="2">2016 - 2017</th>
                <th colspan="2">2015 - 2016</th>
                </tr>

                    <tr >
                      <th >Group Loan</th>
                      <th >No.of Loans</th>
                      <th >Amount Funded(Rs)</th>
                      <th >No.of Loans</th>
                      <th >Amount Funded(Rs)</th>
                    </tr><tr > <td>Agriculture</td>    
                         <td class="right">46</td>
                         <td class="right">690,000.00</td>
                         <td class="right">836</td>
                         <td class="right">13,485,000.00</td>
                     </tr><tr > <td>Small Business</td>    
                         <td class="right">413</td>
                         <td class="right">6,560,000.00</td>
                         <td class="right">2782</td>
                         <td class="right">46,405,000.00</td>
                     </tr><tr > <td>Milch Animal</td>    
                         <td class="right">647</td>
                         <td class="right">10,300,000.00</td>
                         <td class="right">3583</td>
                         <td class="right">59,690,000.00</td>
                     </tr><tr > <td>Self Employment</td>    
                         <td class="right">131</td>
                         <td class="right">2,045,000.00</td>
                         <td class="right">1522</td>
                         <td class="right">25,125,000.00</td>
                     </tr><tr > <td>Housing</td>    
                         <td class="right">22</td>
                         <td class="right">340,000.00</td>
                         <td class="right">107</td>
                         <td class="right">1,870,000.00</td>
                     </tr><tr > <td>Fishing and Connected Business</td>    
                         <td class="right">36</td>
                         <td class="right">540,000.00</td>
                         <td class="right">233</td>
                         <td class="right">3,900,000.00</td>
                     </tr><tr > <td>Educational</td>    
                         <td class="right">1</td>
                         <td class="right">15,000.00</td>
                         <td class="right">12</td>
                         <td class="right">230,000.00</td>
                     </tr><tr >
                     <td align="center"><strong>TOTAL</strong></td>
                      <td class="right"><strong>1296</strong></td>
                      <td class="right"><strong>20,490,000.00</strong></td> 
                      <td class="right"><strong>9075</strong></td>
                      <td class="right"><strong>150,705,000.00</strong></td>
                    </tr> 
              </tbody>
         </table>

	<table class="table table-hover table-striped table-curved">
		<tr > 
			<th colspan=5 ><strong>Analysis of Portfolio at Risk</strong></th>
		</tr>
		<tr > 
			<th rowspan=3 align="center" ><strong>Particulars</strong></th>
			<th colspan=4 align="center" ><strong>Portfolio at Risk as at</strong></th>
		</tr>
		<tr > 
			<th colspan=2 align="center"><strong>2016 - 2017</strong></th>
			<th colspan=2 align="center"><strong>2015 - 2016</strong></th>
		</tr>
		<tr > 
			<th align="center" ><strong>Amount</strong></th>
			<th align="center" ><strong>%</strong></th>
			<th align="center" ><strong>Amount</strong></th>
			<th align="center" ><strong>%</strong></th>
		</tr>
		<tr > 
 			<td>Current</td>
			<td width="15%" class="right">70,718,560.00</td>
			<td class="right" width="15%">99.80%</td>
			<td width="15%" class="right">86,932,252.00</td>
			<td class="right" width="15%">99.95%</td>
		</tr>
		<tr > 
 			<td>1-30 days late</td>
			<td width="15%" class="right">101,317.00</td>
			<td class="right" width="15%">0.14%</td>
			<td width="15%" class="right">17,418.00</td>
			<td class="right" width="15%">0.02%</td>
		</tr>
		<tr > 
 			<td>31-60 days late</td>
			<td width="15%" class="right">5,887.00</td>
			<td class="right" width="15%">0.01%</td>
			<td width="15%" class="right">28,667.00</td>
			<td class="right" width="15%">0.03%</td>
		</tr>
		<tr > 
 			<td>61-90 days late</td>
			<td width="15%" class="right">24,735.00</td>
			<td class="right" width="15%">0.03%</td>
			<td width="15%" class="right">0.00</td>
			<td class="right" width="15%">0.00%</td>
		</tr>
		<tr > 
 			<td>91-120 days late</td>
			<td width="15%" class="right">7,639.00</td>
			<td class="right" width="15%">0.01%</td>
			<td width="15%" class="right">271.00</td>
			<td class="right" width="15%">0.00%</td>
		</tr>
			<tr > 
 			<td>More than 120 days late</td>
			<td width="15%" class="right">0.00</td>
			<td class="right" width="15%">0.00%</td>
			<td width="15%" class="right">0.00</td>
			<td class="right" width="15%">0.00%</td>
		</tr><tr >
				<td align="center"><strong>TOTAL</strong></td>
				<td class="right"><strong>70,858,138.00</strong></td>
				<td class="right"><strong>100.00%</strong></td>
				<td class="right"><strong>86,978,608.00</strong></td>
				<td class="right"><strong>100.00%</strong></td>
			</tr>
             </tbody>
       </table>

     <table class="table table-hover table-striped table-curved">
      <tbody>
            <tr > 
            <th colspan=3 ><strong>On-time Repayment Rate/Delinquency rate</strong></th>
            </tr><tr >
            <th >Particulars</th>
            <th  align="center"><strong>2016 - 2017</strong></td>
            <th  align="center"><strong>2015 - 2016</strong></td>
            </tr><tr >
            <td class="left">1st Quarter</td>
            <td class="right">87.22%</td>
            <td class="right">66.8%</td>
            </tr><tr >
            <td class="left">2st Quarter</td>
            <td class="right">2.98%</td>
            <td class="right">70.92%</td>
            </tr><tr >
            <td class="left">3st Quarter</td>
            <td class="right">0%</td>
            <td class="right">78.85%</td>
            </tr><tr >
            <td class="left">1st Quarter</td>
            <td class="right">0%</td>
            <td class="right">81.04%</td>
            </tr><tr >
            <td align="center"><strong>TOTAL</strong></td>
            <td class="right">45.10%</td>
            <td class="right">74.40%</td>
            </tr>
         <tbody>
      </table>';
echo '<span class="text-muted">Report Generated On '.date("D M j, Y ").' at '.date("h:i A").' </span>';
?>

