<?php
include("../../db_connect.php");
error_reporting("0");
$iid = $_SESSION['iid'];
$type=$_GET['type']; //with staff=1 without staff=0
$pid=$_GET['pid'];
$bid = $_GET['bid'];
$mbtid = $_GET['mbtid'];
$finyear=$_SESSION['fromyear'];
$fdate = explode("-",$_GET['fromdate']);
$fromdate = mktime(0,0,0,$fdate[1],$fdate[0],$fdate[2]);
$tdate = explode("-",$_GET['todate']);
$todate = mktime(0,0,0,$tdate[1],$tdate[0],$tdate[2]);
 //echo "---->".$type."--------".$fromdate."------------".$todate."<BR>";
 /*if( $fromdate != '' &&  $todate !=''){
    //$date_filter_branch_wise="AND c.from_date_filter >= ' $fromdate' AND c.to_date_filter <='$todate' ";

     $date_filter_branch_wise='';
    }

$product_filter="AND c.product_id='$pid'";

$branch_filter="AND b.bid=c.branch_id AND b.approve_status=1 AND b.status=1";

$transaction_filter="AND c.closing_loan_outstanding   != '0'";
$number=time();				  // CREATE RANDOM FILE NAME
$fle_name = $number;



$out.="<table class='table table-hover table-striped table-curved'><tbody>
	<tr>
	<th>Level Name</th>
	<th>Loan Issued</td>
	<th>Principal Opening Loan O/S</th>
	<th>Interest</td>
	<th>Overdues</td>
	<th>Prepayment</td>
	<th>Amt Paid During this period</th>
	<th>Closing Loan O/S</th>
      </tr>";

$branch_name='Not Available';
$loan_issued='0';
$principal_opeing_loan_outstanding='0';
$interest='0';
$overdue='0';
$prepayment='0';
$amount_paid_during_this_period='0';
$closing_loan_outstanding='0';
$loan_issued_total='0';
$principal_opeing_loan_outstanding_total='0';
$interest_total='0';
$overdue_total='0';
$prepayment_total='0';
$amount_paid_during_this_period_total='0';
$closing_loan_outstanding_total='0';

//$display_select="SELECT  branch_name, sum( loan_issued ) AS loan_issued, sum( principal_opeing_loan_outstanding ) AS principal_opeing_loan_outstanding, sum( interest ) AS interest, sum( overdue ) AS overdue, sum( prepayment ) AS prepayment, sum( amount_paid_during_this_period ) AS amount_paid_during_this_period, sum( closing_loan_outstanding ) AS closing_loan_outstanding FROM cron_branch_wise_loan_product WHERE status=1 $product_filter $date_filter_branch_wise GROUP BY (branch_id)";
$display_select="SELECT  *  FROM sjdt1_alagumeena.cron_loan_product_superadmin as c,sjdt1_alagumeena.branch_registration as b WHERE c.status=1 $product_filter $date_filter_branch_wise $branch_filter $transaction_filter";

//echo $display_select."<BR>";
$display_query=mysql_query($display_select) or die("Error -->".mysql_error());
$lev1=1;
$count=mysql_num_rows($display_query);
if($count > 0)
{
 while($display_query_fet=mysql_fetch_array($display_query))
 {
    $branch_name=$display_query_fet['branch_name'];
    $loan_issued=$display_query_fet['loan_issued'];
    $principal_opeing_loan_outstanding=$display_query_fet['principal_opeing_loan_outstanding'];
    $interest=$display_query_fet['interest'];
    $overdue=$display_query_fet['overdue'];
    $prepayment=$display_query_fet['prepayment'];
    $amount_paid_during_this_period=$display_query_fet['amount_paid_during_this_period'];
    $closing_loan_outstanding=$display_query_fet['closing_loan_outstanding'];
    if($lev1%2 == 0)
        $class="level1_tr";
            else
             $class="level2_tr";


    $out.="<tr class='$class' name='trsub".$lev1."' id='trsub".$lev1."'>
                <td>".$branch_name."</a></td>
                <td align='right'>".number_format($loan_issued,2)."</td>
                <td align='right'>".number_format($principal_opeing_loan_outstanding,2)."</td>
                <td align='right'>".number_format($interest,2)."</td>
                <td align='right'>".number_format($overdue,2)."</td>
                <td align='right'>".number_format($prepayment,2)."</td>
                <td align='right'>".number_format($amount_paid_during_this_period,2)."</td>
                <td align='right'>".number_format($closing_loan_outstanding,2)."</td>
           </tr>";


    $loan_issued_total=$loan_issued_total+$loan_issued;
    $principal_opeing_loan_outstanding_total=$principal_opeing_loan_outstanding_total+$principal_opeing_loan_outstanding;
    $interest_total=$interest_total+$interest;
    $overdue_total=$overdue_total+$overdue;
    $prepayment_total=$prepayment_total+$prepayment;
    $amount_paid_during_this_period_total=$amount_paid_during_this_period_total+$amount_paid_during_this_period;
    $closing_loan_outstanding_total=$closing_loan_outstanding_total+$closing_loan_outstanding;
    $lev1++;
 }
}
 else {
    $out.="<tr><tr class='level1_tr' name='trsub".$lev1."' id='trsub".$lev1."'>
                <td colspan='8'></td></tr>";
}

$out.="<tr>
	<td><b><big>Total:</big></b></td>
	<td align='right'><b>".number_format($loan_issued_total,2)."</b></td>
	<td align='right'><b>".number_format($principal_opeing_loan_outstanding_total,2)."</b></td>
	<td align='right'><b>".number_format($interest_total,2)."</b></td>
	<td align='right'><b>".number_format($overdue_total,2)."</b></td>
	<td align='right'><b>".number_format($prepayment_total,2)."</b></td>
	<td align='right'><b>".number_format($amount_paid_during_this_period_total,2)."</b></td>
	<td align='right'><b>".number_format($closing_loan_outstanding_total,2)."</b></td>
</tr></tbody>
</table></tr><tr></table>";


echo $result=$out;*/
echo '<table class="table table-hover table-striped table-curved">
      <tbody>
                <tr>
                <th>Level Name</th>
                <th>Loan Issued
                </th><th>Principal Opening Loan O/S</th>
                <th>Interest
                </th><th>Overdues
                </th><th>Prepayment
                </th><th>Amt Paid During this period</th>
                <th>Closing Loan O/S</th>
           </tr><tr >
                <td>Tranqubar</td>
                <td class="right">2,235,000.00</td>
                <td class="right">10,580,781.00</td>
                <td class="right">537,959.00</td>
                <td class="right">86,504.00</td>
                <td class="right">133,138.00</td>
                <td class="right">4,164,084.00</td>
                <td class="right">9,189,656.00</td>
           </tr><tr >
                <td>Avudayarkovil</td>
                <td class="right">3,445,000.00</td>
                <td class="right">13,484,706.00</td>
                <td class="right">642,452.00</td>
                <td class="right">374,513.00</td>
                <td class="right">28,665.00</td>
                <td class="right">4,984,260.00</td>
                <td class="right">12,587,898.00</td>
           </tr><tr >
                <td>Sirkazhi</td>
                <td class="right">4,305,000.00</td>
                <td class="right">14,388,690.00</td>
                <td class="right">772,626.00</td>
                <td class="right">32,424.00</td>
                <td class="right">903,491.00</td>
                <td class="right">6,015,663.00</td>
                <td class="right">13,450,653.00</td>
           </tr><tr >
                <td>Karaikal </td>
                <td class="right">435,000.00</td>
                <td class="right">15,200,208.00</td>
                <td class="right">733,830.00</td>
                <td class="right">58,625.00</td>
                <td class="right">197,334.00</td>
                <td class="right">6,007,510.00</td>
                <td class="right">10,361,528.00</td>
           </tr><tr >
                <td>Vallioor</td>
                <td class="right">1,380,000.00</td>
                <td class="right">16,887,158.00</td>
                <td class="right">868,945.00</td>
                <td class="right">0.00</td>
                <td class="right">189,445.00</td>
                <td class="right">6,831,025.00</td>
                <td class="right">12,305,078.00</td>
           </tr><tr id="trsub6" name="trsub6" class="level1_tr">
                <td>Aranthanki</td>
                <td class="right">1,395,000.00</td>
                <td class="right">16,437,065.00</td>
                <td class="right">807,030.00</td>
                <td class="right">256,981.00</td>
                <td class="right">193,242.00</td>
                <td class="right">6,282,334.00</td>
                <td class="right">12,356,761.00</td>
           </tr><tr>
                <td><strong>TOTAL:</strong></td>
                <td class="right"><b>13,195,000.00</b></td>
                <td class="right"><b>86,978,608.00</b></td>
                <td class="right"><b>4,362,842.00</b></td>
                <td class="right"><b>809,047.00</b></td>
                <td class="right"><b>1,645,315.00</b></td>
                <td class="right"><b>34,284,876.00</b></td>
                <td class="right"><b>70,251,574.00</b></td>
          </tr>
     </tbody>
</table>';
echo '<span class="text-muted">Report Generated On '.date("D M j, Y ").' at '.date("h:i A").' </span>';
?>

