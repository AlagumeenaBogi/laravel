<?php
    include("dash_header.php");
//$from_filter_dates = explode('-', $first);
//$from_filter_date = mktime(0, 0, 0, $from_filter_dates[1], $from_filter_dates[0], $from_filter_dates[2]);
//$to_filter_dates = explode('-', $last);
//$to_filter_date = mktime(0, 0, 0, $to_filter_dates[1], $to_filter_dates[0], $to_filter_dates[2]);


//$date_filter_risk_wise="AND from_filter_date >=".$from_filter_date." AND to_filter_date <=".$to_filter_date.""; //	from_filter_date //to_filter_date
//
///*---------------------------------Branch Wise Field Agent Performance-------------------------------*/
//
///*---------------------------------Branch Wise Field Agent Performance-------------------------------*/
///*---------------------------------------------------current assets------------------*/
//if($iid != '' && $bid != '')
//    $level_filter="and account_level='$user_level' AND account_level_id='$bid'";
//else
//    $level_filter="and account_level='$user_level' AND account_level_id='$iid'";
//$query="select * from cron_current_assets WHERE status=1  $date_filter_risk_wise $level_filter";
//        //echo $query."<BR>";
//        $select_current_asset = mysql_query($query, $con);
//
//	while($row_current_asset = mysql_fetch_array($select_current_asset))
//	{
//          $current_asset_closing_balance[$row_current_asset['label_name']]=$row_current_asset['amount'];
//        }
//       // echo "<BR>";
//       // print_r($current_asset_closing_balance);
///*----------------------------------------------------current assets---------------*/
///*---------------------------------------------------product performance monitorning------------------*/
//if($iid != '' && $bid != '')
//    $level_filter="and account_level='$user_level' AND account_level_id='$bid'";
//else
//    $level_filter="and mfi_id='$iid'";
//$query="select * from cron_product_wish_loan_dibursement_report  WHERE status=1  $date_filter_risk_wise $level_filter";
//       echo $query."<BR>";
//        $select_current_asset = mysql_query($query, $con);
//         $count=mysql_num_rows($select_current_asset);
//        if($count > 0)
//        {
//	while($row_current_asset = mysql_fetch_array($select_current_asset))
//	{
//          $product_wise_loan_disbursement[]=$row_current_asset['current_year_amount'];
//          $product_wise_category[]="'".$row_current_asset['product_name']."'";
//        }
//        if(is_array($product_wise_loan_disbursement))
//		 $product_wise_loan_disbursement= implode(',', $product_wise_loan_disbursement);
//        if(is_array($product_wise_category))
//		$product_wise_category = implode(',', $product_wise_category);
//        }
//       // echo "<BR>";
//       // print_r($product_wise_loan_disbursement);
///*----------------------------------------------product performance monitorning---------------*/
//
///*----------------------------PORTFOLIA AT RISK_START-------------------------------------------------------*/
//if($iid != '' && $bid != '')
//    $level_filter="AND mfi_id='$bid'";
//else
//    $level_filter="AND mfi_id='$iid'";
//
//$display_select_product="SELECT  * FROM cron_portfolio_at_risk WHERE status=1 $date_filter_risk_wise $level_filter";//echo $display_select."<BR>";
//$display_query_product=mysql_query($display_select_product,$con) or die("Error -->".mysql_error());
//$i=1;
//$count=mysql_num_rows($display_query_product);
//if($count > 0){
//    while($display_query_fet_product=mysql_fetch_array($display_query_product))  {
//        $current_over_due=$display_query_fet_product['cur_year_current_amount'];
//        $par_1_to_30=$display_query_fet_product['cur_year_1_to_30_amount'];
//        $par_31_to_60=$display_query_fet_product['cur_year_31_to_60_amount'];
//        $par_61_to_90=$display_query_fet_product['cur_year_61_to_90_amount'];
//        $par_91_to_120=$display_query_fet_product['cur_year_91_to_120_amount'];
//        $par_above_120=$display_query_fet_product['cur_year_more_120_amount'];
//    }
//}
$current_over_due = '100202';
$par_1_to_30    = '2300';
$par_31_to_60  = '3402';
$par_61_to_90  = '28372';
$par_91_to_120 = '12022';
$par_above_120 = '29822';
$portfolio_at_risk_arr = array(array ("amount" => $current_over_due,"label" => 'current',),array ("amount" => $par_1_to_30,"label" => '1-30 days late',),array ("amount" => $par_31_to_60,"label" => '31-60 days late',),
array ("amount" => $par_61_to_90,"label" => '61-90 days late',),array ("amount" => $par_91_to_120,"label" => '91-120 days late',),
array ("amount" => $par_above_120,"label" => 'above_120',));

//$portfolio_at_risk_arr = array ( [0] => array ( ['amount'] => 39773795 ['label'] => current ) [1] => array ( ['amount'] => '10337516' ['label'] => 1-30 days late ) [2] => array ( [amount] => 10363953 [label] => 31-60 days late ) [3] => array ( [amount] => 822297 [label] => 61-90 days late ) [4] => array ( [amount] => 35744 [label] => 91-120 days late ) [5] => array ( [amount] => 13681 [label] => above_120 ) ) ;

//echo "<pre>";
//print_r($portfolio_at_risk_arr);
//
for ( $row = 0; $row < 6; $row++ ) {
      $portfolio_at_risk[] = "['".$portfolio_at_risk_arr[$row]['label']."' ,".$portfolio_at_risk_arr[$row]['amount']."]";     }
//      print_r($portfolio_at_risk);

if(is_array($portfolio_at_risk))
		$portfolio_at_risk = implode(',', $portfolio_at_risk); 
///*----------------------------PORTFOLIA AT RISK_END-------------------------------------------------------*/


$branch_name=array('karaikal','Tranqubar');
                 ?>
 <div class="page-content inset">
    <!---row_1-->
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li><a href="#">Dashboard</a> </li>
                <li><a href="#"><?=$office;?></a> </li>
            </ol>
            <div class="col-md-12 clear-padding">
                <h1 class="margin-top-ten">Dashboard</h1>
                 <span class="text-muted"><strong> <?=$office;?>  Name :</strong></span>  <span class="text-muted"> MBT Head Office </span><BR>
                <? if($bid == ''){?> <span class="text-muted"> <strong>Reg.No(Govt) : </strong></span> <span class="text-muted"> 37220 </span><?}?>
            </div>
        </div>
    </div>
     <!---end_row_1-->
     <div class="row">
        <div class="dashboard_box">
            <div class="col-md-12">
                <div class="col-md-2 bx-width" style="margin-left: 0">
                    <div class="dashboard_balance_account mbt_text_border">
                        <div class="account_name mbt_text_color">Active MBT</div>
                        <div class="account_balance">
                                <?
                                 $total_mbt = "10";
                                 $active_mbt  = "4";
//                                $groups_active_count =count_migration($user_level,$user_id,$iid,$bid,$fo_id,'active_group_count',$con);
//                                $groups_tot = count_migration($user_level,$user_id,$iid,$bid,$fo_id,'total_group_count',$con);
                                if($total_mbt != "" && $active_mbt != "")
                                        $groups_precent = ($active_mbt / $total_mbt) * 100;
                                echo intval($groups_precent).' % ';
                                ?>
                         </div>
                        <div class="text-center"><?php echo $active_mbt.' out of '.$total_mbt.'';?> </div>
                          <? if($groups_active_count =='0'){?>
                          <div class="text-center">
                                <a href="#"> Add CBOS</a>
                          </div>
                          <? } ?>
			</div>

                    </div>
                  <div class=" col-md-2 bx-width" style="margin-left: 0">
                    <div class="dashboard_balance_account mbt_branch_border">
                        <div class="account_name mbt_branch_color">Active Branch</div>
                        <div class="account_balance">
                                <?
                                 $total_branch = "34";
                                 $active_branch   = "32";
//                                $groups_active_count =count_migration($user_level,$user_id,$iid,$bid,$fo_id,'active_group_count',$con);
//                                $groups_tot = count_migration($user_level,$user_id,$iid,$bid,$fo_id,'total_group_count',$con);
                                if($total_branch != "" && $active_branch != "")
                                        $groups_precent = ($active_branch / $total_branch) * 100;
                                echo intval($groups_precent).' % ';
                                ?>
                         </div>
                        <div class="text-center"><?php echo $active_branch.' out of '.$total_branch.'';?> </div>
                          <? if($groups_active_count =='0'){?>
                          <div class="text-center">
                                <a href="#"> Add CBOS</a>
                          </div>
                          <? } ?>
			</div>

                    </div>

                  <div class ="col-md-2 bx-width" style="margin-left: 0">
                    <div class="dashboard_balance_account liability_border">
                        <div class="account_name liability_text_color">Active Field Officers</div>
                        <div class="account_balance">
                                <?
                                 $total_fo = "98";
                                 $active_fo   = "96";
//                                $groups_active_count =count_migration($user_level,$user_id,$iid,$bid,$fo_id,'active_group_count',$con);
//                                $groups_tot = count_migration($user_level,$user_id,$iid,$bid,$fo_id,'total_group_count',$con);
                                if($total_fo != "" && $active_fo != "")
                                        $groups_precent = ($active_fo / $total_fo) * 100;
                                echo intval($groups_precent).' % ';
                                ?>
                         </div>
                        <div class="text-center"><?php echo $active_fo.' out of '.$total_fo.'';?> </div>
                          <? if($groups_active_count =='0'){?>
                          <div class="text-center">
                                <a href="#"> Add CBOS</a>
                          </div>
                          <? } ?>
			</div>

                    </div>

                <div class="col-md-2 bx-width">
                    <div class="dashboard_balance_account asset_border">
                        <div class="account_name asset_text_color">Active Groups</div>
                         <div class="account_balance">
                                <?
//                                $fo_active_count =count_migration($user_level,$user_id,$iid,$bid,$fo_id,'active_field_officer_count',$con);
//                                $fo_tot = count_migration($user_level,$user_id,$iid,$bid,$fo_id,'total_field_officer_count',$con);
//
                                  $total_grp = "4568";
                                 $active_grp  = "4548";

                                if($total_grp != "" && $active_grp != "")
                                        $fo_precent = ($active_grp / $total_grp) * 100;
                                echo intval($fo_precent).' % ';
                              
                                ?>
                         </div>
                        <div class="text-center"><?php echo $active_grp.' out of '.$total_grp.'';?> </div>
                          <? if($fo_active_count =='0'){?>
                          <div class="text-center">
                                <a href="#"> Add Field Officer</a>
                          </div>
                          <? } ?>
                    </div>
                </div>

                <div class="col-md-2 bx-width">
                    <div class="dashboard_balance_account income_border">
                        <div class="account_name income_text_color">Active Customers</div>
                         <div class="account_balance">
                                <?
//                                $customer_active_count =count_migration($user_level,$user_id,$iid,$bid,$fo_id,'active_customer_count',$con);
//                                $customer_tot = count_migration($user_level,$user_id,$iid,$bid,$fo_id,'total_customer_count',$con);
                                $total_customer ="33722";
                                $active_customer = "33467";
                                if($total_customer != "" && $active_customer != "")
                                        $customer_precent = ($active_customer / $total_customer) * 100;
                                echo intval($customer_precent).' % ';
                               
                                ?>
                         </div>
                        <div class="text-center"><?php echo $active_customer.' out of '.$total_customer.'';?> </div>
                          <? if($customer_active_count =='0'){?>
                          <div class="text-center">
                                <a href="#"> Add Customer</a>
                          </div>
                          <? } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <?php
                      $branch_name = "'Madurai MBT','Trichy MBT' ,'Chennai MBT','Delhi MBT'";
//                      $values            = array('100200','132002' ,'122000', '140320');
//                      $no_of_field_officer =array('120901','11000');;
//                      $disbursement_amount =array('12201','10239');
//                      $no_of_group = array('1201','1302');
//                      $no_of_customer = array('23021','21083');
                         $no_of_branch   = "4,5,3";
                         $no_of_field_officer = "18,23,14";
                         $disbursement_amount ="123201,130239,903002";
               

     ?>
    

    <div class="col-md-12 padding-top-ten">
            <div class="row">
                	<div class="col-md-6 clear-right-padding">
				<div class="view-info">
					<div class="view-info-content" style="min-height: 300px;">
						<h3 class="lead">MBT Wise Field Agent Performance</h3>
<!--                                                      <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>-->
                                                      <script type="text/javascript">

                                                            $(function () {

                                                                                        Highcharts.setOptions({
                                                                                                  lang: {
                                                                                                      drillUpButton: 'Go Back'
                                                                                                  }
                                                                                        });

                                                                                        // Create the chart
                                                                                        $('#field_agent_performance_chart').highcharts({
                                                                                            chart: {
                                                                                                type: 'bar',
                                                                                                events: {
                                                                                                    drillup: function (e) {
                                                                                                        alert('drill Up');
                                                                                                        console.log(this);
                                                                                                        console.log(this.options.series[0].name);
                                                                                                        console.log(this.options.series[0].data[0].name);
                                                                                                    }
                                                                                                }
                                                                                            },
                                                                                            title: {
                                                                                                text: ' '
                                                                                            },
                                                                                            xAxis: {
                                                                                                type: 'category'
                                                                                            },

                                                                                            legend: {
                                                                                                enabled: false
                                                                                            },

                                                                                            plotOptions: {
                                                                                                series: {
                                                                                                    borderWidth: 0,
                                                                                                    dataLabels: {
                                                                                                        enabled: true
                                                                                                    }
                                                                                                }
                                                                                            },

                                                                                            series: [{
                                                                                                name: 'Things',
                                                                                                colorByPoint: true,
                                                                                                
                                                                                                data: [{
                                                                                                    name: 'Madurai MBT',
                                                                                                    y: 5,
                                                                                                    drilldown: 'madurai'
                                                                                                }, {
                                                                                                    name: 'Nilakkottai MBT',
                                                                                                    y: 2,
                                                                                                    drilldown: 'nilakkottai'
                                                                                                }, {
                                                                                                    name: "Theni MBT",
                                                                                                    y: 4
                                                                                                }]
                                                                                            }],
                                                                                            drilldown: {
                                                                                                            drillUpButton: {
                                                                                                                relativeTo: 'spacingBox',
                                                                                                                position: {
                                                                                                                    y: 0,
                                                                                                                    x: 0
                                                                                                                },
                                                                                                                theme: {
                                                                                                                    fill: 'white',
                                                                                                                    'stroke-width': 1,
                                                                                                                    stroke: 'silver',
                                                                                                                    r: 0,
                                                                                                                    states: {
                                                                                                                        hover: {
                                                                                                                            fill: '#99E9F4'
                                                                                                                        },
                                                                                                                        select: {
                                                                                                                            stroke: '#039',
                                                                                                                            fill: '#99E9F4'
                                                                                                                        }
                                                                                                                    }
                                                                                                                }

                                                                                                },
                                                                                                series: [{
                                                                                                    id: 'madurai',
                                                                                                    data: [
                                                                                                        ['Annanagar', 4],
                                                                                                        ['Simmakal', 2],
                                                                                                        ['kalavasal', 1],
                                                                                                        ['Thirunagar', 2],
                                                                                                        ['Villangudi', 1]
                                                                                                    ]
                                                                                                }, {
                                                                                                    id: 'nilakkottai',
                                                                                                    data: [
                                                                                                        ['Madurai MBT', 4],
                                                                                                        ['Theni MBT', 2],
                                                                                                        ['Nillakottai MBT', 3]
                                                                                                    ]
                                                                                                }]
                                                                                            }
                                                                                        })
                                                                      });


//                                                                  $(function () {
//								$('#field_agent_performance_chart')
//									.highcharts({
//										chart: {
//											type: 'column',
//                                                                                                   inverted: true,
//											plotBackgroundColor: null,
//											backgroundColor: 'rgba(255, 255, 255, 0.1)'
//										},
//										colors: [
//												'#8BBC21','#ff0000','#A52A2A',
//												'#263C53'
//											],
//										exporting: {
//											enabled: false
//										},
//										title: {
//											text: ''
//										},
//										xAxis: {
////											categories: ["Madurai MBT"] //if($iid !='' && $bid !=''){echo $field_officer_name;} else {
//											categories: [<?=$branch_name;?>] //if($iid !='' && $bid !=''){echo $field_officer_name;} else {
//
//										},
//										yAxis: {
//											min: 0,
//											title: {
//												text: ''
//											}
//										},
//										tooltip: {
//											headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
//											pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
//												'<td style="padding:0"><b>&#8377; {point.y}</b></td></tr>',
//											footerFormat: '</table>',
//											shared: true,
//											useHTML: true
//										},
//										plotOptions: {
//											column: {
//												pointPadding: 0.2,
//												borderWidth: 0
//											}
//										},
//
//										credits: {
//											enabled: false
//										},
//										series: [
//                                                                                                       {
//                                                                                                                     name: 'No of Branch',
//                                                                                                                     data: [<?=$no_of_branch;?>]
//
//                                                                                                         },
//                                                                                                          {
//                                                                                                                     name: 'No of Field Officer',
//                                                                                                                     data: [<?=$no_of_field_officer;?>]
//
//                                                                                                                     },
//                                                                                                          {
//                                                                                                                     name: 'Disbursed Amount',
//                                                                                                                     data: [<?=$disbursement_amount;?>]
//
//                                                                                                           }
//                                                                                                        ]
//									});
//							});
                                    </script>

         	<? if ($branch_name != ''){?>	<div id="field_agent_performance_chart"></div><?}else {?><br><br><br><center><span class="text-muted">Record Not Found!</span></center><?}?>

													</div>
					</div>
				</div>


               

                <div class="col-md-6 clear-right-padding">
                    <div class="view-info">
                        <div class="view-info-content" style="min-height: 300px;">
                            <h3 class="lead">MBT Wise Portfolio at Risk</h3>

                                <script lang="javascript" type="text/javascript">

                                $(function () {
    // Create the chart
                                                     Highcharts.setOptions({
                                                        lang: {
                                                            drillUpText: ''
                                                        }
                                                    });
                                                    $('#portfolio_at_risk_chart').highcharts({
                                                        chart: {
                                                            type: 'pie',
                                                            events: {
                                                                              drillup: function (e) {
                                                                                      alert('drill Up');
                                                                                      console.log(this);
                                                                                      console.log(this.options.series[0].name);
                                                                                      console.log(this.options.series[0].data[0].name);
                                                                              }
                                                                  }
                                                        },
                                                        title: {
                                                            text: ''
                                                        },
                                                        subtitle: {
                                                           text: ''
                                                        },
                                                        plotOptions: {
                                                            series: {
                                                                dataLabels: {
                                                                    enabled: true,
                                                                    format: '{point.name}: {point.y:.1f}%'
                                                                }
                                                            }
                                                        },

                                                        tooltip: {
                                                            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                                                            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
                                                        },
                                                        series: [{
                                                            name: 'Brands',
                                                            colorByPoint: true,
                                                            data: [{
                                                                name: 'Madurai MBT',
                                                                y: 100,
                                                                drilldown: 'Madurai'
                                                            }, {
                                                                name: 'Nillakottai MBT',
                                                               y: 100,
                                                                drilldown: 'Nillakottai'
                                                            }, {
                                                                name: 'Theni MBT',
                                                                  y: 100,
                                                                drilldown: 'Theni'
                                                            }]
                                                        }],
                                                        drilldown: {

                                                                          drillUpButton: {
                                                                                  relativeTo: 'spacingBox',
                                                                                  position: {
                                                                                      y: 0,
                                                                                      x: 0
                                                                                  },
                                                                                  theme: {
                                                                                      fill: 'white',
                                                                                      'stroke-width': 1,
                                                                                      stroke: 'silver',
                                                                                      r: 0,
                                                                                      states: {
                                                                                          hover: {
                                                                                              fill: '#bada55'
                                                                                          },
                                                                                          select: {
                                                                                              stroke: '#039',
                                                                                              fill: '#bada55'
                                                                                          }
                                                                                      }
                                                                                  }

                                                                              },

                                                                series: [{
                                                                name: 'Madurai MBT',
                                                                id: 'Madurai',
                                                                data: [
                                                                    ['Current', 44.00],
                                                                    ['1-30 days', 16.00],
                                                                    ['30-60 days', 22.00],
                                                                    ['60-90 days', 12.00],
                                                                    ['above 90 days', 6.00],
                                                                 
                                                                ]
                                                            }, {
                                                                name: 'Nillakottai MBT',
                                                                id: 'Nillakottai',
                                                                data: [
                                                                    ['Current', 38.00],
                                                                    ['1-30 days', 22.00],
                                                                    ['30-60 days', 24.00],
                                                                    ['60-90 days', 12.00],
                                                                    ['above 90 days', 4.00],
                                                                ]
                                                            }, {
                                                                name: 'Theni MBT',
                                                                id: 'Theni',
                                                                data: [

                                                                    ['Current', 37.00],
                                                                    ['1-30 days', 13.00],
                                                                    ['30-60 days',18.00],
                                                                    ['60-90 days', 22.00],
                                                                    ['above 90 days', 10.00],
                                                                ]
                                                            }]
                                                        }
                                                    });
                                                });
                                          

//                                            $(function () {
//
//                                                                                  var colors = Highcharts.getOptions().colors,
//                                                                                      categories = ['Madurai MBT', 'Nillakottai MBT', 'Theni MBT'],
//                                                                                      data = [{
//                                                                                          y: 56.3,
//                                                                                          color: colors[0],
//                                                                                          drilldown: {
//                                                                                              name: 'Madurai MBT',
//                                                                                              categories: ['1-30 days ( 10020 )', '30-60 days ( 20102)', '60-90 days ( 23002) ', 'above 90 ( 21092)'],
//                                                                                              data: [1.06, 30.5, 17.2, 8.11],
//                                                                                              color: colors[0]
//                                                                                          }
//                                                                                      }, {
//                                                                                          y: 20.00,
//                                                                                          color: colors[1],
//                                                                                          drilldown: {
//                                                                                              name: 'Nillakottai MBT',
//                                                                                         categories: ['1-30 days ( 12020 )', '30-60 days ( 7102)', '60-90 days ( 23202) ', 'above 90 ( 1092)'],
//                                                                                              data: [1.6, 1.4, 10.2, 6.8],
//                                                                                              color: colors[1]
//                                                                                          }
//                                                                                      }, {
//                                                                                          y: 23.7,
//                                                                                          color: colors[2],
//                                                                                          drilldown: {
//                                                                                              name: 'Theni MBT',
//                                                                                            categories: ['1-30 days ( 12020 )', '30-60 days ( 12102)', '60-90 days ( 22002) ', 'above 90 ( 12092)'],
//                                                                                               data: [2.06, 1.5, 17.2, 3.11],
//                                                                                               color: colors[2]
//                                                                                          }
//
//                                                                                      }],
//                                                                                      browserData = [],
//                                                                                      versionsData = [],
//                                                                                      i,
//                                                                                      j,
//                                                                                      dataLen = data.length,
//                                                                                      drillDataLen,
//                                                                                      brightness;
//
//
//                                                                                  // Build the data arrays
//                                                                                  for (i = 0; i < dataLen; i += 1) {
//
//                                                                                      // add browser data
//                                                                                      browserData.push({
//                                                                                          name: categories[i],
//                                                                                          y: data[i].y,
//                                                                                          color: data[i].color
//                                                                                      });
//
//                                                                                      // add version data
//                                                                                      drillDataLen = data[i].drilldown.data.length;
//                                                                                      for (j = 0; j < drillDataLen; j += 1) {
//                                                                                          brightness = 0.2 - (j / drillDataLen) / 5;
//                                                                                          versionsData.push({
//                                                                                              name: data[i].drilldown.categories[j],
//                                                                                              y: data[i].drilldown.data[j],
//                                                                                              color: Highcharts.Color(data[i].color).brighten(brightness).get()
//                                                                                          });
//                                                                                      }
//                                                                                  }
//
//                                                                                  // Create the chart
//                                                                                  $('#portfolio_at_risk_chart').highcharts({
//                                                                                      chart: {
//                                                                                          type: 'pie'
//                                                                                      },
//                                                                                      plotOptions: {
//                                                                                          pie: {
//                                                                                              shadow: false,
//                                                                                              center: ['50%', '50%']
//                                                                                          }
//                                                                                      },
//                                                                                      tooltip: {
//                                                                                          valueSuffix: '%'
//                                                                                      },
//                                                                                      series: [{
//                                                                                          name: 'Risk',
//                                                                                          data: browserData,
//                                                                                          size: '60%',
//                                                                                          dataLabels: {
//                                                                                              formatter: function () {
//                                                                                                  return this.y > 5 ? this.point.name : null;
//                                                                                              },
//                                                                                              color: '#ffffff',
//                                                                                              distance: -30
//                                                                                          }
//                                                                                      }, {
//                                                                                          name: 'Risk',
//                                                                                          data: versionsData,
//                                                                                          size: '80%',
//                                                                                          innerSize: '60%',
//                                                                                          dataLabels: {
//                                                                                              formatter: function () {
//                                                                                                  // display only if larger than 1
//                                                                                                  return this.y > 1 ? '<b>' + this.point.name + ':</b> ' + this.y + '%' : null;
//                                                                                              }
//                                                                                          }
//                                                                                      }]
//                                                                                  });
//                                                                              });
                                  </script>









<!--                            <script type="text/javascript">
                            	$(function () {
									$('#portfolio_at_risk_chart').highcharts({
										chart: {
											plotBackgroundColor: null,
											plotBorderWidth: null,
											plotShadow: false
										},
										exporting: {
											enabled: false
										},

										credits: {
											enabled: false
										},

										title: {
											text: ''
										},
										tooltip: {
											pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
										},
										plotOptions: {
											pie: {
													allowPointSelect: true,
													cursor: 'pointer',
													dataLabels: {
															enabled: true,
															format: '<b>{point.name}</b>: {point.percentage:.1f} %<br>Amount : {point.y:.1f}',
															style: {
																	color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
															}
													}
											}
										},
										series: [{
											type: 'pie',
										        data: [<?=$portfolio_at_risk;?>]
                                                                                        }]
									});
								});
                            </script>-->
														<? if ($portfolio_at_risk != ''){?>	<div id="portfolio_at_risk_chart"></div><?}else {?><br><br><br><center><span class="text-muted">Record Not Found!</span></center><?}?>
							                        </div>
                    </div>
                </div>
            </div>


            <div class="row padding-top-ten">
                <div class="col-md-4 clear-left-padding">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                      <?php $total_loan_disbursement="69280000";?>
                                    <div class="huge"><i class="fa fa-inr"> </i> <?php echo number_format($total_loan_disbursement,2);?> </div>
                                    <div>Total Loan Disbursed</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <a class="pull-left" href="#">View Details</a>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                      <?php $total_loan_repayment = "30939200";?>
                                    <div class="huge"><i class="fa fa-inr"> </i><?php echo number_format($total_loan_repayment,2);?> </div>
                                    <div>Total Repayment</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">

                                <a class="pull-left" href="#">View Details</a>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4 clear-right-padding">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                              <?php $total_loan_outstanding = $total_loan_disbursement -  $total_loan_repayment;?>
                                             <div class="huge"><i class="fa fa-inr"> </i><?php echo number_format($total_loan_outstanding,2);?></div>
                                             <div>Total Outstanding</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">

                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
		<div class="row">

                      <div class="col-md-6 clear-left-padding">
			<div class="view-info" >
				<div class="view-info-content" style="min-height: 300px;">
					<h3 class="lead">Current Asset</h3>
                                             <script type="text/javascript">

                                                   $(function () {
                                                                $('#financial_status_chart').highcharts({
                                                                    chart: {
                                                                        type: 'bar'
                                                                    },
                                                                    title: {
                                                                        text: ''
                                                                    },
                                                                    xAxis: {
                                                                        categories: ['Madurai MBT', 'Nilakkottai MBT', 'Theni MBT']
                                                                    },
                                                                    yAxis: {
                                                                        min: 0,
                                                                        title: {
                                                                            text: ''
                                                                        }
                                                                    },
                                                                    legend: {
                                                                        reversed: true
                                                                    },
                                                                    plotOptions: {
                                                                        series: {
                                                                            stacking: 'normal'
                                                                        }
                                                                    },
                                                                    series: [{
                                                                        name: 'Cash in Hand',
                                                                        data: [40000,35000, 18000]
                                                                    }, {
                                                                        name: 'Cash at Bank',
                                                                        data: [500000, 2000000, 3000000 ]
                                                                    }]
                                                                });
                                                            });


//                                                   $(function () {
//                                                                            $('#financial_status_chart').highcharts({
//                                                                                chart: {
//                                                                                    type: 'bar'
//                                                                                },
//                                                                                title: {
//                                                                                    text: 'Stacked bar chart'
//                                                                                },
//                                                                                xAxis: {
//                                                                                    categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
//                                                                                },
//                                                                                yAxis: {
//                                                                                    min: 0,
//                                                                                    title: {
//                                                                                        text: 'Total fruit consumption'
//                                                                                    }
//                                                                                },
//                                                                                legend: {
//                                                                                    reversed: true
//                                                                                },
//                                                                                plotOptions: {
//                                                                                    series: {
//                                                                                        stacking: 'normal'
//                                                                                    }
//                                                                                },
//                                                                                series: [{
//                                                                                    name: 'John',
//                                                                                    data: [5, 3, 4, 7, 2]
//                                                                                }, {
//                                                                                    name: 'Jane',
//                                                                                    data: [2, 2, 3, 2, 1]
//                                                                                }, {
//                                                                                    name: 'Joe',
//                                                                                    data: [3, 4, 4, 2, 5]
//                                                                                }]
//                                                                            });
//                                                                        });



//                                             $(function () {
//                                                          $('#financial_status_chart').highcharts({
//                                                              chart: {
//                                                                  type: 'column'
//                                                              },
//                                                              title: {
//                                                                  text: ''
//                                                              },
//                                                              xAxis: {
//                                                                  categories: ['Current Asset']
//
//                                                              },
//                                                              credits: {
//                                                                  enabled: false
//                                                              },
//                                                              series: [<?php
//                                     foreach($current_asset_closing_balance as $key => $value)
//                                                                                 {
//                                                                                       echo "{
//                                                                                               name:'$key',
//                                                                                               data:[$value]
//                                                                                             },";
//                                                                                 }
//                                                                                 ?>//]
//
//                                                          });
//                                                      });
                                                      </script>
                                                  	<div id="financial_status_chart"></div>
							<?php //if($current_asset_closing_balance != "") { ?>
<!--						<div id="financial_status_chart"></div>-->
					<?php // } else { ?>
<!--						<br><br><br><center><span class="text-muted">Record Not Found!</span></center>-->
					<?php // } ?>
									</div>
			</div>

		</div>


                    <div class="col-md-6 clear-right-padding">
                        <div class="view-info">
                            <div class="view-info-content" style="min-height: 300px;">
                                <h3 class="lead">Product Performance</h3>

                                <script type="text/javascript">
                                       $(function () {

                                                                                        Highcharts.setOptions({
                                                                                            lang: {
                                                                                                drillUpText: ''
                                                                                            }
                                                                                        });

                                                                                        // Create the chart
                                                                                        $('#product_performance_chart').highcharts({
                                                                                            chart: {
                                                                                                type: 'bar'
                                                                                            },
                                                                                            title: {
                                                                                                text: ' '
                                                                                            },
                                                                                            xAxis: {
                                                                                                type: 'category'
                                                                                            },

                                                                                            legend: {
                                                                                                enabled: false
                                                                                            },

                                                                                            plotOptions: {
                                                                                                series: {
                                                                                                    borderWidth: 0,
                                                                                                    dataLabels: {
                                                                                                        enabled: true
                                                                                                    }
                                                                                                }
                                                                                            },

                                                                                            series: [{
                                                                                                name: 'Things',
                                                                                                colorByPoint: true,
                                                                                                data: [{
                                                                                                    name: 'Agriculture',
                                                                                                    y: 5,
                                                                                                    drilldown: 'agri'
                                                                                                }, {
                                                                                                    name: 'Education',
                                                                                                    y: 2,
                                                                                                    drilldown: 'education'
                                                                                                }, {
                                                                                                    name: "Small Business",
                                                                                                    y: 4
                                                                                                }]
                                                                                            }],
                                                                                            drilldown: {
                                                                                                drillUpButton: {
                                                                                                    relativeTo: 'spacingBox',
                                                                                                    position: {
                                                                                                        y: 0,
                                                                                                        x: 0
                                                                                                    },
                                                                                                    theme: {
                                                                                                        fill: 'white',
                                                                                                        'stroke-width': 1,
                                                                                                        stroke: 'silver',
                                                                                                        r: 0,
                                                                                                        states: {
                                                                                                            hover: {
                                                                                                                fill: '#bada55'
                                                                                                            },
                                                                                                            select: {
                                                                                                                stroke: '#039',
                                                                                                                fill: '#bada55'
                                                                                                            }
                                                                                                        }
                                                                                                    }

                                                                                                },
                                                                                                series: [{
                                                                                                    id: 'agri',
                                                                                                    data: [
                                                                                                        ['Madurai MBT', 4],
                                                                                                        ['Theni MBT', 2],
                                                                                                        ['Nillakottai MBT', 6],
                                                                                                  
                                                                                                    ]
                                                                                                }, {
                                                                                                    id: 'education',
                                                                                                    data: [
                                                                                                        ['Madurai MBT', 4],
                                                                                                        ['Theni MBT', 2],
                                                                                                        ['Nillakottai MBT', 3]
                                                                                                    ]
                                                                                                }]
                                                                                            }
                                                                                        })
                                                                      });
//								

								</script>
                                <div id="product_performance_chart"></div>
                                <?php //if($product_wise_loan_disbursement != "") { ?>
<!--								<div id="product_performance_chart"></div>-->
							<?php //} else { ?>
<!--								<br><br><br><center><span class="text-muted">Record Not Found!</span></center>-->
							<?php //} ?>
																	

                            </div>
                        </div>
                    </div>
                </div>
                  		
        </div>
    </div>
</div>
<?include("footer.php");
?>