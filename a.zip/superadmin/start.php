<?
//error_reporting('E_ALL');
include ("header.php");

include('db_connect.php');
include("../config/functions.php");
$loginid = $_POST['loginid'];
$idpass = md5($_POST['idpass']);
//$fromyear=$_POST['fromyear'];
//$toyear=$_POST['toyear'];
$fromyear='2016';
$toyear='2017';
echo "<BR>--TESTING_MEENA_IID---><BR>";
$current=date('H');
$ip=$_SERVER['REMOTE_ADDR'];


if(isset($_POST['submit'])) { 
//   echo "STEddP1-->";

//         exit;
        $today=date('d-m-Y');
	$temp1=explode('-',$today);
	$today1=mktime(0, 0, 0, $temp1[1],$temp1[0],$temp1[2]);
//     echo "SELECT * FROM user_registration WHERE loginid='$loginid' AND password='$idpass' AND status=2 AND approve_status=1";
//     exit;
       
  $suspend_query=mysql_query("SELECT * FROM user_registration WHERE loginid='$loginid' AND password='$idpass' AND status=2 AND approve_status=1",$global_database);
  if(mysql_num_rows($suspend_query) == 0) {

            $count_fail=mysql_query("SELECT count(*) as count FROM failed_login WHERE ip='".$ip."' AND `date`=".$today1." AND status=1",$global_database);
            $count_fail1=mysql_fetch_object($count_fail);
           if($count_fail1->count<=2){

              if($loginid == '' || $idpass == '') {
           echo    $err = "Please enter User Name & Password";
               $fail=mysql_query("INSERT into failed_login(ip,login_id,date,status) values('".$ip."','".$loginid."',".$today1.",1)",$mbt_database);
               //fn_login( $err);
              }
        elseif($fromyear == '' || $toyear == '') {
        echo $err = "Please Select the Financial Year";
	$fail=mysql_query("INSERT into failed_login(ip,login_id,date,status) values('".$ip."','".$loginid."',".$today1.",1)",$mbt_database);
	//fn_login( $err);
        }
        else {
     echo "else1";
            echo "select * from user_registration where loginid='$loginid' and password='$idpass' AND status=1 AND approve_status=1";
         $sql_query=mysql_query("select * from user_registration where loginid='$loginid' and password='$idpass' AND status=1 AND approve_status=1",$global_database);
         mysql_num_rows($sql_query);
	if(mysql_num_rows($sql_query)>0)
	{
	$result_sql=mysql_fetch_object($sql_query);
         //$sql_query1=mysql_query("select * from user_registration where loginid='$loginid' and password='$idpass' AND status=1  ");

	 //$sql_query1=mysql_query("select * from user_registration where loginid='$loginid' and password='$idpass' AND status=1 AND approve_status=1 AND `from` <= ". $current." AND `to` >= ".$current);
         //echo "select ciid from user_registration where loginid='$loginid' and password='$idpass' AND status=1 AND approve_status=1";
         $sql_query1=mysql_query("select ciid from user_registration where loginid='$loginid' and password='$idpass' AND status=1 AND approve_status=1",$global_database);

         $mbt_id = mysql_fetch_object($sql_query1)->ciid;
         $mbt_br_id = mysql_fetch_object($sql_query1)->iid;
         if($mbt_br_id==0 && $mbt_id==0)  {
               $_SESSION['database_name']="sjdt1_mbt_global";
         }
         else{
                     $database_name = mysql_fetch_object(mysql_query("select database_name from mfi_registration WHERE id= $mbt_id",$global_database))->database_name;
                     $_SESSION['database_name']=$database_name;
         }
         $counter=mysql_num_rows($sql_query1);
	if($counter)
         {


         $hour = date('H');
	if($hour >= $result_sql->from && $hour < $result_sql->to)
         {
    	   $_SESSION['userid']=$result_sql->id;
    	   $_SESSION['firstname']=$result_sql->firstname;
    	   $_SESSION['middlename']=$result_sql->middlename;
    	   $_SESSION['lastname']=$result_sql->lastname;
	   $_SESSION['ulevel']=$result_sql->level;
	   $_SESSION['urole']=$result_sql->userrole;
            $_SESSION['fromyear']=$fromyear;
            $_SESSION['toyear']=$toyear;
//           $_SESSION['']
           //$_SESSION['account_level']=$result_sql->level;
	//echo "--user_acc_level-->".$_SESSION['account_level']."<BR>";exit;
  	   if($result_sql->level==1){		// MFI USER LEVEL
	     $_SESSION['iid']=$result_sql->iid;
	   }else
	   if($result_sql->level==2){		// BRANCH USER LEVEL
	     $_SESSION['iid']=$result_sql->ciid;
	     $_SESSION['bid']=$result_sql->iid;
	   }else
	   if($result_sql->level==3){		// ROSCA USER LEVEL
	     $_SESSION['bid']=$result_sql->ciid;
	     $_SESSION['rid']=$result_sql->iid;

	     // Getting the MFI
	  $list_out=mysql_fetch_object(mysql_query("SELECT ciid FROM user_registration WHERE iid=".$result_sql->ciid,$global_database));
	  $_SESSION['iid']=$list_out->ciid;

	    }else
	   if($result_sql->level==4){		// FO USER LEVEL
	     $_SESSION['bid']=$result_sql->ciid;
	     $_SESSION['fid']=$result_sql->iid;

	     // Getting the MFI
	$list_out=mysql_fetch_object(mysql_query("SELECT ciid FROM user_registration WHERE iid=".$result_sql->ciid,$global_database));
	  $_SESSION['iid']=$list_out->ciid;
	    }
		logs(1);
	//CODING FOR PAGE URL CHECKER AND TO AVOID UNAUTHORIZED PAGE VISIT
	$privilege=mysql_result(mysql_query("SELECT privilege FROM user_roles WHERE rid=$result_sql->userrole",$mbt_database),0);
		$extract_privilege = explode(",",$privilege);
		$final_value = "";
		for($i=0;$i<sizeof($extract_privilege);$i++) {
			$res_value = mysql_result(mysql_query("SELECT links FROM user_privileges WHERE pid='".$extract_privilege[$i]."'",$mbt_database),0);
			$final_value = $final_value.",".$res_value;
		}

	$rep_privilege=mysql_result(mysql_query("SELECT reports_privilege FROM user_roles WHERE rid=$result_sql->userrole",$mbt_database),0);
		$extract_rep_privilege = explode(",",$rep_privilege);
		$rep_value = "";
		for($i=0;$i<sizeof($extract_rep_privilege);$i++) {
			$res_rep_value = mysql_result(mysql_query("SELECT links FROM user_privileges_reports WHERE pid='".$extract_rep_privilege[$i]."'",$mbt_database),0);
			$rep_value = $rep_value.",".$res_rep_value;
		}
	$new = $final_value.",".$rep_value;
	$_SESSION['urlchecker'] = explode(",",$new);

		if($_POST['pageurl'] != "") {

                        $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
		      header("Location: $base_url.$_POST[pageurl]");
		}
		else {

                        if($result_sql->level==0)
                        {
                                    $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
				 header("Location:dashboard.php");
                        }
                        else if($result_sql->level==1) {		// USER LEVEL 1
		                    $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
				  header("Location:agree_status.php");
			}
			else if($result_sql->level==2) {        // USER LEVEL 2

                                             $check_holiday=mysql_query("SELECT count(*) as count FROM branch_holiday WHERE bid=".$result_sql->iid." AND `date`=".$today1,$mbt_database);
                                             $count=mysql_fetch_object($check_holiday);
                                             if($count->count){
                                                          $err="Today is declared as holiday, you can't access";
                                                          $fail=mysql_query("INSERT into failed_login(ip,login_id,date,status) values('".$ip."','".$loginid."',".$today1.",1)",$global_database);
                                             }
                                             else   {
                                                          $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
                                                          //header("Location:branch/index.php");
                                                          header("Location:agree_status.php");
                                             }
			}
			else if($result_sql->level==3) {        // USER LEVEL 3
			         $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
				header("Location:rosca/index.php");
			}
			else  {        // USER LEVEL  ELSE
			         $clear_fail=mysql_query("UPDATE failed_login set status=0 WHERE ip='".$ip."' AND date=".$today1,$global_database);
				header("Location:fieldofficer/index.php");
			}
		}
	}


    	$err="Invalid User Session. Allowed Session: ".$result_sql->from." hrs - ".$result_sql->to." hrs only";
	$fail=mysql_query("INSERT into failed_login(ip,login_id,date,status) values('".$ip."','".$loginid."',".$today1.",1)",$mbt_database);



    }

    }

    else
    	{
    	$err="Invalid Usessr Name / Password";
	$fail=mysql_query("INSERT into failed_login(ip,login_id,date,status) values('".$ip."','".$loginid."',".$today1.",1)",$global_database);
    	}
   }
}
else {
 echo $err="Maximum number of failed login attempted, Please contact the Admin.";
}
}
else {
      echo "ram";exit;
  $err="You are in suspended state.Please contact the Admin.";
}

}
$curyear=date('Y');
$curyear1=date('Y');
$curmon=date("m");
if($curmon == 1 || $curmon == 2 || $curmon == 3)
{
  $preyear=  $curyear-1;
  $curyear = $curyear ;
}
else
{
   $preyear = $curyear;
   $curyear = $curyear+1;
}

/*require_once($microfin_functions_url ."/sms/global_sms_history.php");
require_once($microfin_functions_url ."/email/global_email_history.php");

$current_time = time();

if (isset($_POST['email_id'])) {

    $string = '123456789';
    $string_shuffled = str_shuffle($string);
    $otp = substr($string_shuffled, 1, 5);
    $person_name = trim($_POST['full_name']);
    $organization_name = trim($_POST['organization_name']);
    $password = md5($_POST['password']);
    $mobile_no = trim($_POST['mobile_number']);
    $email_id = trim($_POST['email_id']);
    $selected_type = trim($_POST['verify_option']);


    $query = "INSERT INTO  clients (org_person, org_name, org_password, org_mobile, org_email, otp, otp_generated_time, file_path_name, time, registration_status) ";
    $query .= "VALUES ('$person_name', '$organization_name','$password','$mobile_no','$email_id','$otp','$current_time','','$current_time','0')";

    if(!mysql_query($query,$link_microfinance_global)){
        echo "Error => ".mysql_error();
        exit;
    }

    $_SESSION['otp'] = $otp;
    $_SESSION['organization_name'] = $organization_name;
    $_SESSION['mobile_no'] = $mobile_no;
    $_SESSION['email_id'] = $email_id;
    $_SESSION['user_level_id'] = "1";
    $_SESSION['client_name'] = $organization_name;
    $_SESSION['user_for'] = "1";


    if ($organization_name != '') {
		$client_id = mysql_fetch_object(mysql_query("SELECT MAX(client_id) AS client_id FROM clients WHERE org_mobile='$mobile_no' AND org_email='$email_id'",$link_microfinance_global))->client_id;
 }

//echo "SELECT plan_id FROM clients WHERE client_id='$client_id'";exit;
    $_SESSION['client_id'] = $client_id;
    $_SESSION['plan_id']   = $plan_id;

      mysql_query("INSERT INTO global_users (client_id, user_level, user_for, email_id, mobile_number, password, first_name, created_time, status) VALUES ('$client_id', '1', '1', '$email_id', '$mobile_no', '$password', '$person_name', '$current_time', '1')",$link_microfinance_global);
    //  echo "INSERT INTO phpbb_users (user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_email_hash, user_lang) VALUES ('$sys_ip', $user_reg , $email_id, '$email_id', ' $pwd', ' $user_pwdchange', ' $email_id', '$encypt_email', 'en')";
    //  exit;
   //  mysql_query("INSERT INTO phpbb_users (user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_email_hash, user_lang) VALUES ('$sys_ip', $user_reg , $email_id, '$email_id', ' $pwd', ' $user_pwdchange', ' $email_id', '$encypt_email', 'en')",$link_microfinance_forum);

    $global_user_id = mysql_fetch_object(mysql_query("SELECT MAX(global_user_id) AS global_user_id FROM global_users WHERE client_id = '$client_id' AND mobile_number='$mobile_no' AND email_id='$email_id'",$link_microfinance_global))->global_user_id;

    $_SESSION['global_user_id'] = $global_user_id;

	mysql_query("INSERT INTO user_role_settings (global_user_id, user_role_id, created_time, status) VALUES ('$global_user_id', '1', '$current_time', '1')",$link_microfinance_global);

    if ($selected_type == 'email') {
		$verification_id = $global_user_id."_".$current_time;
		$verification_md5_id = md5($verification_id);
                $mail_from[]="Customer Support Team <support@microfinance.in>";
                $mail_replay_to[]="Customer Support Team <support@microfinance.in>";
                $mail_cc[]="";
                $mail_bcc[]="";
                $mail_to[]=$email_id;
                $subject="Confirmation Mail For Login Microfinace.in";
		$message = '<html>
			<head>
				<meta http-equiv="content-type" content="text/html; charset=UTF-8">
			</head>
			<body>
			<div style="font-family:Helvetica;width:600px;margin:0 auto;background:red;display:block; " class="outer_box">
				<div class="outer_top" style="float:left;color:#898989;width:100%;">
				<div style="float:left;width:60%;">
					<p style="text-align:left;font-size:11px;">To Ensure delivery to inbox, add <a style="color:#146FD4" href="#" mailto="Customer Support Team <support@microfinance.in>"> "Customer Support Team " &lt; support@microfinance.in &gt;</a> to you address book</p>
				</div>
				<div style="float:left;width:40%;">
					&nbsp;
				</div>
				</div>

				<div class="content" style="float:left;width:580px;border:10px solid #EEEEEE;">
				  <div class="header" style="float:left;padding:22px; ">
						<div style="color: #EA1D25;font-size: 26px; font-weight: bold;"><a href="http://www.microfinance.in/"><img alt="Microfinance.in" src="' . $microfin_final_url . '/themes/images/email/microfinance_logo.png" width="80%"></a></div>
					</div>

					<div class="banner">
						<a href="http://www.microfinance.in/"><img alt="Microfinance Banner" src="' . $microfin_final_url . '/themes/images/email/banner.png" width="100%"></a>
					</div>

					<div style="width:540px;padding:20px;font-size:14px;" class="message">
						<p>Dear '.$person_name.',</p>
						<p>Congratulations! You have been provisionally registred to microfinance.in</p>
						<p>Please Click below to verify your email and start customizing microfinance.in platform for your organization needs.</p>
					</div>

					<div style="padding-bottom:25px;" class="button">
						<a href="' . $microfin_final_url . '/mail_link_page.php?verification_id='.$verification_md5_id.'" id="start_btn" name="start_btn" style="background:#EA1D25;border-radius:6px;color: #FFFFFF; width:220px; height:42px;margin:0 auto;display:block;border:1px solid #EA1D25;text-decoration:none;"><span style="margin:0 60px;display:block;padding:10px;color:white;font-size:17px;">Start Now</span></a>
					</div>

					<div class="logo" style="float:left;background:#EEEEEE;width:580px;padding:10px 0px;">
						<div class="left_logo" style="float:left;width:70%;">
							<div class="logo_img" style="float:left; width:40px;">
								<a href="http://www.microfinance.in/"><img alt="Mirocfinance Icon" src="' . $microfin_final_url . '/themes/images/email/microfinance_32.png" style="width:32px"></a>
							</div>
							<div class="logo_text" style="float:left;">
								<p style="text-align:left;font-size:11px;color:#777674;margin:0px;padding:0px;">Administration Team</p>
								<a href="" style="text-align:left;font-size:11px;color:#777674;text-decoration:none;">microfinance.in</a>
							</div>
						</div>
						<div class="right_logo" style="float:left;width:30%;">
							<a href="http://www.facebook.com/ekgaon"><img alt="Facebook Icon" src="' . $microfin_final_url . '/themes/images/email/facebook_32.png" style="float:right;width:32px"></a>
						</div>
					</div>
				</div>

				<div class="outer_bottom" style="float:left;color:#898989;width:100%;">
					<div style="float:left;width:60%;">
						<p style="text-align:left;font-size:11px;">This Email was intended for ' . $email_id . '</p>
					</div>
					<div style="float:left;width:40%;">

					</div>
				</div>
			</div>
			</body>
		</html>';
        $email_type_id="1";
        global_email_history($global_user_id, $client_id,$mail_from, $mail_replay_to, $mail_cc, $mail_bcc,$mail_to,$subject, $message, $ip_address, $sms_email_sent_url, $email_type_id, $link_microfinance_global);
        header("location:verification_mail_sent.php");
    } elseif ($selected_type == "mobile") {
        $mobile_number = "91" . $mobile_no;
        $message .="Dear " . $person_name . ", ";
        $message .="Thanks for registering to microfinance.in. Your OTP is " . $otp . " for account verification";
        $sms_type_id="1";
        global_sms_history($global_user_id, $client_id, $mobile_no, $message, $ip_address, $sms_email_sent_url, $sms_type_id, $link_microfinance_global);
        header("location:send_otp.php");
    }
}*/

?>
<script src="<?= $microfin_final_url; ?>/themes/validator/login_form.js"></script>
<script src="<?= $microfin_final_url; ?>/themes/validator/register_form.js"></script>
<div class="page_start">
	<div class="page row" style="padding-left: 15px; padding-right: 15px;">
	    <?php
	    if ($_COOKIE['alert']) {
	    $alert_value = $_COOKIE['alert'];
	    echo '<div class="alert alert-success alert_status">' . $alert_value . '! &nbsp; &nbsp;
		    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">
		    <span class="glyphicon glyphicon-remove fright cpoint"></span>
		    </button>
	    </div>';
	    unset($_COOKIE['alert']);
	    }

	    ?>
	    <div class="col-md-6 clear-padding">
		    <ul class="nav nav-tabs" role="tablist" id="logintab">
			    <li class="active"><a href="#login" role="tab" data-toggle="tab">Login</a></li>
			    <li><a href="#register" role="tab" data-toggle="tab">Register</a></li>
		    </ul>
		    <!-- Tab panes -->
		    <div class="tab-content">
			    <div class="tab-pane active" id="login">
				    <div class="col-md-8 login_form" style="margin-top: 25px; padding-left: 0px;">

					    <form class="form-horizontal" id="login_form_sjdt" method="post" action="#">
						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon glyphicon-envelope"></span>
									    <!---input type="text" placeholder="Email or Mobile" name="username" id="username" class="form-control" ---->
								<input type='text' placeholder="Enter User Name"  value='' id='loginid' name='loginid' class="form-control" /> <input type="hidden" name="pageurl" value="<?=str_replace('url=','',$_SERVER['QUERY_STRING']);?>">

                                                                    </div>
							    </div>
						    </div>

						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon-lock"></span>
									    <!---input type="password" placeholder="Password" name="password" id="password" class="form-control"--->
								             <input type='password' placeholder="Enter Password" value='' id='idpass' name='idpass' class="form-control checkrecords"/>

                                                                    </div>


							    </div>
						    </div>
                                                    <!---div class="form-group">
                                                        <div class="col-md-4 clear-right-padding">
                                                            <label class="control-label "><strong>Financial Year</strong></label>
							</div>
                                                        <div class="col-md-4">
                                                            <select  id="fromyear" name="fromyear" class="form-control" >
                                                                <option value="">From</option>
                                                                    <?php for($p=2008;$p<=$curyear1;$p++) { ?>
                                                                    <option value="<?=$p;?>" <?if($preyear==$p){?>selected="selected"<?}?>><?=$p;?></option>
                                                                    <? } ?>
                                                            </select>
                                                            <span class="text-info">April</span>
							</div>
                                                         <div class="col-md-4">
                                                              <select  id="toyear" name="toyear" class="form-control" >
                                                                  <option value="">To</option>
                                                                    <?php for($i=2009;$i<=$curyear1+1;$i++) { ?>
                                                                    <option value="<?=$i;?>" <?if($curyear==$i){?>selected="selected"<?}?>><?=$i;?></option>
                                                                    <? }
                                                                    //	echo $curyear;
                                                                    ?>
                                                            </select>
                                                             <span class="text-info">March</span>
							</div>
                                                     </div--->
                                                        <? if($err!=""){?>
                                             <span style=" color: #a94442;margin-bottom: 10px; margin-top: 5px;"><strong><? echo $err;?></strong></span>
                                         <?}?>

						    <div class="form-group" style="padding:5px;">
							    <div class="col-md-12">
								    <!---button type="submit" class="btn btn-lg btn-default" name="login_btn" style="margin-left:-5px; margin-bottom: 5px;" id="login_btn" >Login</button-->
                                                                 <div class="col-md-4">
                                                                     <input type='submit' name='submit' id='log'  value='LogIn' class="btn btn-lg btn-default" />
                                                                 </div>
                                                                    <div class="col-md-4">
                                                                         <input type='reset' name='Clear' value='Clear' class="btn btn-lg btn-info" />
                                                                    </div>
                                                                    <div class="col-md-4"></div>
                                                            </div>
							    <div class="col-md-6">
							    <img id="spinner" style="display: none; width: 40px;" src="<?=$microfin_final_url?>/themes/images/spinner.gif">
							    </div>
							    <div class="clear"></div>
							    <label id="error" style="margin-left: 10px;" class="text-danger"></label>
						    </div>

					    </form>
				    </div>
			    </div>

			    <div class="tab-pane" id="register">
				    <div class="col-md-8 login_form"  id="email_mobile" style="margin-top: 25px; padding-left: 0px;">
					    <form class="form-horizontal" id="register_form" name="register_form" method="post" action="start.php?action=register" >
						    <input type="hidden" name="form_register" value="register"/>
						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon-user"></span>

									    <input type="text" placeholder="Full Name" name="full_name" id="full_name" class="form-control">
								    </div>
								    <div id="org_name"></div>
							    </div>
						    </div>

						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon-home"></span>

									    <input type="text" placeholder="Organization Name" name="organization_name" id="organization_name" class="form-control">
								    </div>
								    <div id="org_name"></div>
							    </div>
						    </div>

						    <div class="form-group" style="margin-bottom: 0px;">
							    <div class="col-md-12">
								    <div class="control-group">
									    <div class="input-group">
										    <span class="input-group-addon glyphicon glyphicon-lock"></span>
										    <input type="password" id ="regpassid" placeholder="Password" name="password" class="form-control" minlength="6" data-bv-validator="callback">
									    </div>
								    </div>
							    </div>
						    </div>

						    <div class="form-group has-feedback has-error">
							<div class="col-md-12">
							    <!-- The message container -->
							    <div id="messageContainer"></div>
							</div>
						    </div>

						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="control-group">
									    <div class="input-group">
										    <span class="input-group-addon glyphicon glyphicon-lock"></span>
										    <input type="password" id ="regconfpassid" placeholder="Confirm Password" name="confirm_password" class="form-control" minlength="6">
									    </div>
								    </div>
							    </div>
						    </div>


						    <div class="form-group" id="email_id_error">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon-envelope"></span>
									    <input type="text" placeholder="Email ID" name="email_id" id="email_id" class="form-control" >
								    </div>
								    <div id="organization_mail"></div>
							    </div>
						    </div>

						    <div class="form-group" id="mobile_number_error">
							    <div class="col-md-12">
								    <div class="input-group">
									    <span class="input-group-addon glyphicon glyphicon-phone"></span>
									    <input type="text" placeholder="Mobile Number" name="mobile_number" id="mobile_number" class="form-control">
								    </div>
								    <div id="organization_mobile"></div>
							    </div>
						    </div>

						    <div class="form-group">
							    <label class="col-xs-6 col-md-5 control-label form-label-no-padding clear-right-padding">Verification By</label>
							    <div class="col-xs-6 col-md-7 clear-padding">
								    <div class="col-xs-6 col-md-11">
									    <label class="radio-inline">
										    <input type="radio" id ="verify1" name="verify_option" value="email">Email
									    </label>
									    <label class="radio-inline">
										    <input type="radio" id ="verify2" name="verify_option" value="mobile">Mobile
									    </label>
								    </div>
							    </div>
						    </div>

						    <div class="form-group">
							    <div class="col-md-12">
								    <div class="input-group">
									    <label>
										    <input type="checkbox" id="agreee" name="agreee"> &nbsp; I agree to the <a href="#">terms of services</a> of the platform
									    </label>
								    </div>
							    </div>
						    </div>

						    <div class="form-group">
							    <div class="col-md-6">
								    <input type="submits" id="register_btn" name="register_btn" value="Register" class="btn btn-lg btn-default">
							    </div>
						    </div>
					    </form>
				    </div>



			    </div>
		    </div>

	    </div>

	    <div class="col-md-6">
		<ul class="nav nav-tabs" role="tablist" id="logintab">
			<li class="active"><a href="#silver" role="tab" data-toggle="tab">Silver</a></li>
			<li><a href="#gold" role="tab" data-toggle="tab">Gold</a></li>
		</ul>
		<!-- Tab panes -->
		<div class="tab-content">
			<div class="tab-pane active" id="silver">
				<br><br><br>
				<img class="plan_img" src="<?= $microfin_final_url; ?>/themes1/images/s1.png">
				<div class="plan_box">
					<br>
				    <p style="margin-top: 10px; color: #757575; line-height: 1.6em;">Sample content several decades, a revolution in information and communication technologies (ICTs) has completely changed the way people learn, govern, interact, make money and live their lives.</p>
					<!--a href="plan_details.php?plan_id=1">Read more...</a--->
                                        <?php $plan_id=md5(1); /*<?=$microfin_final_url;?>/plan_wise_pricing_list.php?plan_id=<?=$plan_id;?>*/ ?>
                                        <a href="#">Read more...</a>

					<div class="clear"></div>
				</div>
			</div>

			<div class="tab-pane" id="gold">
				<br><br><br>
				<img class="plan_img" src="<?= $microfin_final_url; ?>/themes1/images/g1.png">
				<div class="plan_box">
					<br>
				    <p style="margin-top: 10px; color: #757575; line-height: 1.6em;">Sample content several decades, a revolution in information and communication technologies (ICTs) has completely changed the way people learn, govern, interact, make money and live their lives.</p>
					<?php $plan_id=md5(2);?>
                                        <a href="#">Read more...</a>

					<div class="clear"></div>
				</div>
			</div>
		</div>
		<br>
		<div class="alert alert-info">
		    If you already received your login information through E-mail or SMS please <a href="#"><b>Click Here</b>.</a><!----->
		</div>
	    </div>

	</div>
	<!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<h4 class="modal-title" id="myModalLabel">Login Information</h4>
				</div>
				<div class="modal-body">
					Please Enter the Correct UserName and Password
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?
include ("footer.php");
?>
