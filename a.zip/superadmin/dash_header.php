<?php
include("db_connect.php");
//include("../session.php"); //include("settings.php");  //include ('../includes/dbconnect.php'); //include("config/functions.php"); //include("config/query.php");//include("config/level_settings.php");
//echo "---->".$iid."-----".$bid."<BR>";
//echo "<BR>step1_userid---->".$_SESSION['userid']."<BR>---basic_url-->".$microfin_final_url."<BR>---account_level--->".$_SESSION['account_level']."<BR>";//echo "client_id-->".$client_id."user level:".$user_level_id."--use_global_id-->".$user_id."--userr_for-->".$user_for."<BR>"; //echo "SESSION_USERID-->".$_SESSION['userid']."--ACCOUNT_LEVEL_ID--->".$_SESSION['account_level']."<BR>";

//
//function level_label_migration($user_level,$con)
//{
//    $office="Office";
//    if($user_level == 1) {  $office="Head Office"; }
//    else if($user_level == 2) { $office="Branch Office";   }
//    else if($user_level == 3) { $office="Rosca";  }
//     else{  $office="Field Officer";  } //echo $office."<BR>";
//return $office;
//}
//
//function level_name_migration($iid,$ilevel,$con) {
//   // echo "--ilevel--->".$ilevel."<BR>";
//
//$query=mysql_query("set sql_big_selects=1");
//if($ilevel=="1") {
//	$sel=mysql_query("select mfiname from mfi_registration where id='".$iid."'",$con);
//	$res=mysql_fetch_object($sel);
//	$count=mysql_num_rows($sel);
//	$iname=($count!='0')?  $res->mfiname:"";
//}
//else if($ilevel=="2") {
//    echo "---BRANCH_OFFICE---"."<BR>";
//	$sel=mysql_query("select branchofficename from branch_registration where bid='".$iid."'",$con);
//	$res=mysql_fetch_object($sel);
//	$count=mysql_num_rows($sel);
//	$iname=($count!='0')?  $res->branchofficename:"";
//}
//else if($ilevel=="3") {
//	$sel=mysql_query("select rosca_name from rosca where rid='".$iid."'",$con);
//	$res=mysql_fetch_object($sel);
//	$count=mysql_num_rows($sel);
//	$iname=($count!='0')?  $res->rosca_name:"";
//}
//else {
//	$sel=mysql_query("select branchofficename from branch_registration where bid='".$iid."'",$con);
//	$res=mysql_fetch_object($sel);
//	$count=mysql_num_rows($sel);
//	$iname=($count!='0')?  $res->branchofficename:"";
//}
//return $iname;
//}
//function count_migration($level,$level_id,$iid,$bid,$type,$con)
//{
//$created_time=time();
////echo "count_migration($level,$level_id,$iid,$bid,$type,$con)"."<BR>";
//$count='0';
//if($type == 'active_group_count')
//{
//   if($iid != '' && $bid != '')
//   $query="SELECT *  FROM rosca WHERE status = 1 AND  registerdate <= $created_time AND iid='$bid' ";
//   else
//   $query="SELECT *  FROM rosca WHERE status = 1 AND  registerdate <= $created_time ";
//   // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//else if($type == 'total_group_count')
//{
//   if($iid != '' && $bid != '')
//   $query="SELECT *  FROM rosca  WHERE  registerdate <= $created_time AND iid='$bid' ";
//   else
//       $query="SELECT *  FROM rosca  WHERE  registerdate <= $created_time ";
//  // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//else if($type == 'active_field_officer_count')
//{
//
//   if($iid != '' && $bid != '')
//       $query="SELECT * FROM fieldofficer_address_info WHERE approve_status=1 AND iid ='$bid'";
//   else
//       $query="SELECT * FROM fieldofficer_address_info WHERE approve_status=1 AND iid !=''";
//  // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//else if($type == 'total_field_officer_count')
//{
//
//   if($iid != '' && $bid != '')
//       $query="SELECT * FROM fieldofficer_address_info Where iid ='$bid' ";
//   else
//       $query="SELECT * FROM fieldofficer_address_info WHERE iid !=''";
//  // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//else if($type == 'active_customer_count')
//{
//   if($iid != '' && $bid != '')
//          $query="SELECT *  FROM client_info1  WHERE status =1 AND iid ='$bid' "; //AND registered <= $created_time //SELECT * FROM client_info1 WHERE iid=$bid AND status=1
//   else
//          $query="SELECT *  FROM client_info1  WHERE status =1 AND registered <= $created_time AND iid !=''";
//
//  // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//else if($type == 'total_customer_count')
//{
//   if($iid != '' && $bid != '')
//          $query="SELECT *  FROM client_info1  WHERE  registered <= $created_time AND iid ='$bid' ";
//   else
//          $query="SELECT *  FROM client_info1  WHERE  registered <= $created_time AND iid !='' ";
//
//  // echo $query."<BR>";
//   $count=mysql_num_rows(mysql_query($query,$con));
//}
//
//return $count;
//}
//function user_role_migration($user_role_id,$con)
//{
//    $user_role='Administrator';
//if($user_role_id != '')
//{
//$userrole_info=mysql_query("SELECT rolename,reports_privilege FROM user_roles WHERE rid=".$user_role_id."",$con);
//$userrole_info_result=mysql_fetch_object($userrole_info);
//$user_role=$userrole_info_result->rolename;
//}
//return $user_role;
//}
//
//function user_name_migration($user_id,$con)
//{
//$user_name='Users';
//if($user_id != '')
//{
//$name_info=mysql_query("SELECT firstname FROM user_registration WHERE id=".$user_id."",$con);
//$name_info_result=mysql_fetch_object($name_info);
//$user_name=$name_info_result->firstname;
//return $user_name;
//}
//}
//
//function total_loan_details($type,$bids,$sdate,$tdate,$con)
//{
//// echo "total_loan_disburse($type,$bids,$sdate,$tdate)"."<BR>";
// $loanamount=0;
//
// if($type == 'total_loan_disbursement')
// {
//    $branch_filter='bid in ('.$bids.')';
//   // echo "---branch_filter--->".$branch_filter."<BR>";
//    $query="SELECT loanamount FROM loandisburse WHERE $branch_filter AND dateofloan >=".$sdate." AND dateofloan <=".$tdate."" ;
//    echo "---QUERY-->".$query."<BR>";
//    $sql=mysql_query($query,$con);
//    $count=mysql_num_rows($sql);
//   //echo "--COUNT-->".$count."<BR>";
//    if($count > 0)
//    {
//              while($res=mysql_fetch_object($sql)) {
//                $loanamount=$loanamount+$res->loanamount;   }
//    }
// }
// else  if($type == 'total_loan_repayment')
// {
//     $branch_filter='iid in ('.$bids.')';
//   // echo "---branch_filter--->".$branch_filter."<BR>";
//    $query="SELECT  sum(paidamount) as paidamount FROM loan_repayment_schedule WHERE $branch_filter AND duedate >=".$sdate." AND duedate <=".$tdate."" ;
//    //echo "---QUERY-->".$query."<BR>";
//    $sql=mysql_query($query,$con);
//    $count=mysql_num_rows($sql);
//   //echo "--COUNT-->".$count."<BR>";
//    if($count > 0)
//    {
//              while($res=mysql_fetch_object($sql)) {
//                $loanamount=$loanamount+$res->paidamount;   }
//    }
// }
// else  if($type == 'total_loan_outstanding')
// {
//     $branch_filter='iid in ('.$bids.')';
//   // echo "---branch_filter--->".$branch_filter."<BR>";
//    $query="SELECT  sum(paidamount) as paidamount,sum(dueamount) as dueamount FROM loan_repayment_schedule WHERE $branch_filter AND duedate >=".$sdate." AND duedate <=".$tdate."" ;
//   // echo "---QUERY-->".$query."<BR>";
//    $sql=mysql_query($query,$con);
//    $count=mysql_num_rows($sql);
//   //echo "--COUNT-->".$count."<BR>";
//    if($count > 0)
//    {
//              while($res=mysql_fetch_object($sql)) {
//                $paidamount=$paidamount+$res->paidamount;
//                $dueamount=$dueamount+$res->dueamount;
//                $loanamount=$loanamount+($dueamount - $paidamount);
//                }
//    }
// }
// return $loanamount;
//
//}
//
////REG NO
//if($iid != '')
//{
//$sql=mysql_query("SELECT * FROM mfi_registration WHERE iid=$iid",$con);
//$res=mysql_fetch_object($sql);
//$regno=$res->regno;
//}
//
//
//
////USER LEVEL LABLE NAME:
//$office=level_label_migration($user_level,$con);
//if($iid != '' & $bid !='')
//$level_name=level_name_migration($bid,$user_id,$con);
//else
// $level_name=level_name_migration($iid,$user_id,$con);
//
////USER NAME
//$user_name=user_name_migration($user_id,$con);
//
//
////USER ROLE
//$user_role=user_role_migration($user_role_id,$con);
//
//
//function cash($type,$branch_id,$from_date,$to_date,$display,$con)
//	{
//		$query=mysql_query("set sql_big_selects=1");
//		if($branch_id=="")
//			$branch = "";
//		else
//			$branch = "AND iid='".$branch_id."'";
//
//		if($type=="hand")
//			$pid="44";
//		else
//			$pid="45";
//		$total_balance = 0;
//		$select_cash_ledgers = mysql_query("SELECT lname,type,lid,iid FROM new_ledger WHERE pid='$pid' AND status=1 $branch",$con);
//		while($row_select_cash_ledgers = mysql_fetch_array($select_cash_ledgers))
//			{
//				$ledger_id = $row_select_cash_ledgers['lid'];
//				$branch_id = $row_select_cash_ledgers['iid'];
//				$balance = balance('closing',$ledger_id,$branch_id,$from_date,$to_date,'real');
//				$total_balance = $total_balance + $balance;
//			}
//
//		$real_balance = $total_balance;
//		$number_balance = abs($total_balance);
//		$currency_balance = number_format(abs($total_balance), 2, '.', ',');
//		if($display=="real")
//			{
//				$total_balance = $real_balance;
//			}
//		if($display=="number")
//			{
//				$total_balance = $number_balance;
//			}
//		elseif($display=="currency")
//			{
//				$total_balance = $currency_balance;
//			}
//		elseif($display=="status")
//			{
//				if($total_balance>0)
//					{
//						$total_balance = $currency_balance." (Dr)";
//					}
//				elseif($total_balance<0)
//					{
//						$total_balance = "<span style='color:red;'>".$currency_balance." (Cr)</span>";
//					}
//				elseif($total_ledger_balance==0)
//					{
//						$total_balance = $currency_balance." (Dr)";
//					}
//			}
//
//		return $total_balance;
//	}
			
$alert_val = "";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ekgaon Microfin</title>
    <!-- Bootstrap -->
    <link rel="icon" type="image/png" href="<?=$microfin_application_url;?>/themes/images/ek-microfin-favicon.png">
    <link href="<?= $microfin_application_url ?>/themes/css/bootstrap.css" rel="stylesheet">
    <link href="<?= $microfin_application_url ?>/themes/css/style.css" rel="stylesheet">
    <link href="<?= $microfin_application_url ?>/themes/css/font-awesome.min.css" rel="stylesheet"> 
    <link href="<?= $microfin_application_url ?>/themes/css/bootstrap-theme.css" rel="stylesheet">
    <link href="<?=$microfin_application_url?>/themes/css/accounts_nav.css" rel="stylesheet">
    <link href="<?=$microfin_application_url?>/themes/css/chart.css" rel="stylesheet">
    <link href="<?=$microfin_application_url?>/themes/css/tree.css" rel="stylesheet"> 
   
    <link href="<?= $microfin_application_url ?>/themes/css/includes/sidebar.css" rel="stylesheet">
    <link href="<?= $microfin_application_url ?>/themes/css/includes/header.css" rel="stylesheet">
    <link href="<?= $microfin_application_url ?>/themes/css/includes/filter.css" rel="stylesheet">
    <link href="<?= $microfin_application_url ?>/themes/css/pagination.css" rel="stylesheet">

    <script src="<?= $microfin_application_url ?>/themes/js/jquery.js"></script>
    <link rel="stylesheet" href="<?= $microfin_application_url ?>/themes/js/theme/jquery-ui.css">
    <script src="<?= $microfin_application_url ?>/themes/js/ui/jquery-ui.js"></script>
    <script src="<?= $microfin_application_url ?>/themes/js/bootstrap.min.js"></script>
    <script src="<?= $microfin_application_url ?>/themes/validator/validator.js"></script>
    <script src="<?= $microfin_application_url ?>/themes/js/highchart/highcharts.js"></script>
<!--    <script src="<?= $microfin_application_url ?>/themes/js/highchart/drilldown.js"></script>-->
    <script src="<?= $microfin_application_url ?>/themes/js/highchart/exporting.js"></script>
    <script src="<?= $microfin_application_url ?>/themes/js/date_browser/date_browser.js"></script>
<!--    <script src="https://code.highcharts.com/modules/drilldown.js"></script>-->
    <script src="http://github.highcharts.com/bdf6471/modules/data.js"></script>
    <script src="http://github.highcharts.com/bdf6471/modules/drilldown.src.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="<?= $microfin_application_url ?>/themes/js/mfi/mfi.js"></script>

    <script src="http://code.highcharts.com/highcharts.js"></script>
    <script src="http://code.highcharts.com/modules/drilldown.js"></script>
    <script type='text/javascript' src="<?= $microfin_application_url; ?>/themes/js/print_pdf_excel/print_excel_pdf_fun.js"></script>
 <style type="text/css">

#ajaxloader { 
font-family: Arial, Helvetica, sans-serif; font-weight:normal; 
color:#474747; 
font-size: 18px;/* margin:15% auto 0 auto;*/
margin-left: -34%;
font-weight:bold;
 }
</style>

<script>
    // Create global variable for all ajax base url
    var base_url = '<?=$microfin_application_url;?>';

    $(document).ready(function() {
        $("#wrapper").removeClass();

        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("active");
        });

        $(function() { $("[rel='tooltip']").tooltip(); });

        $('html').append('<div class="hid_tag"> sssss </div>');

        $(window).scroll(function() {
            if($(this).scrollTop() != 0)
                $('#toTop').fadeIn();
            else
                $('#toTop').fadeOut();
        });
        $('#toTop').click(function() {
                $('body,html').animate({scrollTop:0},800);
        });

    });
    </script>

    <style>
    .hid_tag {visibility: hidden;}
    .sidebar-wrapper { display: none; }
    .hid_tag {visibility: hidden;}
    .sidebar-wrapper { display: none; }
    .plus .toggle_icon { background: url(<?=$microfin_application_url;?>/accounts/plus_minus.png) 3px 2px no-repeat; }

    .minus .toggle_icon { background: url(<?=$microfin_application_url;?>/accounts/plus_minus.png) 3px -23px no-repeat; }
     .message-menu {width:340px;text-transform: capitalize;}
    .topbar-list .notification-padding {padding-top:15px;}
    </style>
</head>

<body>
    <!---start1---->
    <div class="header">
        <div class="row">
            <div class="col-md-2">
                <a class="header-logo"><img src="<?= $microfin_application_url; ?>/themes/images/ek-microfin-logo.png"/></a>
            </div>
            <div class="col-md-10">
                <div class="client-logo">
                    <img src="<?=$base_url;?>files/images/logo.jpg"/>
                </div>
                <div class="clear"></div>


                <ul class="topbar-list">		   
                  <!---------Account Settings Start-------------->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle avatar pull-right" data-toggle="dropdown">

                        <img src="<?= $microfin_application_url; ?>/themes/images/small/no_profile_female.png" width="40" alt="<?=$user_name;?> - <?=$user_role;?>" class="img-circle" />
                        <span class="user-name" style="text-transform: capitalize;"> <?=$user_name;?> - <span class='success'><?=$user_role;?></span></span>
                        <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu pull-right">
                           <!---li class="menu-item dropdown dropdown-submenu"> <a href="#"><i class="fa fa-user"></i> User Settings</a> </li><!----/user_settings/profile.php--->
                        <!---li class="divider"></li--->
                        <li class="menu-item dropdown dropdown-submenu"><a href="<?= $microfin_final_url; ?>superadmin/logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
<!--                        <li class="menu-item dropdown dropdown-submenu"><a href="<?= $base_url; ?>includes/logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>-->
                        </ul>
                    </li>
                     <!---------Account Settings End-------------->
                </ul>
            </div>
        </div>
    </div>
    <!---end1---->

    <!---start2--->
   <nav class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>


    <div class="collapse navbar-collapse" id="example-navbar-collapse">

        <ul class="nav navbar-nav">

            <li class="active">
              <? if($user_level == '1'){?>
                <a href="<?= $microfin_application_url; ?>/index.php">Dashboard</a>
              <?}
                 else if($user_level == '2'){?>
                <a href="<?= $microfin_application_url; ?>/branch/view/index.php">Dashboard</a>
              <?}
                else if($user_level == '3'){?>
                <a href="<?= $microfin_application_url; ?>/group/view/index.php">Dashboard</a>
              <?}
                 else { ?>
                <a href="<?= $microfin_application_url; ?>/field_officer/view/index.php">Dashboard</a>
              <?}?>

            </li>
            <!----REPORT MENU---->
            <li class='dropdown'>
                   <a href='#' data-toggle='dropdown' class='dropdown-toggle'>Reports<b class='caret'></b></a>
                   <ul class='dropdown-menu'>
                       <li class='menu-item dropdown'> <a href="<?=$microfin_final_url;?>superadmin/reports/head_office/loan_product_perform_monitor_rep.php">Loan Product Performance Monitoring Report</a></li>
                        <li class='menu-item dropdown'> <a href="<?=$microfin_final_url;?>superadmin/reports/head_office/loan_product_rep.php">Loan Product Report</a></li>
                         <li class='menu-item dropdown'> <a href="<?=$microfin_final_url;?>superadmin/reports/head_office/9bb_rep.php">9BB Report</a></li>
                         <li class='menu-item dropdown'> <a href="<?=$microfin_final_url;?>superadmin/reports/head_office/dcb_rep.php">DCB Report</a></li>
                         <li class='menu-item dropdown'> <a href="<?=$microfin_final_url;?>superadmin/reports/head_office/loan_summary_rep.php">Loan Summary Report</a></li>

                   </ul>
            </li>
            <!---REPORT MENU END--->
             
<?php
//$rid_result=mysql_query("SELECT userrole FROM user_registration WHERE id=".$user_id." ",$con);
//$rid=mysql_fetch_object($rid_result);
//
//
//$pri=mysql_query("SELECT privilege,level from user_roles where rid=".$rid->userrole." ",$con);
//$result_pri=mysql_fetch_object($pri);
//
//$cpri1 = $result_pri->privilege;
//$cpri = explode(",",$cpri1);
//sort($cpri);
//$count=sizeof($cpri);
//for($i=0;$i<$count;$i++) {?>
<!--li class="dropdown"><a class="top_parent" href="javascript:void(0)">Vouchers<b class="caret"></b></a>
  <ul class="dropdown-menu"> <li class="menu-item dropdown"> <a class="submenu" href="http://192.168.1.12/~sjdtmbt/modules/transaction/journal.php">Journal</a> </li></ul><ul class="dropdown-menu"> <li class="menu-item dropdown"> <a class="submenu" href="http://192.168.1.12/~sjdtmbt/modules/transaction/receipt.php">Receipt</a> </li></ul><ul class="dropdown-menu"> <li class="menu-item dropdown"> <a class="submenu" href="http://192.168.1.12/~sjdtmbt/modules/transaction/payment.php">Payment</a> </li></ul><ul class="dropdown-menu"> <li class="menu-item dropdown"> <a class="submenu" href="http://192.168.1.12/~sjdtmbt/modules/transaction/contra.php">Contra</a> </li></ul></li>
<li class="dropdown open">
                 <a data-toggle="dropdown" class="dropdown-toggle" href="#">Products<b class="caret"></b></a>
                  <ul class="dropdown-menu">

                 <li id="1" class="menu-item dropdown "><a href="http://192.168.1.2/~microfinance/final/application/product/loan/loan_product_list.php">Loan</a></li>
                  </ul>
              </li--->

<? //$sql=mysql_query("SELECT * FROM user_privileges WHERE hid=0 AND level=".$_SESSION['ulevel']." AND pid=".$cpri[$i]." ORDER BY sort ASC",$con);
//while($result=mysql_fetch_object($sql))
//	{
//	$cid_count=mysql_num_rows(mysql_query("SELECT * FROM user_privileges WHERE hid='".$result->cid."' AND level=".$_SESSION['ulevel']."",$con));
//	if($cid_count > 0)
//	{
//            echo "<li class='dropdown'>";
//
//	if($result->url == '') {
//
//       // echo "--true-->".$result->privilege_name."<BR>";
//	//echo "<a href='javascript:void(0)' class='top_parent'>".$result->privilege_name."<b class='caret'></b></a>";
//        	echo "<a href='#' data-toggle='dropdown' class='dropdown-toggle' >".$result->privilege_name."<b class='caret'></b></a>";
//
//		}
//	else {
//
//              // echo "--false-->".$result->privilege_name."<BR>";
//
//    $path = $base_url.$result->url;
//
//    echo "<a href='".$path."' class='top_parent'>".$result->privilege_name."<b class='caret'></b></a>";
//	}
//echo "<ul class='dropdown-menu'>";
//	$sql1=mysql_query("SELECT * FROM user_privileges WHERE hid='".$result->cid."' AND level=".$_SESSION['ulevel']." ORDER BY sort ASC",$con);
//	while($result1=mysql_fetch_object($sql1)) {
//		if(in_array($result1->pid,$cpri)) {
//		echo " <li class='menu-item dropdown'> <a href='".$base_url.$result1->url."'>".$result1->privilege_name."</a> </li>";
//		}
//	}
//	echo "</ul></li>";
//	 }
//// End of Inner For Loop for Parent Menu
//
//else  // Top Parent Menu, if the condition Fails
//	{
//	echo "<li class='menu-item dropdown'><a href='".$base_url.$result->url."' class='without'>".$result->privilege_name."</a> </li>";
//	}


//} // End of the Main While loop --
//} // End of the Main For loop --
?>


            
            </ul>                   
    </div>
    </nav>
    <!---end2---->


<?

 




    