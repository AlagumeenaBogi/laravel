<?
$current_time = time();
$year	= date('Y', $current_time );
?>
<!--div id="footer">
	<center>
		<span>
			<a href="#" style="color: #428bca; margin: 0px 10px;">Features</a> |
			<a href="#" style="color: #428bca; margin: 0px 10px;">Accounting</a> |
			<a href="#" style="color: #428bca; margin: 0px 10px;">Billing</a> |
			<a href="#" style="color: #428bca; margin: 0px 10px;">Monitoring</a> |
			<a href="#" style="color: #428bca; margin: 0px 10px;">Dashboard</a>
		</span>
	</center>
	<div class="wrapper">
		<p>&copy; 2014 | <a href="http://www.ekgaon.com/">ekgaon</a> one village one world network. <a href="terms_of_services.php">Terms of Services</a> | <a href="privacy_policy.php">Privacy Policy</a></p>
	</div>
</div-->
<div class="clear"></div>
<footer>
	<div class="container">
		<br>
		<div class="col-md-4">
			<span class="copyright">&copy; 2002 -<?=$year;?>  ekgaon one village one world network</span>
		</div>
		<div class="col-md-4">
			<center>
				<ul class="list-inline social-buttons">
					<li><a target="_blank" href="https://twitter.com/ekgaon"><img src="<?= $microfin_final_url; ?>/themes1/images/tw.png"></a>
					</li>
					<li><a target="_blank" href="https://facebook.com/ekgaon"><img src="<?= $microfin_final_url; ?>/themes1/images/fb.png"></a>
					</li>
					<li><a target="_blank" href="https://www.linkedin.com/company/ekgaon"><img src="<?= $microfin_final_url; ?>/themes1/images/in.png"></a>
					</li>
				</ul>
			</center>
		</div>
		<div class="col-md-4">
			<ul class="list-inline quicklinks">
				<li><a href="#">Privacy Policy</a>
				</li>
				<li><a href="#">Terms of Use</a>
				</li>
			</ul>
		</div>
		<div class="col-lg-12">
			<center>
						<span style="font-size:9px" class="copyright"><!---Registered Office: Plot No--E-142 A, Lower Ground Floor, Kalkaji, Near Laxmi Narayan Tample, New Delhi - 110019, India. --> Registered Office: #1, Kanishka Apartments - 1, Badiyavas, Amraiwadi, Ahmedabad - 380026, Gujarat, India | CIN: U72200GJ2002PTC41369</span>
					</center>
		</div>
		<div class="clear"></div>
		<br>
	</div>
</footer>
<!-- jQuery -->

</body>
<div id="toTop"><span class="glyphicon glyphicon-chevron-up"></span></div>

<?php /* ?>
<!--AddThis Smart Layers BEGIN -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5305ca3877affd91"></script>
<script type="text/javascript">
	addthis.layers({
		'theme' : 'gray',
		'share' : {
		  'position' : 'left',
		  'services' : 'facebook,twitter,linkedin,google_plusone_share,more',
		  'offset' : {'top':'35%'},
		  'numPreferredServices' : 5
		}   
	});
</script>
<!-- AddThis Smart Layers END -->
<?php */ ?>

<?php /* ?>
<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="//v2.zopim.com/?3HR4N8M9nPOu262KXuh08Tzsy7KuQfXG";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<!--End of Zopim Live Chat Script-->
<?php */ ?>

</html>
