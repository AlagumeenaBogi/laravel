<?


$microfin_application_url   = "http://192.168.1.12/~sjdtmbt/application";
$microfin_functions_url = "/home/sjdtmbt/public_html/functions";
$microfin_upload_url   = "http://192.168.1.12/~sjdtmbt//file_uploads";
$microfin_final_url       = "http://192.168.1.12/~sjdtmbt/";
$microfin_crons_url   = "http://192.168.1.2/~microfinance/crons";
$microfin_branch_demo_url   = "http://www.microfinance.in/branch_demo/application/branch/view";
$microfin_head_office_demo_url   = "http://www.microfinance.in/head_office_demo/application";
$microfin_invoice_url   = "http://192.168.1.2/~microfinance/invoice_new";
$microfin_admin_url   = "http://192.168.1.2/~microfinance/admin";
$microfin_sync_url   = "http://192.168.1.2/~microfinance/sync";
$microfin_includes_url   = "http://192.168.1.2/~microfinance/includes";
$microfin_forum_url   = "http://192.168.1.12/~sjdtmbt//forum";

$microfin_base_url        = "http://www.microfinance.in/";

//Ekgaon Global Database
$ekgaon_global_host              = "205.147.111.241";  // server to connect to.
$ekgaon_global_database_username = "microfin_microfn";  // mysql username to access the database with.
$ekgaon_global_database_password = '_#$y&;Hb-5#D';  // mysql password to access the database with.
$ekgaon_global_database          = "ekgaon_global";  // the name of the database.

$link_ekgaon_global = mysql_connect($ekgaon_global_host, $ekgaon_global_database_username, $ekgaon_global_database_password) or die("Cannot connect Ekgaon Client Database");
mysql_select_db($ekgaon_global_database, $link_ekgaon_global);



$microfinance_global_host              = "205.147.111.241";  // server to connect to.
$microfinance_global_database_username = "microfin_microfn";  // mysql username to access the database with.
$microfinance_global_database_password = '_#$y&;Hb-5#D';  // mysql password to access the database with.
//Microfinance Count List Database

$microfinance_count_list_database          = "microfinance_count_list";  // the name of the database.
$link_microfinance_count_list_global       = mysql_connect($microfinance_global_host, $microfinance_global_database_username, $microfinance_global_database_password, true) or die("Cannot Microfinance Client Database");
mysql_select_db($microfinance_count_list_database, $link_microfinance_count_list_global) or die(mysql_error());



$microfinance_forum_database          = "microfinance_forum";  // the name of the database.
$link_microfinance_forum              = mysql_connect($microfinance_global_host, $microfinance_global_database_username, $microfinance_global_database_password, true) or die("Cannot Microfinance Client Database");
mysql_select_db($microfinance_forum_database, $link_microfinance_forum);

$microfinance_global_database          = "microfinance_global";  // the name of the database.
$link_microfinance_global              = mysql_connect($microfinance_global_host, $microfinance_global_database_username, $microfinance_global_database_password, true) or die("Cannot Microfinance Client Database");
mysql_select_db($microfinance_global_database, $link_microfinance_global);

$mbt_host = "192.168.1.12";
$mbt_username = "sjdt1";
$mbt_password = "sjdt1";
$mbt_database = mysql_connect($mbt_host,$mbt_username,$mbt_password) or
die("cannssot connect to db");
//mysql_select_db("sjdthighmark",$con);
mysql_select_db("sjdt1_alagumeena",$mbt_database);

$global_database = mysql_connect("localhost","sjdt1","sjdt1") or
die("cannssot connect to db");
//mysql_select_db("sjdthighmark",$con);
$global_database_name="sjdt1_mbt_global";
mysql_select_db($global_database_name,$global_database);



date_default_timezone_set("Asia/Kolkata");

function logs() {
 echo "h : ".$base_url."<br>";
 // exit;
}
?>