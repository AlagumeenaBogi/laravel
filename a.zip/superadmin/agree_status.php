<?php
error_reporting(0);
include('db_connect.php');
session_start();
$user_id=$_SESSION['userid'];
$user_level=$_SESSION['ulevel'];
//echo "SELECT agree_status FROM {users} WHERE uid =$user_id"; 
 $db_qry=mysql_query("SELECT agree_status FROM user_registration WHERE id =$user_id",$global_database);
 $resu=mysql_fetch_object($db_qry);
 $staus=$resu->agree_status;
 if($staus == "1")
 { 
  if($user_level == "1")
  {
echo "<script>
         window.location.href= '../application/index.php'
      </script>";
  }
  else
      {
      echo "<script>
         window.location.href= '../application/branch/view/index.php'
      </script>";
  }
   
 }
  if($_REQUEST['submit'])  
  {

    $agree=$_REQUEST['agree'];
    $update_time=time();
    //echo "UPDATE user_registration SET agree_status='$agree',update_time='$update_time' WHERE id =$user_id"; exit;
    mysql_query("UPDATE user_registration SET agree_status='$agree',update_time='$update_time' WHERE id =$user_id",$global_database);
if($user_level == "1")
  {
echo "<script>
         window.location.href= '../application/index.php'
      </script>";
  }
  else
      {
      echo "<script>
         window.location.href= '../application/branch/view/index.php'
      </script>";
  }
   
  }  

?>
 <script>
        
        function agreement()
        {
            //alert("sdsd");
              //fld_val = document.getElementById(field).value;
            
            if( document.getElementById("agree").checked == false) 
                {
                    alert("Please select agreement");
                    return false;
                }
        }
    </script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>OneMIS - Online MIS Application for Microfinance Institutions</title>
<link rel="stylesheet" type="text/css" media="all" href="<?=$base_url;?>style/onemis.css"/>
 <link rel="stylesheet" href="css/basic-jquery-slider.css">
<script type="text/javascript" src="<?=$base_url;?>scripts/rounded.js"></script>
<script src="js/libs/jquery-1.6.2.min.js"></script>
<script src="js/basic-jquery-slider.js"></script>
    
</head>
<body style="margin: 1px 0px 0px; background-color:#c7c7c7;margin-left:auto;margin-right:auto;min-width:900px;max-width:1074px;" onload="show_clock()">

<table border=0 width="100%" bgcolor="#efefef">

<tr style="height: 72px;">
<td align="left">

<a href="<?=$base_url;?>">
<img src="files/images/onemis.png" alt="OneMIS" style="width: 140px; height: 70px; border: 0px;align: left; " /></a>
</td>
<td align='right'>
<img src=" http://microfinance.in/micro/webthemes/images/microfinance_logo.png" alt="OneMIS" style="width: 159px; height: 76px; border:0px;" />
</td>
</tr>

<tr>
<td align="right" style=" width:100%;" colspan = "2"><script type="text/javascript" src="scripts/liveclock.js"></script></td>
</tr>

<tr style="align: left;">
<td style="width: 100%; valign: top;" colspan="2"><hr style="color: #0A5074;" /></td>
</tr>

<!--<tr>
<td style="height: 40px; width: 100%;" colspan="2"></td>
</tr>-->

<tr>
<td style="width: 80%; valign: top; align: center;" valign=top colspan="2">

<form action="agree_status.php" method="post" id="index">

    
    <label>
<input type="checkbox" name="agree" id="agree" value="1"> I Agree to the terms of service and will adhere to them unconditionally &nbsp;<a href="<?=$base_url;?>/terms.php" target="_blank"><u style="font-size: 14px;">Read terms of service</u></a>
</label></br></br>
          
         <center> <input type="submit" name="submit" id="submit" value="submit" onclick="return agreement()"></center>

    </body>

<script type="text/javascript">
 Rounded('rounded', 7, 8);
</script>

</form>
</td>
<!--<td width=20%" valign="top">
<iframe src='http://www.opinionpoll.in/modules/plugins/plugin.php?pqid=219' frameborder='0' height='500px' scrolling='auto' style='overflow-x: hidden;'> </iframe> <br/>
<iframe src='http://www.opinionpoll.in/modules/election/rep_plugin.php?id=108' frameborder='0' height='500px' scrolling='auto' style='overflow-x: hidden;'></iframe>
</td>-->
</tr>

<tr style="height:42;">
<td style="width:100%;" colspan="2"><hr style="color: #0A5074;" />
	<table style="width: 100%; line-height: 18px;" title="Subtable">
	<tr>
		<td style="width: 20%;">
			<!--<img src="files/images/valid-xhtml10.png" alt="Valid XHTML" />
			<img src="files/images/valid-css.png" alt="Valid CSS" />
		</td>-->
		<td style="align: center;"> 
		<br>
			<center>Powered by <a href="http://www.ekgaon.com" target = "_blank"><img src="<?=$base_url;?>img/ekgaonlogo.png" alt="ekgaon" width = "60" style = "margin-bottom: -5px;"/></a> --- &nbsp;One Village One World Network&nbsp;|&nbsp;Copyright &copy; <?php echo date("Y");?>&nbsp;|&nbsp;<a href="http://180.179.52.193/support/ekg.php?pr=B53B3A3D6AB90CE0268229151C9BDE11NTU="  target="_blank"  alt="Support"><b>Support</b></a><br>

<i>Best viewed at 1024 x 768 resolution in Mozilla Firefox 2.0 and above</i>
		</td>
		<td style="width: 20%;"></td>
	</tr>
	</table>
</td></tr></table>
</body>
</html>




