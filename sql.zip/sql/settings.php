<?php
    //error_reporting(0);
    date_default_timezone_set('Asia/Calcutta'); // set the indian time
    $cur_date_ymd = date("Y-m-d");
    $cur_date_dmy = date("d-m-Y");
    $cur_day = date("d");
    $cur_month = date("m");
    $cur_year = date("Y");
    $time = time();
    $date_ymd = date("Y-m-d");
    $date_timestamp = strtotime($date_ymd);
    $ip_address   = $_SERVER['REMOTE_ADDR'];
    $sms_email_sent_url="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
