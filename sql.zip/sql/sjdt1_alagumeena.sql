-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 11, 2017 at 02:12 PM
-- Server version: 5.5.30
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sjdt1_alagumeena`
--

-- --------------------------------------------------------

--
-- Table structure for table `8s1_Salary_to_Logeswa_1001`
--

CREATE TABLE IF NOT EXISTS `8s1_Salary_to_Logeswa_1001` (
  `id` double NOT NULL,
  `repid` double NOT NULL,
  `iid` double NOT NULL,
  `voucherid` double NOT NULL,
  `refno` varchar(50) NOT NULL,
  `refyear` double NOT NULL,
  `debitamt` double NOT NULL,
  `creditamt` double NOT NULL,
  `date` double NOT NULL,
  `status` int(10) NOT NULL,
  `bankdate` double NOT NULL,
  `iddate` double NOT NULL,
  `balance` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `8s1_Salary_to_Logeswa_1001`
--

INSERT INTO `8s1_Salary_to_Logeswa_1001` (`id`, `repid`, `iid`, `voucherid`, `refno`, `refyear`, `debitamt`, `creditamt`, `date`, `status`, `bankdate`, `iddate`, `balance`) VALUES
(0, 20151031100001, 1001, 0, '', 0, 0, 0, 1446229800, 0, 0, 0, 0),
(201510310001, 201510310001, 1001, 310011510310003, 'jr', 2015, 7680, 0, 1446229800, 0, 0, 1446402600, 7680),
(201511300001, 201511300001, 1001, 310011511300003, 'jr', 2015, 7680, 0, 1448821800, 0, 0, 1449685800, 15360),
(201512310001, 201512310001, 1001, 310011512310006, 'jr', 2015, 7680, 0, 1451500200, 0, 0, 1452105000, 23040),
(201601300001, 201601300001, 1001, 310011601300002, 'jr', 2016, 7680, 0, 1454092200, 0, 0, 1454524200, 30720);

-- --------------------------------------------------------

--
-- Table structure for table `crons_loan_performance_monitoring_report`
--

CREATE TABLE IF NOT EXISTS `crons_loan_performance_monitoring_report` (
  `loan_perform_moni_id` int(250) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(250) NOT NULL,
  `mfi_name` varchar(1000) NOT NULL,
  `branch_id` int(250) NOT NULL,
  `branch_name` varchar(2000) NOT NULL,
  `product_id` int(250) NOT NULL,
  `product_name` varchar(2000) NOT NULL,
  `no_of_loans` double NOT NULL,
  `loan_disbursement` varchar(1000) NOT NULL,
  `loan_outstanding` varchar(10000) NOT NULL,
  `overdues_total` double NOT NULL,
  `overdue_5` double NOT NULL,
  `overdue_6_to_10` double NOT NULL,
  `overdue_11_to_15` double NOT NULL,
  `overdue_16_to_30` double NOT NULL,
  `overdue_31_to_60` double NOT NULL,
  `overdue_60` double NOT NULL,
  `overdue_interest_earned` double NOT NULL,
  `age_1_to_5` double NOT NULL,
  `age_6_to_10` double NOT NULL,
  `age_11_to_15` double NOT NULL,
  `age_16_to_20` double NOT NULL,
  `age_21_to_25` double NOT NULL,
  `age_26_to_30` double NOT NULL,
  `age_31_to_35` double NOT NULL,
  `age_36_to_40` double NOT NULL,
  `age_41_to_45` double NOT NULL,
  `age_46_to_50` double NOT NULL,
  `age_51_to_55` double NOT NULL,
  `age_56_to_60` double NOT NULL,
  `edu_quali_play_school` double NOT NULL,
  `edu_quali_primary` double NOT NULL,
  `edu_quali_secondary` double NOT NULL,
  `edu_quali_high_secondary` double NOT NULL,
  `edu_quali_non_graduate` double NOT NULL,
  `edu_quali_graduate` double NOT NULL,
  `edu_quali_post_graduate` double NOT NULL,
  `edu_quali_profession` double NOT NULL,
  `edu_quali_doctorate` double NOT NULL,
  `annual_income_bellow_50thousand` double NOT NULL,
  `annual_income_50thou_to_1lakh` double NOT NULL,
  `annual_income_1lakh_to_2lakh` double NOT NULL,
  `annual_income_2lakh_to_3lakh` double NOT NULL,
  `annual_income_3lakh_to_4lakh` double NOT NULL,
  `annual_income_4lakh_to_5lakh` double NOT NULL,
  `annual_income_5lakh_to_6lakh` double NOT NULL,
  `annual_income_6lakh_to_7lakh` double NOT NULL,
  `annual_income_7lakh_to_8lakh` double NOT NULL,
  `annual_income_8lakh_to_9lakh` double NOT NULL,
  `annual_income_9lakh_to_10lakh` double NOT NULL,
  `annual_income_above_10lakh` double NOT NULL,
  `male` double NOT NULL,
  `female` double NOT NULL,
  `transgender` double NOT NULL,
  `pwds` double NOT NULL,
  `salaried` double NOT NULL,
  `selfemployed_professionals` double NOT NULL,
  `business` double NOT NULL,
  `retired` double NOT NULL,
  `student` double NOT NULL,
  `housewife` double NOT NULL,
  `from_date` int(250) NOT NULL,
  `to_date` int(250) NOT NULL,
  `crons_created_time` int(11) NOT NULL,
  `crons_modified_time` int(11) NOT NULL,
  `status` int(250) NOT NULL,
  PRIMARY KEY (`loan_perform_moni_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `crons_loan_performance_monitoring_report`
--

INSERT INTO `crons_loan_performance_monitoring_report` (`loan_perform_moni_id`, `mfi_id`, `mfi_name`, `branch_id`, `branch_name`, `product_id`, `product_name`, `no_of_loans`, `loan_disbursement`, `loan_outstanding`, `overdues_total`, `overdue_5`, `overdue_6_to_10`, `overdue_11_to_15`, `overdue_16_to_30`, `overdue_31_to_60`, `overdue_60`, `overdue_interest_earned`, `age_1_to_5`, `age_6_to_10`, `age_11_to_15`, `age_16_to_20`, `age_21_to_25`, `age_26_to_30`, `age_31_to_35`, `age_36_to_40`, `age_41_to_45`, `age_46_to_50`, `age_51_to_55`, `age_56_to_60`, `edu_quali_play_school`, `edu_quali_primary`, `edu_quali_secondary`, `edu_quali_high_secondary`, `edu_quali_non_graduate`, `edu_quali_graduate`, `edu_quali_post_graduate`, `edu_quali_profession`, `edu_quali_doctorate`, `annual_income_bellow_50thousand`, `annual_income_50thou_to_1lakh`, `annual_income_1lakh_to_2lakh`, `annual_income_2lakh_to_3lakh`, `annual_income_3lakh_to_4lakh`, `annual_income_4lakh_to_5lakh`, `annual_income_5lakh_to_6lakh`, `annual_income_6lakh_to_7lakh`, `annual_income_7lakh_to_8lakh`, `annual_income_8lakh_to_9lakh`, `annual_income_9lakh_to_10lakh`, `annual_income_above_10lakh`, `male`, `female`, `transgender`, `pwds`, `salaried`, `selfemployed_professionals`, `business`, `retired`, `student`, `housewife`, `from_date`, `to_date`, `crons_created_time`, `crons_modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 0, 'ALL Product', 0, '', '0.00', 20077976, 784380, 919964, 1449862, 6431027, 9952447, 540296, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465964517, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 0, 'All Product', 0, '', '7202357.00', 2757549, 150465, 0, 318034, 840592, 1339881, 108577, 62037, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465967876, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 1, 'Agriculture', 0, '', '1069680.00', 808860, 81681, 0, 84552, 164795, 408286, 69546, 10675, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968283, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 2, 'Small Business', 0, '', '1905898.00', 605083, 12897, 0, 99755, 184110, 302512, 5809, 17385, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968404, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 3, 'Milch Animal', 0, '', '3501292.00', 1150777, 50155, 0, 101646, 428723, 537043, 33210, 26962, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968498, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 4, 'Self Employment', 0, '', '715487.00', 191396, 5732, 0, 32081, 61531, 92040, 12, 6832, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968666, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968696, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 6, 'Fishing and Connected Business', 0, '', '10000.00', 1433, 0, 0, 0, 1433, 0, 0, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968696, 0, 1),
(9, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968698, 0, 1),
(10, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968698, 0, 1),
(11, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968699, 0, 1),
(12, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968700, 0, 1),
(13, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968701, 0, 1),
(14, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968701, 0, 1),
(15, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968702, 0, 1),
(16, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968703, 0, 1),
(17, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968704, 0, 1),
(18, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968705, 0, 1),
(19, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968705, 0, 1),
(20, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968706, 0, 1),
(21, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968707, 0, 1),
(22, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968708, 0, 1),
(23, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968708, 0, 1),
(24, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968709, 0, 1),
(25, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968710, 0, 1),
(26, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968711, 0, 1),
(27, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968712, 0, 1),
(28, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968712, 0, 1),
(29, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968713, 0, 1),
(30, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968714, 0, 1),
(31, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968715, 0, 1),
(32, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968715, 0, 1),
(33, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968716, 0, 1),
(34, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968717, 0, 1),
(35, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968718, 0, 1),
(36, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968719, 0, 1),
(37, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968719, 0, 1),
(38, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968720, 0, 1),
(39, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968721, 0, 1),
(40, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968722, 0, 1),
(41, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968723, 0, 1),
(42, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968724, 0, 1),
(43, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968724, 0, 1),
(44, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968725, 0, 1),
(45, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968726, 0, 1),
(46, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968727, 0, 1),
(47, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968727, 0, 1),
(48, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968728, 0, 1),
(49, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968729, 0, 1),
(50, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968730, 0, 1),
(51, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968730, 0, 1),
(52, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968731, 0, 1),
(53, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968732, 0, 1),
(54, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968733, 0, 1),
(55, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968733, 0, 1),
(56, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 0, 'All Product', 0, '', '8871195.00', 2960309, 0, 204477, 292062, 753300, 1710470, 0, 120719, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465968734, 0, 1),
(57, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 1, 'Agriculture', 0, '', '94874.00', 101146, 0, 1911, 0, 32423, 66812, 0, 244, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969176, 0, 1),
(58, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 2, 'Small Business', 0, '', '1043226.00', 314275, 0, 11466, 56997, 77219, 168593, 0, 10675, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969192, 0, 1),
(59, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 3, 'Milch Animal', 0, '', '5572478.00', 1975295, 0, 177723, 207838, 477313, 1112421, 0, 89670, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969236, 0, 1),
(60, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 4, 'Self Employment', 0, '', '518047.00', 200227, 0, 0, 1433, 88162, 110632, 0, 2135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969529, 0, 1),
(61, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969558, 0, 1),
(62, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 6, 'Fishing and Connected Business', 0, '', '1634257.00', 359833, 0, 13377, 25794, 78183, 242479, 0, 17995, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969559, 0, 1),
(63, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 7, 'Educational', 0, '', '8313.00', 9533, 0, 0, 0, 0, 9533, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969629, 0, 1),
(64, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969632, 0, 1),
(65, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 0, 'All Product', 0, '', '10545669.00', 2736282, 144741, 206357, 186774, 1168211, 1001554, 28645, 220576, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465969633, 0, 1),
(66, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 1, 'Agriculture', 0, '', '230221.00', 130257, 5732, 32004, 9555, 30930, 52036, 0, 12566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970224, 0, 1),
(67, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 2, 'Small Business', 0, '', '2172840.00', 595791, 63060, 28183, 16720, 279643, 196723, 11462, 46970, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970256, 0, 1),
(68, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 3, 'Milch Animal', 0, '', '7357675.00', 1802537, 75949, 98879, 152378, 772226, 685922, 17183, 144143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970382, 0, 1),
(69, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 4, 'Self Employment', 0, '', '773683.00', 206264, 0, 47291, 8121, 83979, 66873, 0, 16714, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970777, 0, 1),
(70, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970818, 0, 1),
(71, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 6, 'Fishing and Connected Business', 0, '', '11250.00', 1433, 0, 0, 0, 1433, 0, 0, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970819, 0, 1),
(72, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970820, 0, 1),
(73, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970821, 0, 1),
(74, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 0, 'All Product', 0, '', '10632141.00', 3456457, 106042, 153235, 136135, 1313783, 1726745, 20517, 122061, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465970822, 0, 1),
(75, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 1, 'Agriculture', 0, '', '184690.00', 97134, 4299, 5183, 4299, 38212, 45141, 0, 3599, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465971500, 0, 1),
(76, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 2, 'Small Business', 0, '', '4165486.00', 1548719, 50155, 40763, 21495, 644302, 788182, 3822, 36844, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465971524, 0, 1),
(77, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 3, 'Milch Animal', 0, '', '3490976.00', 938645, 17196, 53080, 90279, 325183, 447678, 5229, 49105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465971820, 0, 1),
(78, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 4, 'Self Employment', 0, '', '2579669.00', 808965, 30093, 52776, 18629, 282235, 413766, 11466, 30744, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972010, 0, 1),
(79, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 5, 'Housing', 0, '', '178820.00', 55829, 4299, 1433, 0, 22418, 27679, 0, 1037, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972180, 0, 1),
(80, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 6, 'Fishing and Connected Business', 0, '', '32500.00', 7165, 0, 0, 1433, 1433, 4299, 0, 732, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972191, 0, 1),
(81, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972194, 0, 1),
(82, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972195, 0, 1),
(83, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 0, 'All Product', 0, '', '12781420.00', 4384230, 383132, 147621, 261783, 1293034, 2050732, 247928, 127307, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972196, 0, 1),
(84, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 1, 'Agriculture', 0, '', '511171.00', 251075, 23407, 9555, 8598, 97590, 103327, 8598, 11773, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972852, 0, 1),
(85, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 2, 'Small Business', 0, '', '5431954.00', 1859983, 189657, 64017, 97453, 528701, 877447, 102708, 57523, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465972899, 0, 1),
(86, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 3, 'Milch Animal', 0, '', '2349627.00', 748410, 30096, 22453, 54936, 250231, 355345, 35349, 14640, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973170, 0, 1),
(87, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 4, 'Self Employment', 0, '', '4313688.00', 1456930, 134240, 51596, 96497, 399315, 681174, 94108, 41480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973278, 0, 1),
(88, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 5, 'Housing', 0, '', '84988.00', 32005, 2866, 0, 1433, 7165, 17675, 2866, 1708, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973490, 0, 1),
(89, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 6, 'Fishing and Connected Business', 0, '', '78328.00', 29139, 1433, 0, 2866, 8121, 12420, 4299, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973498, 0, 1),
(90, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 7, 'Educational', 0, '', '11664.00', 6688, 1433, 0, 0, 1911, 3344, 0, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973502, 0, 1),
(91, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973504, 0, 1),
(92, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 0, 'All Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973504, 0, 1),
(93, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 1, 'Agriculture', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973505, 0, 1),
(94, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 2, 'Small Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973506, 0, 1),
(95, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 3, 'Milch Animal', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973507, 0, 1),
(96, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 4, 'Self Employment', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973507, 0, 1),
(97, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973508, 0, 1),
(98, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 6, 'Fishing and Connected Business', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973509, 0, 1),
(99, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973510, 0, 1),
(100, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973510, 0, 1),
(101, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 0, 'All Product', 0, '', '11314204.00', 3783149, 0, 208274, 255074, 1062107, 2123065, 134629, 114070, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465973511, 0, 1),
(102, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 1, 'Agriculture', 0, '', '977165.00', 604693, 0, 56844, 0, 148961, 377870, 21018, 31964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974147, 0, 1),
(103, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 2, 'Small Business', 0, '', '4443435.00', 1459674, 0, 77864, 121805, 359438, 811317, 89250, 38918, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974276, 0, 1),
(104, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 3, 'Milch Animal', 0, '', '3704155.00', 1085013, 0, 53503, 87413, 351126, 585807, 7164, 27572, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974514, 0, 1),
(105, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 4, 'Self Employment', 0, '', '2026415.00', 580462, 0, 18630, 44423, 194795, 305417, 17197, 11651, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974683, 0, 1),
(106, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974774, 0, 1),
(107, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 6, 'Fishing and Connected Business', 0, '', '155121.00', 49967, 0, 1433, 1433, 7787, 39314, 0, 3782, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974776, 0, 1),
(108, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 7, 'Educational', 0, '', '7913.00', 3340, 0, 0, 0, 0, 3340, 0, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974787, 0, 1),
(109, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 8, 'Testing Product', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1465929000, 1465974790, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `crons_loan_performance_monitoring_report_superadmin`
--

CREATE TABLE IF NOT EXISTS `crons_loan_performance_monitoring_report_superadmin` (
  `loan_perform_moni_id` int(250) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(250) NOT NULL,
  `mfi_name` varchar(1000) NOT NULL,
  `branch_id` int(250) NOT NULL,
  `branch_name` varchar(2000) NOT NULL,
  `product_id` int(250) NOT NULL,
  `product_name` varchar(2000) NOT NULL,
  `no_of_loans` double NOT NULL,
  `loan_disbursement` varchar(1000) NOT NULL,
  `loan_outstanding` varchar(10000) NOT NULL,
  `overdues_total` double NOT NULL,
  `overdue_5` double NOT NULL,
  `overdue_6_to_10` double NOT NULL,
  `overdue_11_to_15` double NOT NULL,
  `overdue_16_to_30` double NOT NULL,
  `overdue_31_to_60` double NOT NULL,
  `overdue_60` double NOT NULL,
  `overdue_interest_earned` double NOT NULL,
  `age_1_to_5` double NOT NULL,
  `age_6_to_10` double NOT NULL,
  `age_11_to_15` double NOT NULL,
  `age_16_to_20` double NOT NULL,
  `age_21_to_25` double NOT NULL,
  `age_26_to_30` double NOT NULL,
  `age_31_to_35` double NOT NULL,
  `age_36_to_40` double NOT NULL,
  `age_41_to_45` double NOT NULL,
  `age_46_to_50` double NOT NULL,
  `age_51_to_55` double NOT NULL,
  `age_56_to_60` double NOT NULL,
  `edu_quali_play_school` double NOT NULL,
  `edu_quali_primary` double NOT NULL,
  `edu_quali_secondary` double NOT NULL,
  `edu_quali_high_secondary` double NOT NULL,
  `edu_quali_non_graduate` double NOT NULL,
  `edu_quali_graduate` double NOT NULL,
  `edu_quali_post_graduate` double NOT NULL,
  `edu_quali_profession` double NOT NULL,
  `edu_quali_doctorate` double NOT NULL,
  `annual_income_bellow_50thousand` double NOT NULL,
  `annual_income_50thou_to_1lakh` double NOT NULL,
  `annual_income_1lakh_to_2lakh` double NOT NULL,
  `annual_income_2lakh_to_3lakh` double NOT NULL,
  `annual_income_3lakh_to_4lakh` double NOT NULL,
  `annual_income_4lakh_to_5lakh` double NOT NULL,
  `annual_income_5lakh_to_6lakh` double NOT NULL,
  `annual_income_6lakh_to_7lakh` double NOT NULL,
  `annual_income_7lakh_to_8lakh` double NOT NULL,
  `annual_income_8lakh_to_9lakh` double NOT NULL,
  `annual_income_9lakh_to_10lakh` double NOT NULL,
  `annual_income_above_10lakh` double NOT NULL,
  `male` double NOT NULL,
  `female` double NOT NULL,
  `transgender` double NOT NULL,
  `pwds` double NOT NULL,
  `salaried` double NOT NULL,
  `selfemployed_professionals` double NOT NULL,
  `business` double NOT NULL,
  `retired` double NOT NULL,
  `student` double NOT NULL,
  `housewife` double NOT NULL,
  `from_date` int(250) NOT NULL,
  `to_date` int(250) NOT NULL,
  `crons_created_time` int(11) NOT NULL,
  `crons_modified_time` int(11) NOT NULL,
  `status` int(250) NOT NULL,
  PRIMARY KEY (`loan_perform_moni_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=113 ;

--
-- Dumping data for table `crons_loan_performance_monitoring_report_superadmin`
--

INSERT INTO `crons_loan_performance_monitoring_report_superadmin` (`loan_perform_moni_id`, `mfi_id`, `mfi_name`, `branch_id`, `branch_name`, `product_id`, `product_name`, `no_of_loans`, `loan_disbursement`, `loan_outstanding`, `overdues_total`, `overdue_5`, `overdue_6_to_10`, `overdue_11_to_15`, `overdue_16_to_30`, `overdue_31_to_60`, `overdue_60`, `overdue_interest_earned`, `age_1_to_5`, `age_6_to_10`, `age_11_to_15`, `age_16_to_20`, `age_21_to_25`, `age_26_to_30`, `age_31_to_35`, `age_36_to_40`, `age_41_to_45`, `age_46_to_50`, `age_51_to_55`, `age_56_to_60`, `edu_quali_play_school`, `edu_quali_primary`, `edu_quali_secondary`, `edu_quali_high_secondary`, `edu_quali_non_graduate`, `edu_quali_graduate`, `edu_quali_post_graduate`, `edu_quali_profession`, `edu_quali_doctorate`, `annual_income_bellow_50thousand`, `annual_income_50thou_to_1lakh`, `annual_income_1lakh_to_2lakh`, `annual_income_2lakh_to_3lakh`, `annual_income_3lakh_to_4lakh`, `annual_income_4lakh_to_5lakh`, `annual_income_5lakh_to_6lakh`, `annual_income_6lakh_to_7lakh`, `annual_income_7lakh_to_8lakh`, `annual_income_8lakh_to_9lakh`, `annual_income_9lakh_to_10lakh`, `annual_income_above_10lakh`, `male`, `female`, `transgender`, `pwds`, `salaried`, `selfemployed_professionals`, `business`, `retired`, `student`, `housewife`, `from_date`, `to_date`, `crons_created_time`, `crons_modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 0, 'All Product', 839, '13195000', '70251574.00', 809288, 213951, 42990, 0, 492462, 44581, 15304, 4362842, 0, 0, 0, 1.4, 4.87, 11.13, 21.18, 21.75, 17.14, 18.23, 3.47, 0.73, 0.67, 64.01, 26.77, 8.08, 0.05, 0.16, 0.16, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.16, 99.74, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226574, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 0, 'All Product', 839, '13195000', '70251574.00', 809288, 213951, 42990, 0, 492462, 44581, 15304, 4362842, 0, 0, 0, 1.4, 4.87, 11.13, 21.18, 21.75, 17.14, 18.23, 3.47, 0.73, 0.67, 64.01, 26.77, 8.08, 0.05, 0.16, 0.16, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.16, 99.74, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226590, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 1, 'Agriculture', 19, '285000', '1433534.00', 61493, 0, 0, 0, 30575, 23272, 7646, 371185, 0, 0, 0, 0, 0, 8.51, 23.4, 29.79, 17.02, 10.64, 10.64, 0, 0, 95.74, 4.26, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226671, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 1, 'Agriculture', 19, '285000', '1433534.00', 61493, 0, 0, 0, 30575, 23272, 7646, 371185, 0, 0, 0, 0, 0, 8.51, 23.4, 29.79, 17.02, 10.64, 10.64, 0, 0, 95.74, 4.26, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226672, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 2, 'Small Business', 234, '3680000', '21000793.00', 239705, 24814, 0, 0, 198686, 14294, 1911, 1336998, 0, 0, 0, 2.03, 6.63, 12.89, 19.15, 22.1, 16.02, 16.21, 4.24, 0.37, 0.37, 69.43, 22.65, 6.81, 0, 0.18, 0.18, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99.63, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226680, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 2, 'Small Business', 234, '3680000', '21000793.00', 239705, 24814, 0, 0, 198686, 14294, 1911, 1336998, 0, 0, 0, 2.03, 6.63, 12.89, 19.15, 22.1, 16.02, 16.21, 4.24, 0.37, 0.37, 69.43, 22.65, 6.81, 0, 0.18, 0.18, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99.63, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226680, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 3, 'Milch Animal', 501, '7945000', '33191451.00', 370911, 162383, 0, 0, 204448, 2155, 1925, 1785836, 0, 0, 0, 0.96, 4.26, 10.36, 21.24, 20.89, 17.15, 20.89, 3.22, 1.04, 0.7, 58.57, 31.16, 9.31, 0.09, 0.09, 0.09, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.26, 99.74, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226711, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 3, 'Milch Animal', 501, '7945000', '33191451.00', 370911, 162383, 0, 0, 204448, 2155, 1925, 1785836, 0, 0, 0, 0.96, 4.26, 10.36, 21.24, 20.89, 17.15, 20.89, 3.22, 1.04, 0.7, 58.57, 31.16, 9.31, 0.09, 0.09, 0.09, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.26, 99.74, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226711, 0, 1),
(9, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 4, 'Self Employment', 47, '715000', '10885561.00', 76991, 15288, 0, 0, 53021, 4860, 3822, 706014, 0, 0, 0, 4.72, 6.6, 16.98, 28.3, 22.64, 12.26, 6.6, 1.89, 0, 1.89, 60.38, 25.47, 10.38, 0, 0.94, 0.94, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226762, 0, 1),
(10, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 4, 'Self Employment', 47, '715000', '10885561.00', 76991, 15288, 0, 0, 53021, 4860, 3822, 706014, 0, 0, 0, 4.72, 6.6, 16.98, 28.3, 22.64, 12.26, 6.6, 1.89, 0, 1.89, 60.38, 25.47, 10.38, 0, 0.94, 0.94, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226762, 0, 1),
(11, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 5, 'Housing', 4, '60000', '1227360.00', 2866, 0, 0, 0, 2866, 0, 0, 46543, 0, 0, 0, 0, 12.5, 0, 37.5, 37.5, 0, 12.5, 0, 0, 12.5, 37.5, 50, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226777, 0, 1),
(12, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 5, 'Housing', 4, '60000', '1227360.00', 2866, 0, 0, 0, 2866, 0, 0, 46543, 0, 0, 0, 0, 12.5, 0, 37.5, 37.5, 0, 12.5, 0, 0, 12.5, 37.5, 50, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226777, 0, 1),
(13, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 6, 'Fishing and Connected Business', 33, '495000', '2489545.00', 57322, 11466, 42990, 0, 2866, 0, 0, 113033, 0, 0, 0, 0, 0, 5.33, 22.67, 25.33, 33.33, 13.33, 0, 0, 0, 97.33, 1.33, 1.33, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226781, 0, 1),
(14, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 6, 'Fishing and Connected Business', 33, '495000', '2489545.00', 57322, 11466, 42990, 0, 2866, 0, 0, 113033, 0, 0, 0, 0, 0, 5.33, 22.67, 25.33, 33.33, 13.33, 0, 0, 0, 97.33, 1.33, 1.33, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226781, 0, 1),
(15, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 7, 'Educational', 1, '15000', '23330.00', 0, 0, 0, 0, 0, 0, 0, 3233, 0, 0, 0, 0, 33.33, 0, 0, 0, 33.33, 33.33, 0, 0, 0, 33.33, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226788, 0, 1),
(16, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 'All Branch', 7, 'Educational', 1, '15000', '23330.00', 0, 0, 0, 0, 0, 0, 0, 3233, 0, 0, 0, 0, 33.33, 0, 0, 0, 33.33, 33.33, 0, 0, 0, 33.33, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226788, 0, 1),
(17, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 0, 'All Product', 149, '2235000', '9189656.00', 86505, 0, 0, 0, 55390, 23469, 7646, 537959, 0, 0, 0, 0, 7.16, 10.6, 16.62, 26.36, 21.2, 18.05, 0, 0, 1.72, 70.2, 27.22, 0.86, 0, 0, 0, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 99, 0, 0, 0, 0, 1459449000, 1466188200, 1466226792, 0, 1),
(18, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 0, 'All Product', 149, '2235000', '9189656.00', 86505, 0, 0, 0, 55390, 23469, 7646, 537959, 0, 0, 0, 0, 7.16, 10.6, 16.62, 26.36, 21.2, 18.05, 0, 0, 1.72, 70.2, 27.22, 0.86, 0, 0, 0, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 99, 0, 0, 0, 0, 1459449000, 1466188200, 1466226792, 0, 1),
(19, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 1, 'Agriculture', 4, '60000', '507169.00', 61493, 0, 0, 0, 30575, 23272, 7646, 114131, 0, 0, 0, 0, 0, 0, 37.5, 25, 12.5, 25, 0, 0, 0, 75, 25, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226809, 0, 1),
(20, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 1, 'Agriculture', 4, '60000', '507169.00', 61493, 0, 0, 0, 30575, 23272, 7646, 114131, 0, 0, 0, 0, 0, 0, 37.5, 25, 12.5, 25, 0, 0, 0, 75, 25, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226809, 0, 1),
(21, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 2, 'Small Business', 70, '1050000', '2985722.00', 13543, 0, 0, 0, 13350, 193, 0, 134871, 0, 0, 0, 0, 8.28, 14.01, 14.65, 23.57, 20.38, 19.11, 0, 0, 0, 65.61, 33.12, 1.27, 0, 0, 0, 0, 0, 98, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226815, 0, 1),
(22, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 2, 'Small Business', 70, '1050000', '2985722.00', 13543, 0, 0, 0, 13350, 193, 0, 134871, 0, 0, 0, 0, 8.28, 14.01, 14.65, 23.57, 20.38, 19.11, 0, 0, 0, 65.61, 33.12, 1.27, 0, 0, 0, 0, 0, 98, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226815, 0, 1),
(23, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 3, 'Milch Animal', 72, '1080000', '4664865.00', 11469, 0, 0, 0, 11465, 4, 0, 239486, 0, 0, 0, 0, 6.25, 7.95, 17.61, 28.41, 22.73, 17.05, 0, 0, 3.41, 75, 21.02, 0.57, 0, 0, 0, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 98, 0, 0, 0, 0, 1459449000, 1466188200, 1466226823, 0, 1),
(24, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 3, 'Milch Animal', 72, '1080000', '4664865.00', 11469, 0, 0, 0, 11465, 4, 0, 239486, 0, 0, 0, 0, 6.25, 7.95, 17.61, 28.41, 22.73, 17.05, 0, 0, 3.41, 75, 21.02, 0.57, 0, 0, 0, 0, 0, 99, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 98, 0, 0, 0, 0, 1459449000, 1466188200, 1466226823, 0, 1),
(25, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 4, 'Self Employment', 2, '30000', '1009400.00', 0, 0, 0, 0, 0, 0, 0, 48922, 0, 0, 0, 0, 0, 20, 20, 60, 0, 0, 0, 0, 0, 60, 40, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226833, 0, 1),
(26, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 4, 'Self Employment', 2, '30000', '1009400.00', 0, 0, 0, 0, 0, 0, 0, 48922, 0, 0, 0, 0, 0, 20, 20, 60, 0, 0, 0, 0, 0, 60, 40, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226833, 0, 1),
(27, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(28, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(29, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 6, 'Fishing and Connected Business', 0, '', '8750.00', 0, 0, 0, 0, 0, 0, 0, 366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(30, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 6, 'Fishing and Connected Business', 0, '', '8750.00', 0, 0, 0, 0, 0, 0, 0, 366, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(31, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 7, 'Educational', 1, '15000', '13750.00', 0, 0, 0, 0, 0, 0, 0, 183, 0, 0, 0, 0, 33.33, 0, 0, 0, 33.33, 33.33, 0, 0, 0, 33.33, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(32, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 7, 'Educational', 1, '15000', '13750.00', 0, 0, 0, 0, 0, 0, 0, 183, 0, 0, 0, 0, 33.33, 0, 0, 0, 33.33, 33.33, 0, 0, 0, 33.33, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226838, 0, 1),
(33, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 0, 'All Product', 214, '3445000', '12587898.00', 374513, 191082, 42990, 0, 140441, 0, 0, 642452, 0, 0, 0, 1.4, 6.8, 10.6, 24.8, 21.4, 15.6, 16.2, 2.2, 0.6, 0, 97.8, 1.8, 0, 0, 0, 0, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.6, 99, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226843, 0, 1),
(34, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 0, 'All Product', 214, '3445000', '12587898.00', 374513, 191082, 42990, 0, 140441, 0, 0, 642452, 0, 0, 0, 1.4, 6.8, 10.6, 24.8, 21.4, 15.6, 16.2, 2.2, 0.6, 0, 97.8, 1.8, 0, 0, 0, 0, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.6, 99, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226843, 0, 1),
(35, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 1, 'Agriculture', 0, '', '6660.00', 0, 0, 0, 0, 0, 0, 0, 13176, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226864, 0, 1),
(36, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 1, 'Agriculture', 0, '', '6660.00', 0, 0, 0, 0, 0, 0, 0, 13176, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226864, 0, 1),
(37, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 2, 'Small Business', 49, '800000', '2020052.00', 59233, 11465, 0, 0, 47768, 0, 0, 69357, 0, 0, 0, 0.87, 9.57, 10.43, 21.74, 29.57, 13.91, 11.3, 0.87, 0, 0, 95.65, 2.61, 0, 0, 0, 0, 0, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98.26, 0, 0, 0, 98, 0, 0, 0, 0, 1459449000, 1466188200, 1466226864, 0, 1),
(38, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 2, 'Small Business', 49, '800000', '2020052.00', 59233, 11465, 0, 0, 47768, 0, 0, 69357, 0, 0, 0, 0.87, 9.57, 10.43, 21.74, 29.57, 13.91, 11.3, 0.87, 0, 0, 95.65, 2.61, 0, 0, 0, 0, 0, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98.26, 0, 0, 0, 98, 0, 0, 0, 0, 1459449000, 1466188200, 1466226864, 0, 1),
(39, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 3, 'Milch Animal', 135, '2195000', '8263098.00', 245536, 152863, 0, 0, 92673, 0, 0, 447252, 0, 0, 0, 1.92, 7.35, 11.82, 26.52, 17.89, 11.82, 18.53, 3.19, 0.96, 0, 98.08, 1.92, 0, 0, 0, 0, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.96, 99.04, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226871, 0, 1),
(40, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 3, 'Milch Animal', 135, '2195000', '8263098.00', 245536, 152863, 0, 0, 92673, 0, 0, 447252, 0, 0, 0, 1.92, 7.35, 11.82, 26.52, 17.89, 11.82, 18.53, 3.19, 0.96, 0, 98.08, 1.92, 0, 0, 0, 0, 0, 0, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.96, 99.04, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226871, 0, 1),
(41, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 4, 'Self Employment', 0, '', '343318.00', 15288, 15288, 0, 0, 0, 0, 0, 27633, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226887, 0, 1),
(42, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 4, 'Self Employment', 0, '', '343318.00', 15288, 15288, 0, 0, 0, 0, 0, 27633, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226887, 0, 1),
(43, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226888, 0, 1),
(44, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226888, 0, 1),
(45, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 6, 'Fishing and Connected Business', 30, '450000', '1954770.00', 54456, 11466, 42990, 0, 0, 0, 0, 83814, 0, 0, 0, 0, 0, 5.56, 22.22, 23.61, 34.72, 13.89, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226888, 0, 1),
(46, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 6, 'Fishing and Connected Business', 30, '450000', '1954770.00', 54456, 11466, 42990, 0, 0, 0, 0, 83814, 0, 0, 0, 0, 0, 5.56, 22.22, 23.61, 34.72, 13.89, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226888, 0, 1),
(47, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 1220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226895, 0, 1),
(48, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 1220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226895, 0, 1),
(49, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 0, 'All Product', 271, '4305000', '13450653.00', 32424, 20962, 0, 0, 0, 11462, 0, 772626, 0, 0, 0, 2.76, 3.58, 11.54, 19.84, 16.75, 16.1, 22.11, 5.53, 1.79, 0, 16.59, 60, 23.25, 0.16, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226895, 0, 1),
(50, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 0, 'All Product', 271, '4305000', '13450653.00', 32424, 20962, 0, 0, 0, 11462, 0, 772626, 0, 0, 0, 2.76, 3.58, 11.54, 19.84, 16.75, 16.1, 22.11, 5.53, 1.79, 0, 16.59, 60, 23.25, 0.16, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226895, 0, 1),
(51, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 1, 'Agriculture', 0, '', '94958.00', 0, 0, 0, 0, 0, 0, 0, 32391, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226922, 0, 1),
(52, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 1, 'Agriculture', 0, '', '94958.00', 0, 0, 0, 0, 0, 0, 0, 32391, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226922, 0, 1),
(53, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 2, 'Small Business', 38, '625000', '2209724.00', 22904, 11442, 0, 0, 0, 11462, 0, 147437, 0, 0, 0, 9.28, 7.22, 16.49, 17.53, 12.37, 12.37, 12.37, 10.31, 2.06, 0, 15.46, 52.58, 31.96, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226923, 0, 1),
(54, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 2, 'Small Business', 38, '625000', '2209724.00', 22904, 11442, 0, 0, 0, 11462, 0, 147437, 0, 0, 0, 9.28, 7.22, 16.49, 17.53, 12.37, 12.37, 12.37, 10.31, 2.06, 0, 15.46, 52.58, 31.96, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226923, 0, 1),
(55, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 3, 'Milch Animal', 216, '3415000', '9899688.00', 9520, 9520, 0, 0, 0, 0, 0, 526613, 0, 0, 0, 0.62, 2.07, 9.75, 20.54, 18.05, 17.63, 24.9, 4.56, 1.87, 0, 15.77, 62.45, 21.58, 0.21, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226930, 0, 1),
(56, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 3, 'Milch Animal', 216, '3415000', '9899688.00', 9520, 9520, 0, 0, 0, 0, 0, 526613, 0, 0, 0, 0.62, 2.07, 9.75, 20.54, 18.05, 17.63, 24.9, 4.56, 1.87, 0, 15.77, 62.45, 21.58, 0.21, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226930, 0, 1),
(57, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 4, 'Self Employment', 16, '250000', '1221283.00', 0, 0, 0, 0, 0, 0, 0, 65819, 0, 0, 0, 14.29, 14.29, 22.86, 17.14, 8.57, 5.71, 11.43, 5.71, 0, 0, 31.43, 45.71, 22.86, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226951, 0, 1),
(58, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 4, 'Self Employment', 16, '250000', '1221283.00', 0, 0, 0, 0, 0, 0, 0, 65819, 0, 0, 0, 14.29, 14.29, 22.86, 17.14, 8.57, 5.71, 11.43, 5.71, 0, 0, 31.43, 45.71, 22.86, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226951, 0, 1),
(59, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226956, 0, 1),
(60, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 5, 'Housing', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226956, 0, 1),
(61, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 6, 'Fishing and Connected Business', 1, '15000', '25000.00', 0, 0, 0, 0, 0, 0, 0, 366, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226956, 0, 1),
(62, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 6, 'Fishing and Connected Business', 1, '15000', '25000.00', 0, 0, 0, 0, 0, 0, 0, 366, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226956, 0, 1),
(63, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226960, 0, 1),
(64, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226960, 0, 1),
(65, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 0, 'All Product', 29, '435000', '10361528.00', 58865, 0, 0, 0, 41557, 9650, 7658, 733830, 0, 0, 0, 0, 0, 22.39, 14.93, 40.3, 16.42, 4.48, 1.49, 0, 10.45, 10.45, 59.7, 10.45, 0, 4.48, 4.48, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226960, 0, 1),
(66, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 0, 'All Product', 29, '435000', '10361528.00', 58865, 0, 0, 0, 41557, 9650, 7658, 733830, 0, 0, 0, 0, 0, 22.39, 14.93, 40.3, 16.42, 4.48, 1.49, 0, 10.45, 10.45, 59.7, 10.45, 0, 4.48, 4.48, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226960, 0, 1),
(67, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 1, 'Agriculture', 0, '', '72500.00', 0, 0, 0, 0, 0, 0, 0, 19520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226976, 0, 1),
(68, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 1, 'Agriculture', 0, '', '72500.00', 0, 0, 0, 0, 0, 0, 0, 19520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466226976, 0, 1),
(69, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 2, 'Small Business', 11, '165000', '3682194.00', 20313, 0, 0, 0, 15763, 2639, 1911, 303109, 0, 0, 0, 0, 0, 21.74, 13.04, 30.43, 26.09, 4.35, 4.35, 0, 8.7, 8.7, 60.87, 13.04, 0, 4.35, 4.35, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226977, 0, 1),
(70, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 2, 'Small Business', 11, '165000', '3682194.00', 20313, 0, 0, 0, 15763, 2639, 1911, 303109, 0, 0, 0, 0, 0, 21.74, 13.04, 30.43, 26.09, 4.35, 4.35, 0, 8.7, 8.7, 60.87, 13.04, 0, 4.35, 4.35, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226977, 0, 1),
(71, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 3, 'Milch Animal', 9, '135000', '3415818.00', 16973, 0, 0, 0, 12897, 2151, 1925, 213988, 0, 0, 0, 0, 0, 33.33, 9.52, 38.1, 19.05, 0, 0, 0, 9.52, 4.76, 66.67, 9.52, 0, 4.76, 4.76, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226986, 0, 1),
(72, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 3, 'Milch Animal', 9, '135000', '3415818.00', 16973, 0, 0, 0, 12897, 2151, 1925, 213988, 0, 0, 0, 0, 0, 33.33, 9.52, 38.1, 19.05, 0, 0, 0, 9.52, 4.76, 66.67, 9.52, 0, 4.76, 4.76, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226986, 0, 1),
(73, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 4, 'Self Employment', 6, '90000', '2601199.00', 17280, 0, 0, 0, 8598, 4860, 3822, 174643, 0, 0, 0, 0, 0, 18.75, 12.5, 56.25, 6.25, 6.25, 0, 0, 12.5, 18.75, 50, 6.25, 0, 6.25, 6.25, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226992, 0, 1),
(74, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 4, 'Self Employment', 6, '90000', '2601199.00', 17280, 0, 0, 0, 8598, 4860, 3822, 174643, 0, 0, 0, 0, 0, 18.75, 12.5, 56.25, 6.25, 6.25, 0, 0, 12.5, 18.75, 50, 6.25, 0, 6.25, 6.25, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226992, 0, 1),
(75, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 5, 'Housing', 2, '30000', '374066.00', 2866, 0, 0, 0, 2866, 0, 0, 16043, 0, 0, 0, 0, 0, 0, 33.33, 50, 0, 16.67, 0, 0, 16.67, 16.67, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226998, 0, 1),
(76, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 5, 'Housing', 2, '30000', '374066.00', 2866, 0, 0, 0, 2866, 0, 0, 16043, 0, 0, 0, 0, 0, 0, 33.33, 50, 0, 16.67, 0, 0, 16.67, 16.67, 66.67, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466226998, 0, 1),
(77, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 6, 'Fishing and Connected Business', 1, '15000', '215751.00', 1433, 0, 0, 0, 1433, 0, 0, 6527, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227002, 0, 1),
(78, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 6, 'Fishing and Connected Business', 1, '15000', '215751.00', 1433, 0, 0, 0, 1433, 0, 0, 6527, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227002, 0, 1),
(79, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227006, 0, 1),
(80, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 7, 'Educational', 0, '', '0.00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227006, 0, 1),
(81, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 0, 'All Product', 92, '1380000', '12305078.00', 0, 0, 0, 0, 0, 0, 0, 868945, 0, 0, 0, 0, 2.88, 12.02, 29.33, 19.23, 21.63, 9.13, 5.77, 0, 0, 97.12, 1.44, 1.44, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227006, 0, 1),
(82, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 0, 'All Product', 92, '1380000', '12305078.00', 0, 0, 0, 0, 0, 0, 0, 868945, 0, 0, 0, 0, 2.88, 12.02, 29.33, 19.23, 21.63, 9.13, 5.77, 0, 0, 97.12, 1.44, 1.44, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227006, 0, 1),
(83, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 1, 'Agriculture', 15, '225000', '489512.00', 0, 0, 0, 0, 0, 0, 0, 55327, 0, 0, 0, 0, 0, 10.26, 20.51, 30.77, 17.95, 7.69, 12.82, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227023, 0, 1),
(84, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 1, 'Agriculture', 15, '225000', '489512.00', 0, 0, 0, 0, 0, 0, 0, 55327, 0, 0, 0, 0, 0, 10.26, 20.51, 30.77, 17.95, 7.69, 12.82, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227024, 0, 1),
(85, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 2, 'Small Business', 36, '540000', '5021227.00', 0, 0, 0, 0, 0, 0, 0, 370331, 0, 0, 0, 0, 3.7, 12.35, 25.93, 18.52, 17.28, 13.58, 8.64, 0, 0, 96.3, 2.47, 1.23, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227028, 0, 1),
(86, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 2, 'Small Business', 36, '540000', '5021227.00', 0, 0, 0, 0, 0, 0, 0, 370331, 0, 0, 0, 0, 3.7, 12.35, 25.93, 18.52, 17.28, 13.58, 8.64, 0, 0, 96.3, 2.47, 1.23, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227028, 0, 1),
(87, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 3, 'Milch Animal', 18, '270000', '2375446.00', 0, 0, 0, 0, 0, 0, 0, 138104, 0, 0, 0, 0, 2.63, 13.16, 28.95, 10.53, 36.84, 7.89, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227037, 0, 1),
(88, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 3, 'Milch Animal', 18, '270000', '2375446.00', 0, 0, 0, 0, 0, 0, 0, 138104, 0, 0, 0, 0, 2.63, 13.16, 28.95, 10.53, 36.84, 7.89, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227037, 0, 1),
(89, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 4, 'Self Employment', 23, '345000', '4251001.00', 0, 0, 0, 0, 0, 0, 0, 291275, 0, 0, 0, 0, 4, 12, 42, 18, 20, 4, 0, 0, 0, 94, 2, 4, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227043, 0, 1),
(90, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 4, 'Self Employment', 23, '345000', '4251001.00', 0, 0, 0, 0, 0, 0, 0, 291275, 0, 0, 0, 0, 4, 12, 42, 18, 20, 4, 0, 0, 0, 94, 2, 4, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227043, 0, 1),
(91, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 5, 'Housing', 0, '', '46652.00', 0, 0, 0, 0, 0, 0, 0, 7320, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227051, 0, 1),
(92, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 5, 'Housing', 0, '', '46652.00', 0, 0, 0, 0, 0, 0, 0, 7320, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227051, 0, 1),
(93, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 6, 'Fishing and Connected Business', 0, '', '115410.00', 0, 0, 0, 0, 0, 0, 0, 5551, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227051, 0, 1),
(94, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 6, 'Fishing and Connected Business', 0, '', '115410.00', 0, 0, 0, 0, 0, 0, 0, 5551, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227051, 0, 1),
(95, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 7, 'Educational', 0, '', '5830.00', 0, 0, 0, 0, 0, 0, 0, 1037, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227052, 0, 1),
(96, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 7, 'Educational', 0, '', '5830.00', 0, 0, 0, 0, 0, 0, 0, 1037, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227052, 0, 1),
(97, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 0, 'All Product', 84, '1395000', '12356761.00', 256981, 1907, 0, 0, 255074, 0, 0, 807030, 0, 0, 0, 1.56, 3.65, 7.29, 17.71, 26.56, 12.5, 26.04, 4.69, 0, 0, 99.48, 0.52, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227052, 0, 1),
(98, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 0, 'All Product', 84, '1395000', '12356761.00', 256981, 1907, 0, 0, 255074, 0, 0, 807030, 0, 0, 0, 1.56, 3.65, 7.29, 17.71, 26.56, 12.5, 26.04, 4.69, 0, 0, 99.48, 0.52, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227052, 0, 1),
(99, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 1, 'Agriculture', 0, '', '262735.00', 0, 0, 0, 0, 0, 0, 0, 136640, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227069, 0, 1),
(100, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 1, 'Agriculture', 0, '', '262735.00', 0, 0, 0, 0, 0, 0, 0, 136640, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227069, 0, 1),
(101, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 2, 'Small Business', 30, '500000', '5081874.00', 123712, 1907, 0, 0, 121805, 0, 0, 311893, 0, 0, 0, 1.43, 2.86, 7.14, 21.43, 21.43, 10, 30, 5.71, 0, 0, 98.57, 1.43, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227071, 0, 1),
(102, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 2, 'Small Business', 30, '500000', '5081874.00', 123712, 1907, 0, 0, 121805, 0, 0, 311893, 0, 0, 0, 1.43, 2.86, 7.14, 21.43, 21.43, 10, 30, 5.71, 0, 0, 98.57, 1.43, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227071, 0, 1),
(103, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 3, 'Milch Animal', 51, '850000', '4572536.00', 87413, 0, 0, 0, 87413, 0, 0, 220393, 0, 0, 0, 1.68, 3.36, 7.56, 15.13, 29.41, 14.29, 24.37, 4.2, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227079, 0, 1),
(104, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 3, 'Milch Animal', 51, '850000', '4572536.00', 87413, 0, 0, 0, 87413, 0, 0, 220393, 0, 0, 0, 1.68, 3.36, 7.56, 15.13, 29.41, 14.29, 24.37, 4.2, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227079, 0, 1),
(105, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 4, 'Self Employment', 0, '', '1459360.00', 44423, 0, 0, 0, 44423, 0, 0, 97722, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227088, 0, 1),
(106, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 4, 'Self Employment', 0, '', '1459360.00', 44423, 0, 0, 0, 44423, 0, 0, 97722, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227088, 0, 1),
(107, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 5, 'Housing', 2, '30000', '806642.00', 0, 0, 0, 0, 0, 0, 0, 23180, 0, 0, 0, 0, 50, 0, 50, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227090, 0, 1),
(108, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 5, 'Housing', 2, '30000', '806642.00', 0, 0, 0, 0, 0, 0, 0, 23180, 0, 0, 0, 0, 50, 0, 50, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227090, 0, 1),
(109, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 6, 'Fishing and Connected Business', 1, '15000', '169864.00', 1433, 0, 0, 0, 1433, 0, 0, 16409, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227094, 0, 1),
(110, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 6, 'Fishing and Connected Business', 1, '15000', '169864.00', 1433, 0, 0, 0, 1433, 0, 0, 16409, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 0, 0, 1459449000, 1466188200, 1466227094, 0, 1),
(111, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 7, 'Educational', 0, '', '3750.00', 0, 0, 0, 0, 0, 0, 0, 793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227097, 0, 1),
(112, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 7, 'Educational', 0, '', '3750.00', 0, 0, 0, 0, 0, 0, 0, 793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1459449000, 1466188200, 1466227097, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_9bb_particulars_report`
--

CREATE TABLE IF NOT EXISTS `cron_9bb_particulars_report` (
  `particular_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_level` int(11) NOT NULL,
  `account_level_id` int(11) NOT NULL,
  `account_level_name` varchar(1000) NOT NULL,
  `cur_yr_loan_disbursment` double NOT NULL,
  `cur_no_of_shg_given_loan` double NOT NULL,
  `cur_no_of_client_newloan` double NOT NULL,
  `cur_no_of_client_reloan` double NOT NULL,
  `cur_no_of_client_total` double NOT NULL,
  `cur_average_capital_loan_size` double NOT NULL,
  `cur_average_shg_loan_size` double NOT NULL,
  `cur_active_borrow_yearend` double NOT NULL,
  `cur_no_of_shg_enroll` double NOT NULL,
  `cur_no_of_client_enroll` double NOT NULL,
  `cur_on_time_repay` double NOT NULL,
  `pre_yr_loan_disbursment` double NOT NULL,
  `pre_no_of_shg_given_loan` double NOT NULL,
  `pre_no_of_client_newloan` double NOT NULL,
  `pre_no_of_client_reloan` double NOT NULL,
  `pre_no_of_client_total` double NOT NULL,
  `pre_average_capital_loan_size` double NOT NULL,
  `pre_average_shg_loan_size` double NOT NULL,
  `pre_active_borrow_yearend` double NOT NULL,
  `pre_no_of_shg_enroll` double NOT NULL,
  `pre_no_of_client_enroll` double NOT NULL,
  `pre_on_time_repay` double NOT NULL,
  `from_filter_time` int(11) NOT NULL,
  `to_filter_time` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`particular_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cron_9bb_particulars_report`
--

INSERT INTO `cron_9bb_particulars_report` (`particular_id`, `account_level`, `account_level_id`, `account_level_name`, `cur_yr_loan_disbursment`, `cur_no_of_shg_given_loan`, `cur_no_of_client_newloan`, `cur_no_of_client_reloan`, `cur_no_of_client_total`, `cur_average_capital_loan_size`, `cur_average_shg_loan_size`, `cur_active_borrow_yearend`, `cur_no_of_shg_enroll`, `cur_no_of_client_enroll`, `cur_on_time_repay`, `pre_yr_loan_disbursment`, `pre_no_of_shg_given_loan`, `pre_no_of_client_newloan`, `pre_no_of_client_reloan`, `pre_no_of_client_total`, `pre_average_capital_loan_size`, `pre_average_shg_loan_size`, `pre_active_borrow_yearend`, `pre_no_of_shg_enroll`, `pre_no_of_client_enroll`, `pre_on_time_repay`, `from_filter_time`, `to_filter_time`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 130250000, 536, 7792, 2, 7794, 16707.29, 243003.73, 7794, 654, 12579, 0, 1459449000, 1465929000, 1465964624, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_branch_loan_ledger`
--

CREATE TABLE IF NOT EXISTS `cron_branch_loan_ledger` (
  `pk_id` int(11) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `client_name` text NOT NULL,
  `loan_acno` smallint(6) NOT NULL,
  `date_of_loan` text NOT NULL,
  `loan_issued` bigint(20) NOT NULL,
  `principla_loan_opening_os` bigint(20) NOT NULL,
  `interest` varchar(20) NOT NULL,
  `overdue` varchar(20) NOT NULL,
  `prepayment` bigint(20) NOT NULL,
  `amount_during_this_period` bigint(20) NOT NULL,
  `principal_closing_os` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cron_branch_loan_ledger`
--


-- --------------------------------------------------------

--
-- Table structure for table `cron_branch_wise_loan_product`
--

CREATE TABLE IF NOT EXISTS `cron_branch_wise_loan_product` (
  `branch_wise_loan_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(250) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(250) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `with_without_staff_filter` int(11) NOT NULL,
  `loan_issued` varchar(1000) NOT NULL,
  `principal_opeing_loan_outstanding` varchar(1000) NOT NULL,
  `interest` varchar(1000) NOT NULL,
  `overdue` varchar(1000) NOT NULL,
  `prepayment` varchar(1000) NOT NULL,
  `amount_paid_during_this_period` varchar(1000) NOT NULL,
  `closing_loan_outstanding` varchar(1000) NOT NULL,
  `from_date_filter` int(11) NOT NULL,
  `to_date_filter` int(11) NOT NULL,
  `created_time` int(11) NOT NULL,
  `modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`branch_wise_loan_product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `cron_branch_wise_loan_product`
--

INSERT INTO `cron_branch_wise_loan_product` (`branch_wise_loan_product_id`, `mfi_id`, `mfi_name`, `branch_id`, `branch_name`, `product_id`, `product_name`, `with_without_staff_filter`, `loan_issued`, `principal_opeing_loan_outstanding`, `interest`, `overdue`, `prepayment`, `amount_paid_during_this_period`, `closing_loan_outstanding`, `from_date_filter`, `to_date_filter`, `created_time`, `modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 0, 'All Product', 0, '0', '7602631', '62037', '2757549', '0', '462311', '7202357', 1459449000, 1465929000, 1465964566, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 1, 'Agriculture', 0, '0', '1141686', '10675', '808860', '0', '82681', '1069680', 1459449000, 1465929000, 1465964566, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 2, 'Small Business', 0, '0', '2017648', '17385', '605083', '0', '129135', '1905898', 1459449000, 1465929000, 1465964566, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 3, 'Milch Animal', 0, '0', '3672560', '26962', '1150777', '0', '198230', '3501292', 1459449000, 1465929000, 1465964566, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 4, 'Self Employment', 0, '0', '759487', '6832', '191396', '0', '50832', '715487', 1459449000, 1465929000, 1465964566, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 6, 'Fishing and Connected Business', 0, '0', '11250', '183', '1433', '0', '1433', '10000', 1459449000, 1465929000, 1465964566, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(9, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Chidambaram', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(10, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(11, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(12, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(13, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(14, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(15, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(16, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(17, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(18, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Nagarkovil', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(19, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(20, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(21, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(22, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(23, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(24, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(25, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(26, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(27, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Ponnamaravathi', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(28, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(29, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(30, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(31, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(32, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(33, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(34, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(35, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(36, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Mayiladuturai', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(37, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(38, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(39, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(40, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(41, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(42, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(43, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(44, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(45, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Thisyanvelai', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(46, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(47, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(48, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(49, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(50, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(51, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(52, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(53, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(54, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Avudayarkovil', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(55, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 0, 'All Product', 0, '0', '9455774', '120719', '2960309', '0', '934230', '8871195', 1459449000, 1465929000, 1465964566, 0, 1),
(56, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 1, 'Agriculture', 0, '0', '96541', '244', '101146', '0', '1911', '94874', 1459449000, 1465929000, 1465964566, 0, 1),
(57, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 2, 'Small Business', 0, '0', '1063229', '10675', '314275', '0', '79928', '1043226', 1459449000, 1465929000, 1465964566, 0, 1),
(58, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 3, 'Milch Animal', 0, '0', '6021630', '89670', '1975295', '0', '694754', '5572478', 1459449000, 1465929000, 1465964566, 0, 1),
(59, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 4, 'Self Employment', 0, '0', '531383', '2135', '200227', '0', '16721', '518047', 1459449000, 1465929000, 1465964566, 0, 1),
(60, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(61, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 6, 'Fishing and Connected Business', 0, '0', '1734678', '17995', '359833', '0', '140916', '1634257', 1459449000, 1465929000, 1465964566, 0, 1),
(62, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 7, 'Educational', 0, '0', '8313', '0', '9533', '0', '0', '8313', 1459449000, 1465929000, 1465964566, 0, 1),
(63, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Sirkazhi', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(64, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 0, 'All Product', 0, '0', '12059178', '220576', '2736282', '1167', '1734085', '10545669', 1459449000, 1465929000, 1465964566, 0, 1),
(65, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 1, 'Agriculture', 0, '0', '329381', '12566', '130257', '0', '111726', '230221', 1459449000, 1465929000, 1465964566, 0, 1),
(66, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 2, 'Small Business', 0, '0', '2498508', '46970', '595791', '0', '372638', '2172840', 1459449000, 1465929000, 1465964566, 0, 1),
(67, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 3, 'Milch Animal', 0, '0', '8332432', '144143', '1802537', '1167', '1118900', '7357675', 1459449000, 1465929000, 1465964566, 0, 1),
(68, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 4, 'Self Employment', 0, '0', '886357', '16714', '206264', '0', '129388', '773683', 1459449000, 1465929000, 1465964566, 0, 1),
(69, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(70, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 6, 'Fishing and Connected Business', 0, '0', '12500', '183', '1433', '0', '1433', '11250', 1459449000, 1465929000, 1465964566, 0, 1),
(71, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(72, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Karaikal ', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(73, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 0, 'All Product', 0, '0', '11566184', '122061', '3449791', '1433', '1056104', '10632141', 1459449000, 1465929000, 1465964566, 0, 1),
(74, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 1, 'Agriculture', 0, '0', '213547', '3599', '97134', '0', '32456', '184690', 1459449000, 1465929000, 1465964566, 0, 1),
(75, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 2, 'Small Business', 0, '0', '4444949', '36844', '1547050', '0', '316307', '4165486', 1459449000, 1465929000, 1465964566, 0, 1),
(76, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 3, 'Milch Animal', 0, '0', '3870802', '49105', '935315', '0', '428931', '3490976', 1459449000, 1465929000, 1465964566, 0, 1),
(77, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 4, 'Self Employment', 0, '0', '2813482', '30744', '807298', '1433', '264557', '2579669', 1459449000, 1465929000, 1465964566, 0, 1),
(78, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 5, 'Housing', 0, '0', '185904', '1037', '55829', '0', '8121', '178820', 1459449000, 1465929000, 1465964566, 0, 1),
(79, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 6, 'Fishing and Connected Business', 0, '0', '37500', '732', '7165', '0', '5732', '32500', 1459449000, 1465929000, 1465964566, 0, 1),
(80, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(81, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Vallioor', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(82, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 0, 'All Product', 0, '0', '13722158', '127307', '4384230', '0', '1068045', '12781420', 1459449000, 1465929000, 1465964566, 0, 1),
(83, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 1, 'Agriculture', 0, '0', '598246', '11773', '251075', '0', '98848', '511171', 1459449000, 1465929000, 1465964566, 0, 1),
(84, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 2, 'Small Business', 0, '0', '5859748', '57523', '1859983', '0', '485317', '5431954', 1459449000, 1465929000, 1465964566, 0, 1),
(85, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 3, 'Milch Animal', 0, '0', '2453449', '14640', '748410', '0', '118462', '2349627', 1459449000, 1465929000, 1465964566, 0, 1),
(86, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 4, 'Self Employment', 0, '0', '4622817', '41480', '1456930', '0', '350609', '4313688', 1459449000, 1465929000, 1465964566, 0, 1),
(87, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 5, 'Housing', 0, '0', '96656', '1708', '32005', '0', '13376', '84988', 1459449000, 1465929000, 1465964566, 0, 1),
(88, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 6, 'Fishing and Connected Business', 0, '0', '78328', '0', '29139', '0', '0', '78328', 1459449000, 1465929000, 1465964566, 0, 1),
(89, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 7, 'Educational', 0, '0', '12914', '183', '6688', '0', '1433', '11664', 1459449000, 1465929000, 1465964566, 0, 1),
(90, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Periyakulam', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(91, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 0, 'All Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(92, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 1, 'Agriculture', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(93, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 2, 'Small Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(94, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 3, 'Milch Animal', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(95, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 4, 'Self Employment', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(96, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(97, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 6, 'Fishing and Connected Business', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(98, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(99, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Aranthanki', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(100, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 0, 'All Product', 0, '0', '12102185', '114070', '3783149', '0', '902051', '11314204', 1459449000, 1465929000, 1465964566, 0, 1),
(101, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 1, 'Agriculture', 0, '0', '1195531', '31964', '604693', '0', '250330', '977165', 1459449000, 1465929000, 1465964566, 0, 1),
(102, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 2, 'Small Business', 0, '0', '4709279', '38918', '1459674', '0', '304762', '4443435', 1459449000, 1465929000, 1465964566, 0, 1),
(103, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 3, 'Milch Animal', 0, '0', '3901252', '27572', '1085013', '0', '224669', '3704155', 1459449000, 1465929000, 1465964566, 0, 1),
(104, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 4, 'Self Employment', 0, '0', '2106001', '11651', '580462', '0', '91237', '2026415', 1459449000, 1465929000, 1465964566, 0, 1),
(105, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1),
(106, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 6, 'Fishing and Connected Business', 0, '0', '180959', '3782', '49967', '0', '29620', '155121', 1459449000, 1465929000, 1465964566, 0, 1),
(107, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 7, 'Educational', 0, '0', '9163', '183', '3340', '0', '1433', '7913', 1459449000, 1465929000, 1465964566, 0, 1),
(108, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, '', 8, 'Testing Product', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1465929000, 1465964566, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_branch_wish_loan_dibursement_report`
--

CREATE TABLE IF NOT EXISTS `cron_branch_wish_loan_dibursement_report` (
  `loan_disburse_branch_wise_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(500) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(500) NOT NULL,
  `current_year_loan_disbursement` double NOT NULL,
  `previous_year_loan_disbursement` double NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`loan_disburse_branch_wise_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `cron_branch_wish_loan_dibursement_report`
--

INSERT INTO `cron_branch_wish_loan_dibursement_report` (`loan_disburse_branch_wise_id`, `mfi_id`, `mfi_name`, `branch_id`, `branch_name`, `current_year_loan_disbursement`, `previous_year_loan_disbursement`, `from_filter_date`, `to_filter_date`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 0, 15615000, 1459449000, 1465929000, 1465964597, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 2002, 'Chidambaram', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 2003, 'Nagarkovil', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 2004, 'Ponnamaravathi', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 2005, 'Mayiladuturai', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 2006, 'Thisyanvelai', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 0, 18710000, 1459449000, 1465929000, 1465964597, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 0, 21760000, 1459449000, 1465929000, 1465964597, 0, 1),
(9, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 0, 24690000, 1459449000, 1465929000, 1465964597, 0, 1),
(10, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 0, 25340000, 1459449000, 1465929000, 1465964597, 0, 1),
(11, 1001, 'Valar Aditi Social Finance Private Ltd', 2023, 'Periyakulam', 0, 0, 1459449000, 1465929000, 1465964597, 0, 1),
(12, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 0, 24135000, 1459449000, 1465929000, 1465964597, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_current_assets`
--

CREATE TABLE IF NOT EXISTS `cron_current_assets` (
  `current_assets_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_level` int(250) NOT NULL,
  `account_level_id` int(11) NOT NULL,
  `account_level_name` varchar(1000) NOT NULL,
  `label_name` varchar(1000) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`current_assets_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `cron_current_assets`
--

INSERT INTO `cron_current_assets` (`current_assets_id`, `account_level`, `account_level_id`, `account_level_name`, `label_name`, `amount`, `from_filter_date`, `to_filter_date`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1, 1001, 'Valar Aditi Social Finance Private Ltd', 'Cash at Hand', 8103.00, 1459449000, 1466101800, 1466137622, 0, 1),
(2, 1, 1001, 'Valar Aditi Social Finance Private Ltd', 'Cash at bank', 73501.32, 1459449000, 1466101800, 1466137622, 0, 1),
(3, 2, 2001, 'Tranqubar', 'Cash at Hand', 1067344.00, 1459449000, 1466101800, 1466137622, 0, 1),
(4, 2, 2001, 'Tranqubar', 'Cash at bank', -7637386.00, 1459449000, 1466101800, 1466137622, 0, 1),
(5, 2, 2002, 'Chidambaram', 'Cash at Hand', 2385000.00, 1459449000, 1466101800, 1466137622, 0, 1),
(6, 2, 2002, 'Chidambaram', 'Cash at bank', -1681563.20, 1459449000, 1466101800, 1466137622, 0, 1),
(7, 2, 2003, 'Nagarkovil', 'Cash at Hand', 0.00, 1459449000, 1466101800, 1466137622, 0, 1),
(8, 2, 2003, 'Nagarkovil', 'Cash at bank', 0.00, 1459449000, 1466101800, 1466137622, 0, 1),
(9, 2, 2004, 'Ponnamaravathi', 'Cash at Hand', 0.00, 1459449000, 1466101800, 1466137622, 0, 1),
(10, 2, 2004, 'Ponnamaravathi', 'Cash at bank', 657966.00, 1459449000, 1466101800, 1466137622, 0, 1),
(11, 2, 2005, 'Mayiladuturai', 'Cash at Hand', 1095000.00, 1459449000, 1466101800, 1466137622, 0, 1),
(12, 2, 2005, 'Mayiladuturai', 'Cash at bank', -666576.00, 1459449000, 1466101800, 1466137622, 0, 1),
(13, 2, 2006, 'Thisyanvelai', 'Cash at Hand', 0.00, 1459449000, 1466101800, 1466137622, 0, 1),
(14, 2, 2006, 'Thisyanvelai', 'Cash at bank', 477425.00, 1459449000, 1466101800, 1466137622, 0, 1),
(15, 2, 2007, 'Avudayarkovil', 'Cash at Hand', -358315.00, 1459449000, 1466101800, 1466137622, 0, 1),
(16, 2, 2007, 'Avudayarkovil', 'Cash at bank', -8001105.00, 1459449000, 1466101800, 1466137622, 0, 1),
(17, 2, 2008, 'Sirkazhi', 'Cash at Hand', -3695901.00, 1459449000, 1466101800, 1466137622, 0, 1),
(18, 2, 2008, 'Sirkazhi', 'Cash at bank', -6934272.00, 1459449000, 1466101800, 1466137622, 0, 1),
(19, 2, 2021, 'Karaikal ', 'Cash at Hand', 88301.00, 1459449000, 1466101800, 1466137622, 0, 1),
(20, 2, 2021, 'Karaikal ', 'Cash at bank', -9760648.35, 1459449000, 1466101800, 1466137622, 0, 1),
(21, 2, 2022, 'Vallioor', 'Cash at Hand', 554556.00, 1459449000, 1466101800, 1466137622, 0, 1),
(22, 2, 2022, 'Vallioor', 'Cash at bank', -12525421.00, 1459449000, 1466101800, 1466137622, 0, 1),
(23, 2, 2023, 'Periyakulam', 'Cash at Hand', 665000.00, 1459449000, 1466101800, 1466137622, 0, 1),
(24, 2, 2023, 'Periyakulam', 'Cash at bank', -351936.70, 1459449000, 1466101800, 1466137622, 0, 1),
(25, 2, 2024, 'Aranthanki', 'Cash at Hand', 1340962.00, 1459449000, 1466101800, 1466137622, 0, 1),
(26, 2, 2024, 'Aranthanki', 'Cash at bank', -11768339.80, 1459449000, 1466101800, 1466137622, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_demand_report`
--

CREATE TABLE IF NOT EXISTS `cron_demand_report` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `filter_type` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `principal_closing_loan` bigint(20) NOT NULL,
  `current_due` int(11) NOT NULL,
  `over_due` int(11) NOT NULL,
  `total_due` bigint(20) NOT NULL,
  PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cron_demand_report`
--

INSERT INTO `cron_demand_report` (`pk_id`, `filter_type`, `branch_id`, `branch_name`, `principal_closing_loan`, `current_due`, `over_due`, `total_due`) VALUES
(2, 1, 2001, 'Tranqubar', 7198697, 181991, 0, 363981),
(3, 1, 2001, 'Tranqubar', 7198697, 181991, 0, 363981),
(4, 1, 2001, 'Tranqubar', 7198697, 181991, 0, 363981),
(5, 1, 2001, 'Tranqubar', 7198697, 181991, 0, 363981);

-- --------------------------------------------------------

--
-- Table structure for table `cron_head_loan_ledger`
--

CREATE TABLE IF NOT EXISTS `cron_head_loan_ledger` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `iid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `level_name` text NOT NULL,
  `loan_issued` text NOT NULL,
  `opening_loan_ason` text NOT NULL,
  `interest_paid_between` text NOT NULL,
  `overdue_ason_date` text NOT NULL,
  `prepayment_ason_date` text NOT NULL,
  `amount_paid_between` text NOT NULL,
  `closing_loan` text NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `cron_head_loan_ledger`
--

INSERT INTO `cron_head_loan_ledger` (`pk_id`, `iid`, `rid`, `fid`, `level_name`, `loan_issued`, `opening_loan_ason`, `interest_paid_between`, `overdue_ason_date`, `prepayment_ason_date`, `amount_paid_between`, `closing_loan`, `status`, `createdon`) VALUES
(1, 2021, 31154, 4058, 'branch', '24690000', '0', '1876726', '12633', '29511', '15000542', '11565452', 1, '2016-06-16 16:38:09'),
(2, 2021, 31154, 4073, 'fo', '8070000', '0', '886086', '0', '0', '6938586', '2017500', 1, '2016-06-16 16:43:30'),
(3, 2021, 31154, 4058, 'fo', '7320000', '0', '535824', '0', '0', '4195824', '3660000', 1, '2016-06-16 16:48:26'),
(4, 2021, 31154, 4059, 'fo', '4110000', '0', '300852', '0', '0', '2355852', '2055000', 1, '2016-06-16 16:51:12'),
(5, 2021, 31154, 4060, 'fo', '3135000', '0', '229482', '0', '0', '1796982', '1567500', 1, '2016-06-16 16:53:19'),
(6, 2021, 31154, 4093, 'fo', '735000', '0', '8967', '0', '0', '70217', '673750', 1, '2016-06-16 16:53:49'),
(7, 2021, 30760, 4073, 'group', '375000', '0', '41175', '0', '0', '322425', '93750', 1, '2016-06-16 16:54:04'),
(8, 2021, 30850, 4073, 'group', '225000', '0', '16470', '0', '0', '128970', '112500', 1, '2016-06-16 16:54:13'),
(9, 2021, 30575, 4073, 'group', '80000', '0', '9760', '0', '0', '89760', '0', 1, '2016-06-16 16:54:18'),
(10, 2021, 3872, 4073, 'group', '140000', '0', '18788', '0', '0', '158788', '0', 1, '2016-06-16 16:54:22'),
(11, 2021, 3930, 4073, 'group', '140000', '0', '18788', '0', '0', '158788', '0', 1, '2016-06-16 16:54:26'),
(12, 2021, 30455, 4073, 'group', '140000', '0', '17080', '0', '0', '157080', '0', 1, '2016-06-16 16:54:31'),
(13, 2021, 30297, 4073, 'group', '120000', '0', '16104', '0', '0', '136104', '0', 1, '2016-06-16 16:54:35'),
(14, 2021, 30732, 4073, 'group', '50000', '0', '6710', '0', '0', '56710', '0', 1, '2016-06-16 16:54:39'),
(15, 2021, 30699, 4073, 'group', '140000', '0', '17080', '0', '84', '133840', '23240', 1, '2016-06-16 16:54:47'),
(16, 2021, 30365, 4073, 'group', '80000', '0', '10736', '0', '0', '90736', '0', 1, '2016-06-16 16:54:49'),
(17, 2021, 3964, 4073, 'group', '280000', '0', '37576', '0', '0', '317576', '0', 1, '2016-06-16 16:54:57'),
(18, 2021, 30162, 4073, 'group', '140000', '0', '20496', '0', '11641', '158788', '0', 1, '2016-06-16 16:55:02'),
(19, 2021, 3871, 4073, 'group', '80000', '0', '9760', '0', '0', '89760', '0', 1, '2016-06-16 16:55:04'),
(20, 2021, 30730, 4073, 'group', '150000', '0', '18300', '0', '90', '143400', '24900', 1, '2016-06-16 16:55:13'),
(21, 2021, 30780, 4073, 'group', '210000', '0', '23058', '0', '0', '180558', '52500', 1, '2016-06-16 16:55:22'),
(22, 2021, 30762, 4073, 'group', '315000', '0', '34587', '0', '0', '270837', '78750', 1, '2016-06-16 16:55:34'),
(23, 2021, 30761, 4073, 'group', '270000', '0', '29646', '0', '0', '232146', '67500', 1, '2016-06-16 16:55:45'),
(24, 2021, 30781, 4073, 'group', '285000', '0', '31293', '0', '0', '245043', '71250', 1, '2016-06-16 16:55:56'),
(25, 2021, 30312, 4073, 'group', '400000', '0', '43920', '0', '0', '343980', '99940', 1, '2016-06-16 16:56:08'),
(26, 2021, 30779, 4073, 'group', '225000', '0', '24705', '0', '0', '193455', '56250', 1, '2016-06-16 16:56:19'),
(27, 2021, 30886, 4073, 'group', '285000', '0', '20862', '0', '0', '163362', '142500', 1, '2016-06-16 16:56:30'),
(28, 2021, 30163, 4073, 'group', '480000', '0', '52704', '0', '0', '412776', '119928', 1, '2016-06-16 16:56:46'),
(29, 2021, 30808, 4073, 'group', '300000', '0', '25620', '0', '0', '200620', '125000', 1, '2016-06-16 16:56:59'),
(30, 2021, 30806, 4073, 'group', '270000', '0', '26352', '0', '0', '206352', '90000', 1, '2016-06-16 16:57:10'),
(31, 2021, 30810, 4073, 'group', '300000', '0', '25620', '0', '0', '200620', '125000', 1, '2016-06-16 16:57:22'),
(32, 2021, 30943, 4073, 'group', '240000', '0', '17568', '0', '32', '137600', '119968', 1, '2016-06-16 16:57:32'),
(33, 2021, 30994, 4073, 'group', '300000', '0', '14640', '0', '0', '114640', '200000', 1, '2016-06-16 16:57:44'),
(34, 2021, 30993, 4073, 'group', '300000', '0', '14640', '0', '0', '114640', '200000', 1, '2016-06-16 16:57:56'),
(35, 2021, 30960, 4073, 'group', '240000', '0', '11712', '0', '0', '91712', '160000', 1, '2016-06-16 16:58:06'),
(36, 2021, 31071, 4073, 'group', '285000', '0', '10431', '0', '0', '81681', '213750', 1, '2016-06-16 16:58:20'),
(37, 2021, 31088, 4073, 'group', '285000', '0', '10431', '0', '0', '81681', '213750', 1, '2016-06-16 16:58:33'),
(38, 2021, 31089, 4073, 'group', '210000', '0', '7686', '0', '0', '60186', '157500', 1, '2016-06-16 16:58:43'),
(39, 2021, 31107, 4073, 'group', '255000', '0', '6222', '0', '0', '48722', '212500', 1, '2016-06-16 16:58:55'),
(40, 2021, 31176, 4073, 'group', '300000', '0', '3660', '0', '0', '26160', '277500', 1, '2016-06-16 16:59:05'),
(41, 2021, 31182, 4073, 'group', '270000', '0', '3294', '0', '0', '25794', '247500', 1, '2016-06-16 16:59:16'),
(42, 2021, 31177, 4073, 'group', '360000', '0', '4392', '0', '0', '31392', '333000', 1, '2016-06-16 16:59:27'),
(43, 2021, 30891, 4058, 'group', '315000', '0', '23058', '0', '0', '180558', '157500', 1, '2016-06-16 16:59:40'),
(44, 2021, 30811, 4058, 'group', '360000', '0', '30744', '0', '0', '240744', '150000', 1, '2016-06-16 16:59:54'),
(45, 2021, 30567, 4058, 'group', '180000', '0', '24156', '0', '0', '189189', '14967', 1, '2016-06-16 17:00:00'),
(46, 2021, 30852, 4058, 'group', '300000', '0', '21960', '0', '0', '171960', '150000', 1, '2016-06-16 17:00:12'),
(47, 2021, 30851, 4058, 'group', '255000', '0', '18666', '0', '0', '146166', '127500', 1, '2016-06-16 17:00:23'),
(48, 2021, 30759, 4058, 'group', '300000', '0', '32940', '0', '0', '257940', '75000', 1, '2016-06-16 17:00:35'),
(49, 2021, 3718, 4058, 'group', '160000', '0', '17568', '0', '0', '137592', '39976', 1, '2016-06-16 17:00:40'),
(50, 2021, 3680, 4058, 'group', '160000', '0', '21472', '0', '0', '181472', '0', 1, '2016-06-16 17:00:44'),
(51, 2021, 3717, 4058, 'group', '120000', '0', '14640', '0', '0', '134640', '0', 1, '2016-06-16 17:00:48'),
(52, 2021, 3957, 4058, 'group', '80000', '0', '9760', '0', '0', '89760', '0', 1, '2016-06-16 17:00:50'),
(53, 2021, 3906, 4058, 'group', '300000', '0', '36600', '0', '0', '286650', '49950', 1, '2016-06-16 17:01:00'),
(54, 2021, 30574, 4058, 'group', '70000', '0', '8540', '0', '28', '66906', '11634', 1, '2016-06-16 17:01:05'),
(55, 2021, 30159, 4058, 'group', '360000', '0', '48312', '0', '0', '408312', '0', 1, '2016-06-16 17:01:15'),
(56, 2021, 30570, 4058, 'group', '60000', '0', '8052', '0', '0', '63078', '4974', 1, '2016-06-16 17:01:19'),
(57, 2021, 3844, 4058, 'group', '160000', '0', '19520', '0', '0', '179520', '0', 1, '2016-06-16 17:01:25'),
(58, 2021, 30557, 4058, 'group', '100000', '0', '13420', '0', '0', '105550', '7870', 1, '2016-06-16 17:01:28'),
(59, 2021, 3689, 4058, 'group', '220000', '0', '29524', '0', '0', '249524', '0', 1, '2016-06-16 17:01:35'),
(60, 2021, 30733, 4058, 'group', '80000', '0', '10736', '0', '48', '84120', '6616', 1, '2016-06-16 17:01:40'),
(61, 2021, 3866, 4058, 'group', '160000', '0', '19520', '0', '0', '179520', '0', 1, '2016-06-16 17:01:45'),
(62, 2021, 30686, 4058, 'group', '100000', '0', '13420', '0', '0', '105105', '8315', 1, '2016-06-16 17:01:48'),
(63, 2021, 30571, 4058, 'group', '100000', '0', '10980', '9555', '0', '85995', '24985', 1, '2016-06-16 17:01:51'),
(64, 2021, 30743, 4058, 'group', '270000', '0', '29646', '0', '0', '232146', '67500', 1, '2016-06-16 17:02:02'),
(65, 2021, 3743, 4058, 'group', '180000', '0', '19764', '0', '0', '154791', '44973', 1, '2016-06-16 17:02:08'),
(66, 2021, 30558, 4058, 'group', '120000', '0', '16104', '0', '0', '126126', '9978', 1, '2016-06-16 17:02:11'),
(67, 2021, 30747, 4058, 'group', '300000', '0', '32940', '0', '0', '257940', '75000', 1, '2016-06-16 17:02:23'),
(68, 2021, 30745, 4058, 'group', '195000', '0', '21411', '0', '0', '167661', '48750', 1, '2016-06-16 17:02:31'),
(69, 2021, 30744, 4058, 'group', '255000', '0', '27999', '0', '0', '219249', '63750', 1, '2016-06-16 17:02:41'),
(70, 2021, 30199, 4058, 'group', '200000', '0', '24400', '0', '0', '224400', '0', 1, '2016-06-16 17:02:47'),
(71, 2021, 30685, 4058, 'group', '120000', '0', '17568', '0', '9978', '136104', '1464', 1, '2016-06-16 17:02:51'),
(72, 2021, 30549, 4058, 'group', '160000', '0', '17568', '0', '16', '137608', '39960', 1, '2016-06-16 17:02:56'),
(73, 2021, 30813, 4058, 'group', '225000', '0', '19215', '0', '0', '150465', '93750', 1, '2016-06-16 17:03:06'),
(74, 2021, 30995, 4058, 'group', '300000', '0', '14640', '0', '0', '114640', '200000', 1, '2016-06-16 17:03:18'),
(75, 2021, 31068, 4058, 'group', '210000', '0', '7686', '0', '0', '60186', '157500', 1, '2016-06-16 17:03:27'),
(76, 2021, 31115, 4058, 'group', '315000', '0', '7686', '0', '0', '60186', '262500', 1, '2016-06-16 17:03:40'),
(77, 2021, 31116, 4058, 'group', '330000', '0', '8052', '0', '0', '63052', '275000', 1, '2016-06-16 17:03:54'),
(78, 2021, 31155, 4058, 'group', '315000', '0', '3843', '0', '0', '30093', '288750', 1, '2016-06-16 17:04:08'),
(79, 2021, 31156, 4058, 'group', '340000', '0', '4148', '0', '0', '29648', '314500', 1, '2016-06-16 17:04:18'),
(80, 2021, 31154, 4058, 'group', '270000', '0', '3294', '0', '0', '25794', '247500', 1, '2016-06-16 17:04:29'),
(81, 2021, 30888, 4059, 'group', '255000', '0', '18666', '0', '0', '146166', '127500', 1, '2016-06-16 17:04:39'),
(82, 2021, 30849, 4059, 'group', '240000', '0', '17568', '0', '0', '137568', '120000', 1, '2016-06-16 17:04:49'),
(83, 2021, 30853, 4059, 'group', '270000', '0', '19764', '0', '0', '154764', '135000', 1, '2016-06-16 17:04:59'),
(84, 2021, 30748, 4059, 'group', '255000', '0', '27999', '0', '0', '219249', '63750', 1, '2016-06-16 17:05:10'),
(85, 2021, 30814, 4059, 'group', '210000', '0', '17934', '0', '0', '140434', '87500', 1, '2016-06-16 17:05:18'),
(86, 2021, 30363, 4059, 'group', '140000', '0', '18788', '0', '0', '147147', '11641', 1, '2016-06-16 17:05:22'),
(87, 2021, 30731, 4059, 'group', '60000', '0', '8784', '0', '1362', '64416', '4368', 1, '2016-06-16 17:05:26'),
(88, 2021, 3816, 4059, 'group', '140000', '0', '17080', '0', '0', '133770', '23310', 1, '2016-06-16 17:05:30'),
(89, 2021, 30890, 4059, 'group', '225000', '0', '16470', '0', '0', '128970', '112500', 1, '2016-06-16 17:05:39'),
(90, 2021, 3698, 4059, 'group', '120000', '0', '16104', '0', '0', '126126', '9978', 1, '2016-06-16 17:05:42'),
(91, 2021, 30746, 4059, 'group', '225000', '0', '24705', '0', '0', '193455', '56250', 1, '2016-06-16 17:05:51'),
(92, 2021, 30812, 4059, 'group', '255000', '0', '24888', '0', '0', '194888', '85000', 1, '2016-06-16 17:06:01'),
(93, 2021, 30815, 4059, 'group', '240000', '0', '23424', '0', '0', '183424', '80000', 1, '2016-06-16 17:06:12'),
(94, 2021, 31069, 4059, 'group', '240000', '0', '8784', '0', '0', '68784', '180000', 1, '2016-06-16 17:06:21'),
(95, 2021, 31067, 4059, 'group', '300000', '0', '10980', '0', '0', '85980', '225000', 1, '2016-06-16 17:06:33'),
(96, 2021, 31117, 4059, 'group', '225000', '0', '5490', '0', '0', '42990', '187500', 1, '2016-06-16 17:06:41'),
(97, 2021, 31179, 4059, 'group', '285000', '0', '3477', '0', '0', '27227', '261250', 1, '2016-06-16 17:06:52'),
(98, 2021, 31184, 4059, 'group', '300000', '0', '3660', '0', '0', '26160', '277500', 1, '2016-06-16 17:07:01'),
(99, 2021, 31181, 4059, 'group', '270000', '0', '3294', '0', '0', '25794', '247500', 1, '2016-06-16 17:07:13'),
(100, 2021, 30854, 4060, 'group', '300000', '0', '21960', '0', '0', '171960', '150000', 1, '2016-06-16 17:07:25'),
(101, 2021, 30884, 4060, 'group', '300000', '0', '21960', '0', '0', '171960', '150000', 1, '2016-06-16 17:07:37'),
(102, 2021, 30883, 4060, 'group', '300000', '0', '21960', '0', '0', '171960', '150000', 1, '2016-06-16 17:07:49'),
(103, 2021, 30809, 4060, 'group', '285000', '0', '27816', '0', '19', '217835', '94981', 1, '2016-06-16 17:08:00'),
(104, 2021, 30818, 4060, 'group', '330000', '0', '28182', '0', '0', '220682', '137500', 1, '2016-06-16 17:08:14'),
(105, 2021, 30959, 4060, 'group', '300000', '0', '14640', '0', '0', '114640', '200000', 1, '2016-06-16 17:08:26'),
(106, 2021, 30958, 4060, 'group', '285000', '0', '13908', '0', '0', '108908', '190000', 1, '2016-06-16 17:08:37'),
(107, 2021, 31106, 4060, 'group', '225000', '0', '5490', '0', '0', '42990', '187500', 1, '2016-06-16 17:08:46'),
(108, 2021, 31104, 4060, 'group', '285000', '0', '6954', '0', '0', '54454', '237500', 1, '2016-06-16 17:08:59'),
(109, 2021, 31157, 4060, 'group', '240000', '0', '2928', '0', '0', '22928', '220000', 1, '2016-06-16 17:09:10'),
(110, 2021, 31158, 4060, 'group', '285000', '0', '3477', '0', '0', '27227', '261250', 1, '2016-06-16 17:09:21'),
(111, 2021, 31180, 4093, 'group', '240000', '0', '2928', '0', '0', '22928', '220000', 1, '2016-06-16 17:09:30'),
(112, 2021, 31178, 4093, 'group', '285000', '0', '3477', '0', '0', '27227', '261250', 1, '2016-06-16 17:09:42'),
(113, 2021, 31183, 4093, 'group', '210000', '0', '2562', '0', '0', '20062', '192500', 1, '2016-06-16 17:09:52'),
(114, 2001, 31110, 4002, 'branch', '15615000', '0', '1185901', '57198', '79930', '9198270', '7598971', 1, '2016-06-16 17:19:24'),
(115, 2001, 31110, 4003, 'fo', '4680000', '0', '342576', '0', '0', '2682576', '2340000', 1, '2016-06-16 17:22:38'),
(116, 2001, 31110, 4004, 'fo', '3255000', '0', '238266', '0', '217', '1865983', '1627283', 1, '2016-06-16 17:24:50'),
(117, 2001, 31110, 4002, 'fo', '5415000', '0', '396378', '0', '0', '3103878', '2707500', 1, '2016-06-16 17:28:32'),
(118, 2001, 31110, 4001, 'fo', '555000', '0', '74481', '37', '0', '583194', '46287', 1, '2016-06-16 17:28:54'),
(119, 2001, 30869, 4003, 'group', '315000', '0', '23058', '0', '0', '180558', '157500', 1, '2016-06-16 17:29:07'),
(120, 2001, 30863, 4003, 'group', '300000', '0', '21960', '0', '0', '171960', '150000', 1, '2016-06-16 17:29:20'),
(121, 2001, 30870, 4003, 'group', '255000', '0', '18666', '0', '0', '146166', '127500', 1, '2016-06-16 17:29:32'),
(122, 2001, 30872, 4003, 'group', '520000', '0', '38064', '0', '0', '298116', '259948', 1, '2016-06-16 17:29:48'),
(123, 2001, 30108, 4003, 'group', '260000', '0', '34892', '0', '4082', '277355', '17537', 1, '2016-06-16 17:29:56'),
(124, 2001, 3178, 4003, 'group', '160000', '0', '21472', '464', '0', '167704', '13768', 1, '2016-06-16 17:30:01'),
(125, 2001, 3179, 4003, 'group', '20000', '0', '2684', '83', '0', '20938', '1746', 1, '2016-06-16 17:30:02'),
(126, 2001, 3936, 4003, 'group', '100000', '0', '13420', '2145', '0', '102960', '10460', 1, '2016-06-16 17:30:06'),
(127, 2001, 3800, 4003, 'group', '100000', '0', '14640', '0', '8720', '113825', '815', 1, '2016-06-16 17:30:09'),
(128, 2001, 30751, 4003, 'group', '315000', '0', '34587', '0', '0', '270837', '78750', 1, '2016-06-16 17:30:22'),
(129, 2001, 30873, 4003, 'group', '225000', '0', '24705', '0', '21495', '193455', '56250', 1, '2016-06-16 17:30:30'),
(130, 2001, 30752, 4003, 'group', '300000', '0', '32940', '0', '0', '257940', '75000', 1, '2016-06-16 17:30:42'),
(131, 2001, 30867, 4003, 'group', '255000', '0', '21777', '0', '0', '170527', '106250', 1, '2016-06-16 17:30:52'),
(132, 2001, 30063, 4003, 'group', '140000', '0', '13664', '7', '0', '107009', '46655', 1, '2016-06-16 17:30:56'),
(133, 2001, 31055, 4003, 'group', '420000', '0', '15372', '0', '0', '109872', '325500', 1, '2016-06-16 17:31:09');

-- --------------------------------------------------------

--
-- Table structure for table `cron_loan_product_superadmin`
--

CREATE TABLE IF NOT EXISTS `cron_loan_product_superadmin` (
  `branch_wise_loan_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(250) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(250) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `with_without_staff_filter` int(11) NOT NULL,
  `loan_issued` varchar(1000) NOT NULL,
  `principal_opeing_loan_outstanding` varchar(1000) NOT NULL,
  `interest` varchar(1000) NOT NULL,
  `overdue` varchar(1000) NOT NULL,
  `prepayment` varchar(1000) NOT NULL,
  `amount_paid_during_this_period` varchar(1000) NOT NULL,
  `closing_loan_outstanding` varchar(1000) NOT NULL,
  `from_date_filter` int(11) NOT NULL,
  `to_date_filter` int(11) NOT NULL,
  `created_time` int(11) NOT NULL,
  `modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`branch_wise_loan_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `cron_loan_product_superadmin`
--

INSERT INTO `cron_loan_product_superadmin` (`branch_wise_loan_product_id`, `mfi_id`, `mfi_name`, `branch_id`, `branch_name`, `product_id`, `product_name`, `with_without_staff_filter`, `loan_issued`, `principal_opeing_loan_outstanding`, `interest`, `overdue`, `prepayment`, `amount_paid_during_this_period`, `closing_loan_outstanding`, `from_date_filter`, `to_date_filter`, `created_time`, `modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 0, 'All Product', 0, '2235000', '10580781', '537959', '86504', '133138', '4164084', '9189656', 1459449000, 1466188200, 1466206275, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 1, 'Agriculture', 0, '60000', '1248088', '114131', '61493', '1434', '915050', '507169', 1459449000, 1466188200, 1466206281, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 2, 'Small Business', 0, '1050000', '2832646', '134871', '13543', '43242', '1031795', '2985722', 1459449000, 1466188200, 1466206288, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 3, 'Milch Animal', 0, '1080000', '5185560', '239486', '11468', '75437', '1840181', '4664865', 1459449000, 1466188200, 1466206300, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 4, 'Self Employment', 0, '30000', '1303237', '48922', '0', '13025', '372759', '1009400', 1459449000, 1466188200, 1466206302, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1466188200, 1466206302, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 6, 'Fishing and Connected Business', 0, '0', '11250', '366', '0', '0', '2866', '8750', 1459449000, 1466188200, 1466206302, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 2001, 'Tranqubar', 7, 'Educational', 0, '15000', '0', '183', '0', '0', '1433', '13750', 1459449000, 1466188200, 1466206303, 0, 1),
(9, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 0, 'All Product', 0, '3445000', '13484706', '642452', '374513', '28665', '4984260', '12587898', 1459449000, 1466188200, 1466206386, 0, 1),
(10, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 1, 'Agriculture', 0, '0', '96541', '13176', '0', '0', '103057', '6660', 1459449000, 1466188200, 1466206387, 0, 1),
(11, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 2, 'Small Business', 0, '800000', '1682479', '69357', '59233', '0', '531784', '2020052', 1459449000, 1466188200, 1466206392, 0, 1),
(12, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 3, 'Milch Animal', 0, '2195000', '9092562', '447252', '245536', '28665', '3471716', '8263098', 1459449000, 1466188200, 1466206413, 0, 1),
(13, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 4, 'Self Employment', 0, '0', '532633', '27633', '15288', '0', '216948', '343318', 1459449000, 1466188200, 1466206415, 0, 1),
(14, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1466188200, 1466206415, 0, 1),
(15, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 6, 'Fishing and Connected Business', 0, '450000', '2072178', '83814', '54456', '0', '651222', '1954770', 1459449000, 1466188200, 1466206420, 0, 1),
(16, 1001, 'Valar Aditi Social Finance Private Ltd', 2007, 'Avudayarkovil', 7, 'Educational', 0, '0', '8313', '1220', '0', '0', '9533', '0', 1459449000, 1466188200, 1466206420, 0, 1),
(17, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 0, 'All Product', 0, '4305000', '14388690', '772626', '32424', '903491', '6015663', '13450653', 1459449000, 1466188200, 1466206520, 0, 1),
(18, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 1, 'Agriculture', 0, '0', '329381', '32391', '0', '1911', '266814', '94958', 1459449000, 1466188200, 1466206522, 0, 1),
(19, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 2, 'Small Business', 0, '625000', '2588508', '147437', '22904', '154611', '1151221', '2209724', 1459449000, 1466188200, 1466206529, 0, 1),
(20, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 3, 'Milch Animal', 0, '3415000', '10041944', '526613', '9520', '676816', '4083869', '9899688', 1459449000, 1466188200, 1466206556, 0, 1),
(21, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 4, 'Self Employment', 0, '250000', '1416357', '65819', '0', '70153', '510893', '1221283', 1459449000, 1466188200, 1466206559, 0, 1),
(22, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 5, 'Housing', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1466188200, 1466206559, 0, 1),
(23, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 6, 'Fishing and Connected Business', 0, '15000', '12500', '366', '0', '0', '2866', '25000', 1459449000, 1466188200, 1466206559, 0, 1),
(24, 1001, 'Valar Aditi Social Finance Private Ltd', 2008, 'Sirkazhi', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1466188200, 1466206560, 0, 1),
(25, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 0, 'All Product', 0, '435000', '15200208', '733830', '58625', '197334', '6007510', '10361528', 1459449000, 1466188200, 1466206662, 0, 1),
(26, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 1, 'Agriculture', 0, '0', '213547', '19520', '0', '1433', '160567', '72500', 1459449000, 1466188200, 1466206663, 0, 1),
(27, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 2, 'Small Business', 0, '165000', '5704705', '303109', '20313', '99750', '2490620', '3682194', 1459449000, 1466188200, 1466206678, 0, 1),
(28, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 3, 'Milch Animal', 0, '135000', '4815558', '213988', '16733', '46182', '1748728', '3415818', 1459449000, 1466188200, 1466206689, 0, 1),
(29, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 4, 'Self Employment', 0, '90000', '3752994', '174643', '17280', '37883', '1416438', '2601199', 1459449000, 1466188200, 1466206698, 0, 1),
(30, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 5, 'Housing', 0, '30000', '460904', '16043', '2866', '10653', '132881', '374066', 1459449000, 1466188200, 1466206699, 0, 1),
(31, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 6, 'Fishing and Connected Business', 0, '15000', '252500', '6527', '1433', '1433', '58276', '215751', 1459449000, 1466188200, 1466206700, 0, 1),
(32, 1001, 'Valar Aditi Social Finance Private Ltd', 2021, 'Karaikal ', 7, 'Educational', 0, '0', '0', '0', '0', '0', '0', '0', 1459449000, 1466188200, 1466206700, 0, 1),
(33, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 0, 'All Product', 0, '1380000', '16887158', '868945', '0', '189445', '6831025', '12305078', 1459449000, 1466188200, 1466206801, 0, 1),
(34, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 1, 'Agriculture', 0, '225000', '658246', '55327', '0', '1746', '449061', '489512', 1459449000, 1466188200, 1466206805, 0, 1),
(35, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 2, 'Small Business', 0, '540000', '7014748', '370331', '0', '84224', '2903852', '5021227', 1459449000, 1466188200, 1466206821, 0, 1),
(36, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 3, 'Milch Animal', 0, '270000', '3053449', '138104', '0', '29904', '1086107', '2375446', 1459449000, 1466188200, 1466206828, 0, 1),
(37, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 4, 'Self Employment', 0, '345000', '5897817', '291275', '0', '73571', '2283091', '4251001', 1459449000, 1466188200, 1466206841, 0, 1),
(38, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 5, 'Housing', 0, '0', '96656', '7320', '0', '0', '57324', '46652', 1459449000, 1466188200, 1466206841, 0, 1),
(39, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 6, 'Fishing and Connected Business', 0, '0', '153328', '5551', '0', '0', '43469', '115410', 1459449000, 1466188200, 1466206842, 0, 1),
(40, 1001, 'Valar Aditi Social Finance Private Ltd', 2022, 'Vallioor', 7, 'Educational', 0, '0', '12914', '1037', '0', '0', '8121', '5830', 1459449000, 1466188200, 1466206842, 0, 1),
(41, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 0, 'All Product', 0, '1395000', '16437065', '807030', '256981', '193242', '6282334', '12356761', 1459449000, 1466188200, 1466206944, 0, 1),
(42, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 1, 'Agriculture', 0, '0', '1195531', '136640', '0', '160', '1069436', '262735', 1459449000, 1466188200, 1466206951, 0, 1),
(43, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 2, 'Small Business', 0, '500000', '6686719', '311893', '123712', '87605', '2416738', '5081874', 1459449000, 1466188200, 1466206966, 0, 1),
(44, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 3, 'Milch Animal', 0, '850000', '5221252', '220393', '87413', '56632', '1719109', '4572536', 1459449000, 1466188200, 1466206978, 0, 1),
(45, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 4, 'Self Employment', 0, '0', '2123441', '97722', '44423', '45668', '761803', '1459360', 1459449000, 1466188200, 1466206983, 0, 1),
(46, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 5, 'Housing', 0, '30000', '935000', '23180', '0', '0', '181538', '806642', 1459449000, 1466188200, 1466206984, 0, 1),
(47, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 6, 'Fishing and Connected Business', 0, '15000', '265959', '16409', '1433', '3177', '127504', '169864', 1459449000, 1466188200, 1466206985, 0, 1),
(48, 1001, 'Valar Aditi Social Finance Private Ltd', 2024, 'Aranthanki', 7, 'Educational', 0, '0', '9163', '793', '0', '0', '6206', '3750', 1459449000, 1466188200, 1466206985, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_on_time_repayment`
--

CREATE TABLE IF NOT EXISTS `cron_on_time_repayment` (
  `on_time_repay_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(250) NOT NULL,
  `cur_first_quarter` double NOT NULL,
  `cur_secound_quarter` double NOT NULL,
  `cur_third_quarter` double NOT NULL,
  `cur_fourth_quarter` double NOT NULL,
  `cur_total` double NOT NULL,
  `pre_first_quarter` double NOT NULL,
  `pre_secound_quarter` double NOT NULL,
  `pre_third_quarter` double NOT NULL,
  `pre_fourth_quarter` double NOT NULL,
  `pre_total` double NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`on_time_repay_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cron_on_time_repayment`
--

INSERT INTO `cron_on_time_repayment` (`on_time_repay_id`, `mfi_id`, `mfi_name`, `cur_first_quarter`, `cur_secound_quarter`, `cur_third_quarter`, `cur_fourth_quarter`, `cur_total`, `pre_first_quarter`, `pre_secound_quarter`, `pre_third_quarter`, `pre_fourth_quarter`, `pre_total`, `from_filter_date`, `to_filter_date`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 13.81, 0, 0, 0, 6.905, 66.53, 70.38, 78.91, 80.93, 74.1875, 1459449000, 1466015400, 1466062292, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_portfolio_at_risk`
--

CREATE TABLE IF NOT EXISTS `cron_portfolio_at_risk` (
  `portfolio_at_risk_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(500) NOT NULL,
  `cur_year_current_amount` double NOT NULL,
  `cur_year_current_percentage` double NOT NULL,
  `cur_year_1_to_30_amount` double NOT NULL,
  `cur_year_1_to_30_percentage` double NOT NULL,
  `cur_year_31_to_60_amount` double NOT NULL,
  `cur_year_31_to_60_percentage` double NOT NULL,
  `cur_year_61_to_90_amount` double NOT NULL,
  `cur_year_61_to_90_percentage` double NOT NULL,
  `cur_year_91_to_120_amount` double NOT NULL,
  `cur_year_91_to_120_percentage` double NOT NULL,
  `cur_year_more_120_amount` double NOT NULL,
  `cur_year_more_120_percentage` double NOT NULL,
  `pre_year_current_amount` double NOT NULL,
  `pre_year_current_percentage` double NOT NULL,
  `pre_year_1_to_30_amount` double NOT NULL,
  `pre_year_1_to_30_percentage` double NOT NULL,
  `pre_year_31_to_60_amount` double NOT NULL,
  `pre_year_31_to_60_percentage` double NOT NULL,
  `pre_year_61_to_90_amount` double NOT NULL,
  `pre_year_61_to_90_percentage` double NOT NULL,
  `pre_year_91_to_120_amount` double NOT NULL,
  `pre_year_91_to_120_percentage` double NOT NULL,
  `pre_year_more_120_amount` double NOT NULL,
  `pre_year_more_120_percentage` double NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`portfolio_at_risk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cron_portfolio_at_risk`
--


-- --------------------------------------------------------

--
-- Table structure for table `cron_product_wish_loan_dibursement_report`
--

CREATE TABLE IF NOT EXISTS `cron_product_wish_loan_dibursement_report` (
  `loan_disburse_product_wise_id` int(11) NOT NULL AUTO_INCREMENT,
  `mfi_id` int(11) NOT NULL,
  `mfi_name` varchar(500) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `current_year_no_of_loan` double NOT NULL,
  `previous_year_no_of_loan` double NOT NULL,
  `current_year_amount` double NOT NULL,
  `previous_year_amount` double NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`loan_disburse_product_wise_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=105 ;

--
-- Dumping data for table `cron_product_wish_loan_dibursement_report`
--

INSERT INTO `cron_product_wish_loan_dibursement_report` (`loan_disburse_product_wise_id`, `mfi_id`, `mfi_name`, `product_id`, `product_name`, `current_year_no_of_loan`, `previous_year_no_of_loan`, `current_year_amount`, `previous_year_amount`, `from_filter_date`, `to_filter_date`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1001, 'Valar Aditi Social Finance Private Ltd', 1, 'Agriculture', 0, 823, 0, 13275000, 1459449000, 1465929000, 1465964239, 0, 1),
(2, 1001, 'Valar Aditi Social Finance Private Ltd', 2, 'Small Business', 0, 2417, 0, 40485000, 1459449000, 1465929000, 1465964239, 0, 1),
(3, 1001, 'Valar Aditi Social Finance Private Ltd', 3, 'Milch Animal', 0, 3007, 0, 50595000, 1459449000, 1465929000, 1465964239, 0, 1),
(4, 1001, 'Valar Aditi Social Finance Private Ltd', 4, 'Self Employment', 0, 1305, 0, 21795000, 1459449000, 1465929000, 1465964239, 0, 1),
(5, 1001, 'Valar Aditi Social Finance Private Ltd', 5, 'Housing', 0, 40, 0, 660000, 1459449000, 1465929000, 1465964239, 0, 1),
(6, 1001, 'Valar Aditi Social Finance Private Ltd', 6, 'Fishing and Connected Business', 0, 192, 0, 3210000, 1459449000, 1465929000, 1465964239, 0, 1),
(7, 1001, 'Valar Aditi Social Finance Private Ltd', 7, 'Educational', 0, 12, 0, 230000, 1459449000, 1465929000, 1465964239, 0, 1),
(8, 1001, 'Valar Aditi Social Finance Private Ltd', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(9, 2001, 'Tranqubar', 1, 'Agriculture', 0, 269, 0, 4300000, 1459449000, 1465929000, 1465964239, 0, 1),
(10, 2001, 'Tranqubar', 2, 'Small Business', 0, 210, 0, 3670000, 1459449000, 1465929000, 1465964239, 0, 1),
(11, 2001, 'Tranqubar', 3, 'Milch Animal', 0, 381, 0, 6490000, 1459449000, 1465929000, 1465964239, 0, 1),
(12, 2001, 'Tranqubar', 4, 'Self Employment', 0, 66, 0, 1140000, 1459449000, 1465929000, 1465964239, 0, 1),
(13, 2001, 'Tranqubar', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(14, 2001, 'Tranqubar', 6, 'Fishing and Connected Business', 0, 1, 0, 15000, 1459449000, 1465929000, 1465964239, 0, 1),
(15, 2001, 'Tranqubar', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(16, 2001, 'Tranqubar', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(17, 2002, 'Chidambaram', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(18, 2002, 'Chidambaram', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(19, 2002, 'Chidambaram', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(20, 2002, 'Chidambaram', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(21, 2002, 'Chidambaram', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(22, 2002, 'Chidambaram', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(23, 2002, 'Chidambaram', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(24, 2002, 'Chidambaram', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(25, 2003, 'Nagarkovil', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(26, 2003, 'Nagarkovil', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(27, 2003, 'Nagarkovil', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(28, 2003, 'Nagarkovil', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(29, 2003, 'Nagarkovil', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(30, 2003, 'Nagarkovil', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(31, 2003, 'Nagarkovil', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(32, 2003, 'Nagarkovil', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(33, 2004, 'Ponnamaravathi', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(34, 2004, 'Ponnamaravathi', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(35, 2004, 'Ponnamaravathi', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(36, 2004, 'Ponnamaravathi', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(37, 2004, 'Ponnamaravathi', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(38, 2004, 'Ponnamaravathi', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(39, 2004, 'Ponnamaravathi', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(40, 2004, 'Ponnamaravathi', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(41, 2005, 'Mayiladuturai', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(42, 2005, 'Mayiladuturai', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(43, 2005, 'Mayiladuturai', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(44, 2005, 'Mayiladuturai', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(45, 2005, 'Mayiladuturai', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(46, 2005, 'Mayiladuturai', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(47, 2005, 'Mayiladuturai', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(48, 2005, 'Mayiladuturai', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(49, 2006, 'Thisyanvelai', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(50, 2006, 'Thisyanvelai', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(51, 2006, 'Thisyanvelai', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(52, 2006, 'Thisyanvelai', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(53, 2006, 'Thisyanvelai', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(54, 2006, 'Thisyanvelai', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(55, 2006, 'Thisyanvelai', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(56, 2006, 'Thisyanvelai', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(57, 2007, 'Avudayarkovil', 1, 'Agriculture', 0, 35, 0, 700000, 1459449000, 1465929000, 1465964239, 0, 1),
(58, 2007, 'Avudayarkovil', 2, 'Small Business', 0, 100, 0, 1805000, 1459449000, 1465929000, 1465964239, 0, 1),
(59, 2007, 'Avudayarkovil', 3, 'Milch Animal', 0, 657, 0, 12365000, 1459449000, 1465929000, 1465964239, 0, 1),
(60, 2007, 'Avudayarkovil', 4, 'Self Employment', 0, 62, 0, 1165000, 1459449000, 1465929000, 1465964239, 0, 1),
(61, 2007, 'Avudayarkovil', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(62, 2007, 'Avudayarkovil', 6, 'Fishing and Connected Business', 0, 156, 0, 2575000, 1459449000, 1465929000, 1465964239, 0, 1),
(63, 2007, 'Avudayarkovil', 7, 'Educational', 0, 5, 0, 100000, 1459449000, 1465929000, 1465964239, 0, 1),
(64, 2007, 'Avudayarkovil', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(65, 2008, 'Sirkazhi', 1, 'Agriculture', 0, 71, 0, 1050000, 1459449000, 1465929000, 1465964239, 0, 1),
(66, 2008, 'Sirkazhi', 2, 'Small Business', 0, 285, 0, 4730000, 1459449000, 1465929000, 1465964239, 0, 1),
(67, 2008, 'Sirkazhi', 3, 'Milch Animal', 0, 899, 0, 14455000, 1459449000, 1465929000, 1465964239, 0, 1),
(68, 2008, 'Sirkazhi', 4, 'Self Employment', 0, 94, 0, 1510000, 1459449000, 1465929000, 1465964239, 0, 1),
(69, 2008, 'Sirkazhi', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(70, 2008, 'Sirkazhi', 6, 'Fishing and Connected Business', 0, 1, 0, 15000, 1459449000, 1465929000, 1465964239, 0, 1),
(71, 2008, 'Sirkazhi', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(72, 2008, 'Sirkazhi', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(73, 2021, 'Karaikal ', 1, 'Agriculture', 0, 53, 0, 805000, 1459449000, 1465929000, 1465964239, 0, 1),
(74, 2021, 'Karaikal ', 2, 'Small Business', 0, 657, 0, 10520000, 1459449000, 1465929000, 1465964239, 0, 1),
(75, 2021, 'Karaikal ', 3, 'Milch Animal', 0, 433, 0, 6680000, 1459449000, 1465929000, 1465964239, 0, 1),
(76, 2021, 'Karaikal ', 4, 'Self Employment', 0, 388, 0, 6245000, 1459449000, 1465929000, 1465964239, 0, 1),
(77, 2021, 'Karaikal ', 5, 'Housing', 0, 21, 0, 340000, 1459449000, 1465929000, 1465964239, 0, 1),
(78, 2021, 'Karaikal ', 6, 'Fishing and Connected Business', 0, 4, 0, 60000, 1459449000, 1465929000, 1465964239, 0, 1),
(79, 2021, 'Karaikal ', 7, 'Educational', 0, 2, 0, 40000, 1459449000, 1465929000, 1465964239, 0, 1),
(80, 2021, 'Karaikal ', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(81, 2022, 'Vallioor', 1, 'Agriculture', 0, 104, 0, 1735000, 1459449000, 1465929000, 1465964239, 0, 1),
(82, 2022, 'Vallioor', 2, 'Small Business', 0, 623, 0, 10725000, 1459449000, 1465929000, 1465964239, 0, 1),
(83, 2022, 'Vallioor', 3, 'Milch Animal', 0, 249, 0, 4160000, 1459449000, 1465929000, 1465964239, 0, 1),
(84, 2022, 'Vallioor', 4, 'Self Employment', 0, 485, 0, 8295000, 1459449000, 1465929000, 1465964239, 0, 1),
(85, 2022, 'Vallioor', 5, 'Housing', 0, 16, 0, 260000, 1459449000, 1465929000, 1465964239, 0, 1),
(86, 2022, 'Vallioor', 6, 'Fishing and Connected Business', 0, 8, 0, 130000, 1459449000, 1465929000, 1465964239, 0, 1),
(87, 2022, 'Vallioor', 7, 'Educational', 0, 2, 0, 35000, 1459449000, 1465929000, 1465964239, 0, 1),
(88, 2022, 'Vallioor', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(89, 2023, 'Periyakulam', 1, 'Agriculture', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(90, 2023, 'Periyakulam', 2, 'Small Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(91, 2023, 'Periyakulam', 3, 'Milch Animal', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(92, 2023, 'Periyakulam', 4, 'Self Employment', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(93, 2023, 'Periyakulam', 5, 'Housing', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(94, 2023, 'Periyakulam', 6, 'Fishing and Connected Business', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(95, 2023, 'Periyakulam', 7, 'Educational', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(96, 2023, 'Periyakulam', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1),
(97, 2024, 'Aranthanki', 1, 'Agriculture', 0, 291, 0, 4685000, 1459449000, 1465929000, 1465964239, 0, 1),
(98, 2024, 'Aranthanki', 2, 'Small Business', 0, 542, 0, 9035000, 1459449000, 1465929000, 1465964239, 0, 1),
(99, 2024, 'Aranthanki', 3, 'Milch Animal', 0, 388, 0, 6445000, 1459449000, 1465929000, 1465964239, 0, 1),
(100, 2024, 'Aranthanki', 4, 'Self Employment', 0, 210, 0, 3440000, 1459449000, 1465929000, 1465964239, 0, 1),
(101, 2024, 'Aranthanki', 5, 'Housing', 0, 3, 0, 60000, 1459449000, 1465929000, 1465964239, 0, 1),
(102, 2024, 'Aranthanki', 6, 'Fishing and Connected Business', 0, 22, 0, 415000, 1459449000, 1465929000, 1465964239, 0, 1),
(103, 2024, 'Aranthanki', 7, 'Educational', 0, 3, 0, 55000, 1459449000, 1465929000, 1465964239, 0, 1),
(104, 2024, 'Aranthanki', 8, 'Testing Product', 0, 0, 0, 0, 1459449000, 1465929000, 1465964239, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cron_total_loan_details`
--

CREATE TABLE IF NOT EXISTS `cron_total_loan_details` (
  `total_loan_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_level` int(11) NOT NULL,
  `account_level_id` int(11) NOT NULL,
  `account_level_name` varchar(300) NOT NULL,
  `loan_disbursement_amount` double NOT NULL,
  `loan_repayment_amount` double NOT NULL,
  `loan_interest_amount` double NOT NULL,
  `loan_outstanding_amount` double NOT NULL,
  `from_filter_date` int(11) NOT NULL,
  `to_filter_date` int(11) NOT NULL,
  `cron_created_time` int(11) NOT NULL,
  `cron_modified_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`total_loan_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cron_total_loan_details`
--

INSERT INTO `cron_total_loan_details` (`total_loan_details_id`, `account_level`, `account_level_id`, `account_level_name`, `loan_disbursement_amount`, `loan_repayment_amount`, `loan_interest_amount`, `loan_outstanding_amount`, `from_filter_date`, `to_filter_date`, `cron_created_time`, `cron_modified_time`, `status`) VALUES
(1, 1, 1001, 'Valar Aditi Social Finance Private Ltd', 0, 6156826, 766770, 61346986, 1459449000, 1465929000, 1465964179, 0, 1),
(2, 2, 2001, 'Tranqubar', 0, 462311, 62037, 7202357, 1459449000, 1465929000, 1465964179, 0, 1),
(3, 2, 2002, 'Chidambaram', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(4, 2, 2003, 'Nagarkovil', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(5, 2, 2004, 'Ponnamaravathi', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(6, 2, 2005, 'Mayiladuturai', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(7, 2, 2006, 'Thisyanvelai', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(8, 2, 2007, 'Avudayarkovil', 0, 934230, 120719, 8871195, 1459449000, 1465929000, 1465964179, 0, 1),
(9, 2, 2008, 'Sirkazhi', 0, 1734085, 220576, 10545669, 1459449000, 1465929000, 1465964179, 0, 1),
(10, 2, 2021, 'Karaikal ', 0, 1056104, 122061, 10632141, 1459449000, 1465929000, 1465964179, 0, 1),
(11, 2, 2022, 'Vallioor', 0, 1068045, 127307, 12781420, 1459449000, 1465929000, 1465964179, 0, 1),
(12, 2, 2023, 'Periyakulam', 0, 0, 0, 0, 1459449000, 1465929000, 1465964179, 0, 1),
(13, 2, 2024, 'Aranthanki', 0, 902051, 114070, 11314204, 1459449000, 1465929000, 1465964179, 0, 1);
