@extends('layouts.dashboard')
@section('page_heading','Dashboard')
@section('section')

            <!-- /.row -->
            <div class="col-sm-12">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?=$count = DB::table('invoice_item')->where(['status'=>1])->count();?></div>
                                    <div>Total Invoice</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?=number_format($total = DB::table('invoice_item')->sum('product_round_total'),2);?></div>
                                    <div>Total Amount</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-shopping-cart fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?=$count_customer = DB::table('customer')->where(['status'=>1])->count();?></div>
                                    <div>Customers</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?=$count_product = DB::table('product_item')->where(['status'=>1])->count();?></div>
                                    <div>Product</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-md-6">
                    <div class="view-info">
                        <div class="view-info-content" style="min-height: 300px;">
                            <h3 class="lead">Product Wise Sales invoice Details</h3>
                              <div id="container" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="view-info">
                        <div class="view-info-content" style="min-height: 300px;">
                            <h3 class="lead">Current Asset</h3>
                              <div id="current_asset" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
                        </div>
                    </div>
                </div>
            </div><!-- /.row -->
            <!----div class="row">

                <div class="col-sm-6">

                @section ('cchart2_panel_title','Pie Chart')
                @section ('cchart2_panel_body')
                <div style="max-width:400px; margin:0 auto;">@include('widgets.charts.cpiechart')</div>
                @endsection
                @include('widgets.panel', array('header'=>true, 'as'=>'cchart2'))

                </div>

		<div class="col-sm-6">
                @section ('cchart1_panel_title','Line Chart')
                @section ('cchart1_panel_body')
                @include('widgets.charts.clinechart')
                @endsection
                @include('widgets.panel', array('header'=>true, 'as'=>'cchart1'))
                </div>
            </div--->

            <div class="row">
                <div class="col-lg-12">
<div class="view-info">
    <div class="view-info-content" style="min-height: 300px;">
            <h3 class="lead">Customer wise Invoice List</h3>
                @section ('pane2_panel_body')

                    <!-- /.panel -->
                    <table class="table table-bordered">
                    <thead>
                    <tr style="background-color: #3a8df7;    color: #fff;    text-align: center;border-top: 1px solid #ddd;line-height: 1.42857;    padding: 8px;    vertical-align: top;border-collapse: separate;    border: solid #ddd 1px;    border-radius: 16px;    border-left: 0px;    border-top: 0px;">
                    <th>Name</th>
                    <th>Product Name</th>
                    <th>Inovice Date</th>
                    <th>Amount</th>
                    <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                          $grand_total=0;
                          $query=DB::table('invoice_item')->where(['status'=>1])->get();                          //print_r($query);
                          foreach ($query as $query_val)
                          {
                              $customer_id=$query_val->customer_id;
                              $customer_name=DB::table('customer')->where(['customer_id'=>$customer_id,'status'=>1])->get(); //print_r($customer_name);
                              foreach ($customer_name as $cust)
                              {
                                  $client_contact_person_name=$cust->client_contact_person_name;
                                  $client_contact_person_email_ids=$cust->client_contact_person_email_ids;
                                  $client_contact_person_mobile_number=$cust->client_contact_person_mobile_number;
                              }

                             $invoice_type_id=$query_val->invoice_type_id;                            
                             $invoice_type = DB::table('invoice_type')->select('invoice_type_name')->where(['invoice_type_id'=>$invoice_type_id,'status'=>1])->get();
                             $invoice_type=$invoice_type[0]->invoice_type_name;

                             $product_id=$query_val->invoice_type_wise_category_id;
                             $product = DB::table('product_item')->select('product_name')->where(['invoice_type_id'=>$invoice_type_id,'status'=>1,'product_pk_id'=>$product_id])->get();
                             $product_name=$product[0]->product_name;
                            
                              $transaction_mode=$query_val->transaction_mode;
                              $transaction_mode_name_id = DB::table('transaction_mode')->select('transaction_mode_name')->where(['status'=>1,'transaction_mode_id'=>$transaction_mode])->get();
                              $transaction_mode_name=$transaction_mode_name_id[0]->transaction_mode_name;

                               //$user = DB::table('users')->where('name', 'John')->first();echo $user->name; //$email = DB::table('users')->where('name', 'John')->value('email');//$users = DB::table('users')->select('name', 'email as user_email')->get();



                              if($invoice_type_id == '1')
                                    $class="class=text-success";
                              else if($invoice_type_id == '2')
                                    $class="class=text-info";
                              else if($invoice_type_id == '3')
                                    $class="class=text-warning";

                              if($transaction_mode == '1')
                                   $class_mode="class=text-primary";
                              else if($transaction_mode == '2')
                                   $class_mode="class=text-danger";

                             echo '<tr >
                                    <td>'.$client_contact_person_name.'<BR><span '.$class.'><strong>'.$invoice_type.'</strong></span></td>
                                    <td>'.$product_name.'<BR><span '.$class_mode.'>Payment Mode: '.$transaction_mode_name.'</span></td>
                                    <td>'.date('d-m-Y',$query_val->invoice_date).'</td>
                                    <td>'.number_format($query_val->product_round_total,2) .'</td>
                                    <td>
                                        <div class="pull-left">
                                            <a href="" class="btn btn-success btn-sm glyphicon glyphicon glyphicon-eye-open" data-toggle="tooltip" title="" rel="tooltip" data-original-title="View '.$client_contact_person_name.' Customer Invoice Profile"></a>
                                         </div>
                                     </td>
                                    </tr>';
                             $grand_total=$grand_total+$query_val->product_round_total;
                          }
                          
 //$data = DB::table("click")->select(DB::raw("SUM(numberofclick) as count"))->orderBy("created_at")->groupBy(DB::raw("year(created_at)"))->get();
                        ?>
<!---<div class="row pull-right">
<a href="" class="btn btn-success btn-sm glyphicon glyphicon glyphicon-eye-open" data-toggle="tooltip" title="" rel="tooltip" data-original-title="View checkgrp Groups Profile"></a>
<a href="" class="btn btn-info btn-sm glyphicon glyphicon-edit" data-toggle="tooltip" title="" rel="tooltip" data-original-title="Edit checkgrp group Profile"></a>
<a class="btn btn-warning btn-sm glyphicon glyphicon-remove-circle" data-toggle="tooltip" title="" onclick="" name="2" id="active91" rel="tooltip" data-original-title="Deactivate checkgrp Groups"></a>
<a onclick="" id="delete91" class="btn btn-default btn-sm glyphicon glyphicon-trash" data-toggle="tooltip" title="" rel="tooltip" data-original-title="Delete checkgrp Groups"></a>
</div>---->
                    <tr style="background-color: #3a8df7;    color: #fff;    text-align: center;border-top: 1px solid #ddd;line-height: 1.42857;    padding: 8px;    vertical-align: top;border-collapse: separate;    border: solid #ddd 1px;    border-radius: 16px;    border-left: 0px;    border-top: 0px;">
                    <td colspan="3" align=right>TOTAL: </td>
                    <td align=left><?php echo number_format($grand_total,2);?></td>
                    <td></td>
                    </tr>
                    </tbody>
                    </table>
                        <!-- /.panel-body -->

                    <!-- /.panel -->
                @endsection
                @include('widgets.panel', array('header'=>true, 'as'=>'pane2'))
</div></div>
                </div>
                <!-- /.col-lg-8 -->
                    </div>
                    <!-- /.panel .chat-panel -->
                    @endsection
                    @include('widgets.panel', array('header'=>true, 'as'=>'pane3'))
                </div>

                <!-- /.col-lg-4 -->
                <!-----
                1.highchart display offline mode with database way
                2.
                ----------------->
                

@stop